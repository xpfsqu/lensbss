"""Generate figures 1-10 from cached results."""
import os, json, pickle, traceback
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C
plt = C.setup_mpl()
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
R, F = C.RESULTS, C.FIGDIR
CB = ["#2b6cb0", "#c0392b", "#27865c", "#8e44ad", "#d68910", "#16a085"]

def load_json(name):
    with open(os.path.join(R, name)) as f:
        return json.load(f)

def save(fig, name):
    p = os.path.join(F, name)
    fig.savefig(p, bbox_inches="tight", dpi=160)
    plt.close(fig)
    print("  wrote", name)

def fig1_pipeline():
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 4)
    boxes = [(0.7, "Multi-detector\nstrain X(t)"), (2.8, "Whiten +\nSTFT"),
             (4.9, "SSP detection\n(rank-1 cov.)"), (7.0, "Cluster complex\ndirections"),
             (9.1, "min-$\\ell_1$\nrecovery")]
    for x, txt in boxes:
        b = FancyBboxPatch((x - 0.75, 2.4), 1.5, 1.1, boxstyle="round,pad=0.08",
                           fc="#eef3f8", ec=CB[0], lw=1.4)
        ax.add_patch(b); ax.text(x, 2.95, txt, ha="center", va="center", fontsize=8)
    for i in range(len(boxes) - 1):
        ax.add_patch(FancyArrowPatch((boxes[i][0] + 0.78, 2.95),
                                     (boxes[i + 1][0] - 0.78, 2.95),
                                     arrowstyle="-|>", mutation_scale=12, color="#555"))
    # second row: downstream lensing
    d = [(2.8, "Separated\nsource $s_k(t)$"), (4.9, "Neural $F(\\omega,y)$\nsurrogate"),
         (7.0, "Lens posterior\n$p(M_{Lz},y)$")]
    for x, txt in d:
        b = FancyBboxPatch((x - 0.75, 0.5), 1.5, 1.1, boxstyle="round,pad=0.08",
                           fc="#f7eef3", ec=CB[1], lw=1.4)
        ax.add_patch(b); ax.text(x, 1.05, txt, ha="center", va="center", fontsize=8)
    ax.add_patch(FancyArrowPatch((9.1, 2.4), (2.8, 1.62), arrowstyle="-|>",
                                 mutation_scale=12, color="#555",
                                 connectionstyle="arc3,rad=0.25"))
    for i in range(len(d) - 1):
        ax.add_patch(FancyArrowPatch((d[i][0] + 0.78, 1.05), (d[i + 1][0] - 0.78, 1.05),
                                     arrowstyle="-|>", mutation_scale=12, color="#555"))
    ax.text(0.7, 1.05, "Stage 1: blind\nseparation", ha="center", va="center",
            fontsize=8, style="italic", color=CB[0])
    save(fig, "fig1_pipeline.pdf")

def fig2_siren():
    from lensbss.siren import Surrogate
    Fg = np.load(os.path.join(R, "Fgrid.npz"))
    met = load_json("siren_metrics.json")
    wv, yv, Ftrue = Fg["wg"], Fg["yg"], Fg["F"]
    with open(os.path.join(R, "siren_sine.pkl"), "rb") as f:
        st = pickle.load(f)
    sur = Surrogate(st["w_range"], st["y_range"], activation="sine",
                    omega0=st["omega0"]); sur.load(st)
    WW, YY = np.meshgrid(wv, yv, indexing="ij")
    Fpred = sur.predict(WW.ravel(), YY.ravel()).reshape(WW.shape)
    ext = [wv.min(), wv.max(), yv.min(), yv.max()]
    fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.0))
    im0 = axes[0].imshow(np.abs(Ftrue).T, origin="lower", aspect="auto", extent=ext,
                         cmap="magma")
    axes[0].set_title("$|F(\\omega,y)|$ exact"); axes[0].set_xlabel("$\\omega$")
    axes[0].set_ylabel("$y$"); fig.colorbar(im0, ax=axes[0], fraction=0.046)
    err = np.abs(Fpred - Ftrue)
    im1 = axes[1].imshow(err.T, origin="lower", aspect="auto", extent=ext, cmap="viridis")
    axes[1].set_title("absolute error (SIREN)"); axes[1].set_xlabel("$\\omega$")
    fig.colorbar(im1, ax=axes[1], fraction=0.046)
    j = err.shape[1] // 2
    axes[2].plot(wv, np.abs(Ftrue[:, j]), color=CB[0], label="exact")
    axes[2].plot(wv, np.abs(Fpred[:, j]), "--", color=CB[1], label="SIREN")
    axes[2].set_xlabel("$\\omega$"); axes[2].set_ylabel("$|F|$")
    axes[2].set_title(f"$y={yv[j]:.2f}$ slice"); axes[2].legend(frameon=False, fontsize=8)
    axes[2].text(0.04, 0.06, f"median err {met['sine_med']:.1e}",
                 transform=axes[2].transAxes, fontsize=8)
    save(fig, "fig2_siren.pdf")

def fig3_scatter():
    d = np.load(os.path.join(R, "main_arrays.npz"))
    a, b, w = d["alpha"], d["beta"], d["weights"]
    ect = d["est_cols_re"] + 1j * d["est_cols_im"]
    ctt = d["cols_true_re"] + 1j * d["cols_true_im"]
    def ab(c):
        return np.arctan2(np.abs(c[1]), np.abs(c[0])), np.angle(c[1] / c[0])
    fig, ax = plt.subplots(figsize=(5.4, 4.2))
    sc = ax.scatter(a, b, c=np.log10(w + 1e-12), s=6, cmap="cividis", alpha=0.5)
    for i in range(ctt.shape[0]):
        at, bt = ab(ctt[i]); ax.plot(at, bt, "*", ms=16, color=CB[1],
                                     mec="k", mew=0.5, zorder=5)
    for i in range(ect.shape[0]):
        ae, be = ab(ect[i]); ax.plot(ae, be, "o", ms=9, mfc="none", mec=CB[2],
                                     mew=1.8, zorder=6)
    ax.set_xlabel(r"$\alpha=\arctan|a_2/a_1|$")
    ax.set_ylabel(r"$\beta=\arg(a_2/a_1)$ [rad]")
    ax.set_title("Complex mixing directions (ET)")
    ax.plot([], [], "*", color=CB[1], mec="k", label="true columns")
    ax.plot([], [], "o", mfc="none", mec=CB[2], label="estimated")
    ax.legend(frameon=False, fontsize=8, loc="upper center")
    fig.colorbar(sc, ax=ax, fraction=0.046, label="$\\log_{10}$ TF weight")
    save(fig, "fig3_scatter.pdf")

def fig4_separation():
    d = np.load(os.path.join(R, "main_arrays.npz"))
    S, al = d["S"], d["aligned"]
    info = load_json("main.json")["fiducial"]
    perm = info["perm"]; sdrs = info["sdr"]
    fs = C.FS; t = np.arange(S.shape[1]) / fs
    fig, axes = plt.subplots(3, 1, figsize=(7.2, 5.2), sharex=True)
    sl = slice(int(1.0 * fs), int(2.6 * fs))
    for i in range(3):
        axes[i].plot(t[sl], S[i][sl], color="#888", lw=1.3, label="injected")
        r = al[i]
        r = r * np.sign(np.dot(r[sl], S[i][sl]))
        r = r / (np.std(r[sl]) + 1e-12) * np.std(S[i][sl])
        axes[i].plot(t[sl], r[sl], "--", color=CB[i], lw=1.0, label="recovered")
        axes[i].set_ylabel(f"src {i+1}\nSDR {sdrs[i]:.1f} dB", fontsize=8)
        axes[i].legend(frameon=False, fontsize=7, loc="upper left", ncol=2)
    axes[-1].set_xlabel("time [s]")
    axes[0].set_title("Phase-aligned separated waveforms (complex ET mixing)")
    save(fig, "fig4_separation.pdf")

def fig5_lensing():
    d = np.load(os.path.join(R, "main_arrays.npz"))
    lf = load_json("main.json")["lensfit"]
    freqs = d["freqs"]; band = d["band"]
    Femp = d["Femp_re"] + 1j * d["Femp_im"]
    Ftrue = d["Ftrue_re"] + 1j * d["Ftrue_im"]
    chi2 = d["chi2"]; MG, YG = d["MLZ_GRID"], d["Y_GRID"]
    fb = freqs[band]
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 3.6))
    axes[0].plot(fb, np.abs(Ftrue[band]), color="#888", lw=2, label="true $|F|$")
    axes[0].plot(fb, np.abs(Femp), ".", color=CB[0], ms=3, label="recovered")
    axes[0].set_xlabel("frequency [Hz]"); axes[0].set_ylabel("$|F(\\omega,y)|$")
    axes[0].set_title("Amplification recovered from separated source")
    axes[0].legend(frameon=False, fontsize=8)
    chi2n = chi2 - np.nanmin(chi2)
    im = axes[1].pcolormesh(MG, YG, np.clip(chi2n.T, 0, np.nanpercentile(chi2n, 92)),
                            cmap="viridis_r", shading="auto")
    axes[1].plot(lf["MLz_true"], lf["y_true"], "*", ms=15, color=CB[1], mec="k",
                 label="truth")
    axes[1].plot(lf["MLz_sep"], lf["y_sep"], "o", ms=8, color="w", mec="k",
                 label="separated MLE")
    axes[1].plot(lf["MLz_clean"], lf["y_clean"], "s", ms=7, color=CB[2], mec="k",
                 label="clean MLE")
    axes[1].set_xlabel("$M_{Lz}\\,[M_\\odot]$"); axes[1].set_ylabel("$y$")
    axes[1].set_title("$\\Delta\\chi^2$ landscape")
    axes[1].legend(frameon=False, fontsize=7.5)
    fig.colorbar(im, ax=axes[1], fraction=0.046, label="$\\Delta\\chi^2$")
    save(fig, "fig5_lensing.pdf")

def fig6_whitening():
    w = load_json("whiten.json"); s = w["sweep"]; snr = np.array(w["snrs"])
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    ax.errorbar(snr, s["white_mean"], yerr=s["white_std"], marker="o", color=CB[0],
                capsize=3, label="with whitening")
    ax.errorbar(snr, s["nowhite_mean"], yerr=s["nowhite_std"], marker="s", color=CB[1],
                capsize=3, label="no whitening")
    ax.set_xlabel("network mixing SNR [dB]"); ax.set_ylabel("mean SDR [dB]")
    ax.invert_xaxis(); ax.legend(frameon=False); ax.grid(alpha=0.25)
    ax.set_title("Separation quality vs SNR (12 realisations)")
    save(fig, "fig6_whitening.pdf")

def fig7_wdo():
    z = np.load(os.path.join(R, "wdo.npz"))
    dM, dt, H = z["dM"], z["dt"], z["H"]
    fig, ax = plt.subplots(figsize=(5.6, 4.2))
    im = ax.pcolormesh(dt, dM, H, cmap="RdYlGn", shading="nearest",
                       vmin=0, vmax=26)
    ax.set_xlabel("$\\Delta t_c$ [s]"); ax.set_ylabel("$\\Delta M\\,[M_\\odot]$")
    ax.set_title("Worst-source SDR vs mass / time separation")
    fig.colorbar(im, ax=ax, label="min SDR [dB]")
    save(fig, "fig7_wdo.pdf")

def fig8_stronglens():
    d = np.load(os.path.join(R, "stronglens_arrays.npz"))
    info = load_json("stronglens.json")
    fs = float(d["fs"]) if "fs" in d.files else C.FS
    env = d["mf_env"]; img1, img2 = d["img1"], d["img2"]
    n = len(env); t = np.arange(n) / fs
    k1 = int(np.argmax(env))
    dt_est = float(d["dt_est"])
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 3.6))
    # left: shared column scatter
    a, b, w = d["alpha"], d["beta"], d["weights"]
    axes[0].scatter(a, b, s=5, c="#9aa", alpha=0.4)
    ci = d["col_img_re"] + 1j * d["col_img_im"]
    cu = d["col_un_re"] + 1j * d["col_un_im"]
    for c, col, lab in [(ci, CB[1], "image column (shared)"), (cu, CB[2], "unrelated")]:
        at = np.arctan2(abs(c[1]), abs(c[0])); bt = np.angle(c[1] / c[0])
        axes[0].plot(at, bt, "*", ms=16, color=col, mec="k", label=lab)
    axes[0].set_xlabel(r"$\alpha$"); axes[0].set_ylabel(r"$\beta$ [rad]")
    axes[0].set_title("Two images share one direction\n(CP$^1$=0$^\\circ$)")
    axes[0].legend(frameon=False, fontsize=7.5)
    # right: matched-filter envelope with two peaks
    sl = slice(int(0.2 * fs), int(3.6 * fs))
    axes[1].plot(t[sl], env[sl] / env.max(), color=CB[0])
    axes[1].axvline(t[k1], color="#888", ls=":")
    axes[1].set_xlabel("time [s]"); axes[1].set_ylabel("MF envelope (norm.)")
    axes[1].set_title(f"Coherent recovery: $\\Delta t$={dt_est:.3f}s "
                      f"(true 0.45)")
    save(fig, "fig8_stronglens.pdf")

def fig9_mcmc():
    ch = np.load(os.path.join(R, "mcmc_flat.npz"))["chain"]
    m = load_json("mcmc.json")
    fig = plt.figure(figsize=(5.6, 5.0))
    gs = fig.add_gridspec(3, 3)
    axM = fig.add_subplot(gs[0, :2]); axY = fig.add_subplot(gs[1:, 2])
    axJ = fig.add_subplot(gs[1:, :2])
    axM.hist(ch[:, 0], bins=50, color=CB[0], alpha=0.8); axM.axvline(500, color=CB[1])
    axM.set_xticklabels([]); axM.set_ylabel("$p(M_{Lz})$")
    axY.hist(ch[:, 1], bins=50, orientation="horizontal", color=CB[0], alpha=0.8)
    axY.axhline(0.30, color=CB[1]); axY.set_yticklabels([]); axY.set_xlabel("$p(y)$")
    axJ.hexbin(ch[:, 0], ch[:, 1], gridsize=40, cmap="Blues", mincnt=1)
    axJ.plot(500, 0.30, "*", ms=16, color=CB[1], mec="k")
    axJ.set_xlabel("$M_{Lz}\\,[M_\\odot]$"); axJ.set_ylabel("$y$")
    axJ.text(0.03, 0.93, f"$\\hat R$={m['rhat_MLz']:.3f}/{m['rhat_y']:.3f}",
             transform=axJ.transAxes, fontsize=8)
    axM.set_xlim(axJ.get_xlim()); axY.set_ylim(axJ.get_ylim())
    fig.suptitle("Lensing posterior from separated source (truth $\\star$)", fontsize=10)
    save(fig, "fig9_mcmc.pdf")

def fig10_spectrogram():
    g = np.load(os.path.join(R, "glitch_spec.npz"))
    Z1 = g["Z1"]; fr = g["freqs"]
    fig, ax = plt.subplots(figsize=(6.6, 3.8))
    S = 20 * np.log10(np.abs(Z1) + 1e-6)
    im = ax.imshow(S, origin="lower", aspect="auto", cmap="magma",
                   extent=[0, C.DUR, fr.min(), fr.max()],
                   vmax=S.max(), vmin=S.max() - 60)
    ax.set_ylim(0, 400); ax.set_xlabel("time [s]"); ax.set_ylabel("frequency [Hz]")
    ax.set_title("Whitened spectrogram (overlapping chirps + transients)")
    fig.colorbar(im, ax=ax, label="dB")
    save(fig, "fig10_spectrogram.pdf")

for fn in [fig1_pipeline, fig2_siren, fig3_scatter, fig4_separation, fig5_lensing,
           fig6_whitening, fig7_wdo, fig8_stronglens, fig9_mcmc, fig10_spectrogram]:
    try:
        fn()
    except Exception as e:
        print("  FAILED", fn.__name__, "->", e)
        traceback.print_exc()
print("part 1 done")
