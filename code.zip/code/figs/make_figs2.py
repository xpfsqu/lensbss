"""Generate figures 11-16, A, C, D from cached results."""
import os, json, traceback
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C
plt = C.setup_mpl()
R, F = C.RESULTS, C.FIGDIR
CB = ["#2b6cb0", "#c0392b", "#27865c", "#8e44ad", "#d68910", "#16a085"]

def lj(name):
    with open(os.path.join(R, name)) as f:
        return json.load(f)

def save(fig, name):
    fig.savefig(os.path.join(F, name), bbox_inches="tight", dpi=160)
    plt.close(fig); print("  wrote", name)

def fig11_scaling():
    s = lj("extras.json")["scaling"]; N = np.array(s["N"])
    fig, ax = plt.subplots(figsize=(5.6, 4.0))
    ax.errorbar(N, s["oracle_mean"], yerr=s["oracle_std"], marker="o", color=CB[0],
                capsize=3, label="oracle columns")
    ax.errorbar(N, s["blind_mean"], yerr=s["blind_std"], marker="s", color=CB[1],
                capsize=3, label="blind (estimated)")
    ax.set_xlabel("number of overlapping sources $N$ (with $M=2$)")
    ax.set_ylabel("mean SDR [dB]"); ax.set_xticks(N)
    ax.legend(frameon=False); ax.grid(alpha=0.25)
    ax.set_title("Underdetermined scaling")
    save(fig, "fig11_scaling.pdf")

def fig12_whitening_ablation():
    a = lj("ablation.json"); snr = np.array(a["snrs"]); cur = a["curves"]
    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    style = {"ideal_ET": (CB[0], "o", "ideal ET PSD"),
             "aLIGO_mismatch": (CB[2], "^", "aLIGO PSD (mismatch)"),
             "wrong_slope": (CB[3], "v", "wrong-slope PSD"),
             "none": (CB[1], "s", "no whitening")}
    for k, (c, m, lab) in style.items():
        ax.plot(snr, cur[k], marker=m, color=c, label=lab)
    ax.set_xlabel("network mixing SNR [dB]"); ax.set_ylabel("mean SDR [dB]")
    ax.invert_xaxis(); ax.legend(frameon=False, fontsize=8); ax.grid(alpha=0.25)
    ax.set_title("Whitening sensitivity to PSD model")
    save(fig, "fig12_whitening_ablation.pdf")

def fig13_baselines():
    s = lj("baselines.json")["separation_sdr"]
    methods = [("sca", "SCA (ours)"), ("fastica", "FastICA"),
               ("duet", "DUET"), ("sequential", "seq.-subtract\n(non-blind)")]
    means = [s[m + "_mean"] for m, _ in methods]
    labels = [lab for _, lab in methods]
    colors = [CB[0], CB[1], CB[3], "#999"]
    fig, ax = plt.subplots(figsize=(6.0, 3.8))
    ax.bar(range(len(means)), means, color=colors)
    ax.set_xticks(range(len(means))); ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("mean SDR [dB]")
    ax.set_title("Separation baselines (complex underdetermined mixture)")
    for i, v in enumerate(means):
        ax.text(i, v + 0.5, f"{v:.1f}", ha="center", fontsize=8)
    save(fig, "fig13_baselines.pdf")

def fig14_nullstream():
    ns = lj("extras.json")["nullstream"]
    rem = ns["remaining3_sdr"]
    fig, ax = plt.subplots(figsize=(5.0, 3.6))
    ax.bar(range(len(rem)), rem, color=CB[0])
    ax.axhline(np.mean(rem), color=CB[1], ls="--",
               label=f"mean {ns['remaining3_mean']:.1f} dB")
    ax.set_xticks(range(len(rem)))
    ax.set_xticklabels([f"src {i+2}" for i in range(len(rem))])
    ax.set_ylabel("SDR [dB]")
    ax.set_title("After nulling a known-direction source ($M$=3, $N$=4)")
    ax.legend(frameon=False, fontsize=8)
    save(fig, "fig14_nullstream.pdf")

def fig15_imr():
    d = np.load(os.path.join(R, "imr_arrays.npz"))
    S, al = d["S"], d["aligned"]
    info = lj("extras.json")["imr"]
    fs = C.FS; t = np.arange(S.shape[1]) / fs
    fig, axes = plt.subplots(3, 1, figsize=(7.0, 4.8), sharex=True)
    sl = slice(int(1.2 * fs), int(2.2 * fs))
    for i in range(3):
        axes[i].plot(t[sl], S[i][sl], color="#888", lw=1.3, label="injected IMR")
        r = al[i]; r = r * np.sign(np.dot(r[sl], S[i][sl]))
        r = r / (np.std(r[sl]) + 1e-12) * np.std(S[i][sl])
        axes[i].plot(t[sl], r[sl], "--", color=CB[i], lw=1.0, label="recovered")
        axes[i].set_ylabel(f"src {i+1}\n{info['sdr'][i]:.1f} dB", fontsize=8)
        axes[i].legend(frameon=False, fontsize=7, ncol=2, loc="upper left")
    axes[-1].set_xlabel("time [s]")
    axes[0].set_title("Separation with full inspiral-merger-ringdown waveforms")
    save(fig, "fig15_imr.pdf")

def fig16_population():
    recs = lj("population.json")["records"]
    summ = lj("population_summary.json")
    Mt = np.array([r["MLz_true"] for r in recs])
    Mh = np.array([r["MLz_hat"] for r in recs])
    rb = (Mh - Mt) / Mt
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 3.8))
    axes[0].hist(100 * rb, bins=20, color=CB[0], alpha=0.85)
    axes[0].axvline(100 * np.median(rb), color=CB[1],
                    label=f"median {100*np.median(rb):+.0f}%")
    axes[0].axvline(0, color="k", ls=":")
    axes[0].set_xlabel("$M_{Lz}$ point-estimate relative bias [%]")
    axes[0].set_ylabel("injections"); axes[0].legend(frameon=False, fontsize=8)
    axes[0].set_title(f"Separation-induced bias ($N$={summ['n']})")
    # truth vs estimate scatter
    axes[1].scatter(Mt, Mh, s=14, c=[r["sdr_mic"] for r in recs], cmap="viridis")
    lims = [Mt.min() * 0.8, Mt.max() * 1.2]
    axes[1].plot(lims, lims, "k:", lw=1)
    axes[1].set_xlabel("true $M_{Lz}$"); axes[1].set_ylabel("recovered $M_{Lz}$")
    axes[1].set_title("Point estimates scatter high")
    sc = axes[1].collections[0]; fig.colorbar(sc, ax=axes[1], fraction=0.046,
                                              label="sep. SDR [dB]")
    save(fig, "fig16_population.pdf")

def figA_identifiability():
    dm = np.load(os.path.join(R, "main_arrays.npz"))
    ds = np.load(os.path.join(R, "stronglens_arrays.npz"))
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 3.8))
    # left: three unrelated sources -> 3 distinct directions
    ctt = dm["cols_true_re"] + 1j * dm["cols_true_im"]
    axes[0].scatter(dm["alpha"], dm["beta"], s=5, c="#9aa", alpha=0.4)
    for i in range(ctt.shape[0]):
        c = ctt[i]; at = np.arctan2(abs(c[1]), abs(c[0])); bt = np.angle(c[1] / c[0])
        axes[0].plot(at, bt, "*", ms=15, color=CB[i], mec="k")
    axes[0].set_title("3 unrelated sources:\n3 separable directions")
    axes[0].set_xlabel(r"$\alpha$"); axes[0].set_ylabel(r"$\beta$ [rad]")
    # right: two images + unrelated -> 2 directions
    axes[1].scatter(ds["alpha"], ds["beta"], s=5, c="#caa", alpha=0.4)
    ci = ds["col_img_re"] + 1j * ds["col_img_im"]
    cu = ds["col_un_re"] + 1j * ds["col_un_im"]
    for c, col, lab in [(ci, CB[1], "images (2, shared)"), (cu, CB[2], "unrelated")]:
        at = np.arctan2(abs(c[1]), abs(c[0])); bt = np.angle(c[1] / c[0])
        axes[1].plot(at, bt, "*", ms=15, color=col, mec="k", label=lab)
    axes[1].set_title("2 strong-lensing images + 1:\nonly 2 directions")
    axes[1].set_xlabel(r"$\alpha$"); axes[1].legend(frameon=False, fontsize=8)
    save(fig, "figA_identifiability.pdf")

def figC_coverage():
    recs = lj("population.json")["records"]
    cl = np.sort(np.array([r["cred_level"] for r in recs]))
    nominal = np.linspace(0, 1, 100)
    emp = np.array([np.mean(cl <= p) for p in nominal])
    fig, ax = plt.subplots(figsize=(4.6, 4.4))
    ax.plot(nominal, emp, color=CB[0], lw=2, label="separated posteriors")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="ideal calibration")
    ax.fill_between(nominal, nominal, emp, color=CB[0], alpha=0.12)
    ax.set_xlabel("nominal credible level"); ax.set_ylabel("empirical coverage")
    ax.set_title("P-P calibration"); ax.legend(frameon=False, fontsize=8)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_aspect("equal")
    save(fig, "figC_coverage.pdf")

def figD_downstream():
    bj = lj("baselines.json"); dn = bj["downstream"]; sp = bj["runtime"]
    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.8))
    names = ["raw\nmixture", "separated\n(ours)", "oracle\nclean"]
    errM = [abs(dn["raw"][2]), abs(dn["separated"][2]), abs(dn["oracle"][2])]
    axes[0].bar(range(3), errM, color=[CB[1], CB[0], CB[2]])
    axes[0].set_xticks(range(3)); axes[0].set_xticklabels(names, fontsize=8)
    axes[0].set_ylabel("$|M_{Lz}|$ error [%]")
    axes[0].set_title("Downstream lensing accuracy")
    for i, v in enumerate(errM):
        axes[0].text(i, v + 0.3, f"{v:.0f}%", ha="center", fontsize=8)
    # runtime per amplification evaluation
    labels = ["SIREN\nsurrogate", "float64\n$_1F_1$", "mpmath\n(dps=15)", "mpmath\n(dps=30)"]
    times = [sp["surrogate_us"], sp["float64_us"], sp["mpmath15_us"], sp["mpmath30_us"]]
    axes[1].bar(range(4), times, color=[CB[0], CB[4], "#aaa", "#777"])
    axes[1].set_yscale("log"); axes[1].set_xticks(range(4))
    axes[1].set_xticklabels(labels, fontsize=8)
    axes[1].set_ylabel("time per evaluation [$\\mu$s]")
    axes[1].set_title(f"Amplification cost ({sp['speedup_vs_mpmath30']:.0f}$\\times$ vs mpmath)")
    save(fig, "figD_downstream.pdf")

for fn in [fig11_scaling, fig12_whitening_ablation, fig13_baselines, fig14_nullstream,
           fig15_imr, fig16_population, figA_identifiability, figC_coverage,
           figD_downstream]:
    try:
        fn()
    except Exception as e:
        print("  FAILED", fn.__name__, "->", e); traceback.print_exc()
print("part 2 done")
