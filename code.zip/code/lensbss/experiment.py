"""Shared experiment helpers: source construction, mixing, noise, matching."""
import numpy as np
import itertools
from .amplification import F_exact, w_of_f
from .waveforms import make_source_td
from . import config as C
from .metrics import sdr, matched_filter_snr


def build_lensed_source(m1, m2, MLz, y, n, fs, flow=20.0, kind="pn", seed=0):
    """Return (time series, freqs, spectrum) for a microlensed source."""
    s, freqs, hf = make_source_td(m1, m2, n, fs, flow=flow, kind=kind, seed=seed)
    w = w_of_f(freqs, MLz)
    band = w > 1e-6
    F = np.ones_like(hf)
    F[band] = F_exact(w[band], np.full(band.sum(), y), dps=25)
    hl = hf * F
    sl = np.fft.irfft(hl, n=n) * fs
    sl = sl - sl.mean()
    rms = np.sqrt(np.mean(sl ** 2)) + 1e-30
    return sl / rms, freqs, hl / rms, hf, F


def make_sources(sources=None, n=None, fs=None, kind="pn", seed0=1):
    """Build the list of intrinsic source time series + bookkeeping."""
    sources = sources or C.SOURCES
    n = n or C.N
    fs = fs or C.FS
    out = []
    meta = []
    for i, sp in enumerate(sources):
        spx = {k: v for k, v in sp.items() if k != "lensed"}
        if sp.get("lensed"):
            sl, freqs, hl, hf, F = build_lensed_source(
                sp["m1"], sp["m2"], sp["MLz"], sp["y"], n, fs, kind=kind,
                seed=seed0 + i)
            out.append(sl)
            meta.append(dict(lensed=True, freqs=freqs, hf=hf, hl=hl, F=F, **spx))
        else:
            s, freqs, hf = make_source_td(sp["m1"], sp["m2"], n, fs, kind=kind,
                                          seed=seed0 + i)
            out.append(s)
            meta.append(dict(lensed=False, freqs=freqs, hf=hf, **spx))
    return np.array(out), meta


def mix_real(S, thetas):
    """Real instantaneous 2-channel mixing through columns [cos t, sin t]."""
    A = np.array([[np.cos(t), np.sin(t)] for t in thetas])   # (N,2)
    X = A.T @ S
    cols = A / np.linalg.norm(A, axis=1, keepdims=True)
    return X, cols.astype(complex)


def mix_complex(S, cmat):
    """Complex constant 2-channel mixing.  cmat: (N,2) complex columns.
    Implemented in the frequency domain (constant per source)."""
    N, n = S.shape
    X = np.zeros((2, n))
    Xc = np.zeros((2, n), complex)
    for j in range(N):
        Sf = np.fft.rfft(S[j])
        for a in range(2):
            Xc_a = np.fft.irfft(cmat[j, a] * Sf, n=n)
            X[a] += np.real(Xc_a)
    cols = cmat / np.linalg.norm(cmat, axis=1, keepdims=True)
    return X, cols


def add_noise(X, snr_db, fs, psd_func=None, seed=0):
    """Add noise at a target *network mixing SNR* defined as
        SNR^2 = sum_a ||signal_a||^2 / sum_a ||noise_a||^2  (time domain),
    i.e. the ratio of total signal power to total noise power across channels.
    If psd_func given, the noise is colored with that one-sided PSD.
    """
    rng = np.random.default_rng(seed)
    M, n = X.shape
    sig_pow = np.sum(X ** 2)
    if psd_func is None:
        # white: unit-variance then scale
        nz = rng.standard_normal((M, n))
    else:
        freqs = np.fft.rfftfreq(n, 1.0 / fs)
        asd = np.sqrt(psd_func(freqs))
        nz = np.zeros((M, n))
        for a in range(M):
            wn = (rng.standard_normal(len(freqs)) + 1j * rng.standard_normal(len(freqs)))
            nz[a] = np.fft.irfft(wn * asd, n=n)
    noise_pow = np.sum(nz ** 2)
    scale = np.sqrt(sig_pow / (noise_pow * 10 ** (snr_db / 10.0)))
    return X + scale * nz, scale


def best_match_sdr(S_true, S_rec):
    """Permutation-matched per-source SDR (and the matching permutation)."""
    N = S_true.shape[0]
    best = None
    for perm in itertools.permutations(range(min(N, S_rec.shape[0]))):
        sdrs = [sdr(S_true[i], S_rec[perm[i]]) for i in range(len(perm))]
        if best is None or np.mean(sdrs) > np.mean(best[1]):
            best = (perm, sdrs)
    return best


def best_match_sdr_pa(S_true, S_stft, fs, nperseg):
    """Phase-aligned permutation-matched SDR for complex-mixing reconstructions.
    Returns (perm, sdrs, aligned_sources)."""
    from .metrics import sdr_phase_aligned
    N = S_true.shape[0]
    M = S_stft.shape[0]
    Smat = np.zeros((N, M))
    aligned = {}
    for i in range(N):
        for k in range(M):
            s, al = sdr_phase_aligned(S_true[i], S_stft[k], fs, nperseg)
            Smat[i, k] = s
            aligned[(i, k)] = al
    best = None
    perms = (itertools.permutations(range(M), N) if M >= N
             else [tuple(range(M))])
    for perm in perms:
        val = np.mean([Smat[i, perm[i]] for i in range(N)])
        if best is None or val > best[1]:
            best = (perm, val, [Smat[i, perm[i]] for i in range(N)])
    perm = best[0]
    aligned_src = np.array([aligned[(i, perm[i])] for i in range(N)])
    return perm, best[2], aligned_src


def network_mf_snr(S, cols, psd_func, fs, flow=20.0):
    """Matched-filter network SNR of a single source across channels."""
    n = S.shape[-1]
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    psd = psd_func(freqs)
    snr2 = 0.0
    for a in range(cols.shape[0]):
        h = np.fft.irfft(cols[a] * np.fft.rfft(S), n=n)
        snr2 += matched_filter_snr(h, psd, fs, flow=flow) ** 2
    return np.sqrt(snr2)


# fiducial sky positions for the complex-mixing scenario (one per source)
SKIES = [dict(ra=1.2, dec=0.3, psi=0.4, iota=0.5),
         dict(ra=4.5, dec=-0.6, psi=1.1, iota=1.2),
         dict(ra=2.8, dec=0.9, psi=0.7, iota=0.9)]


def fiducial_scenario(snr_db=34.0, kind="pn", seed=0, mixing="complex_et"):
    """Build the standard 3-source scenario used throughout the paper.

    mixing: 'complex_et' (two co-located ET detectors -> complex constant cols),
            'real' (instantaneous real cols; the phi=0 special case),
            'etce' (ET + CE -> frequency-dependent cols).
    Returns dict with S, meta, cmat/cols_true, X, Xn, freqs, skies.
    """
    from . import detector as det
    S, meta = make_sources(kind=kind)
    n = S.shape[1]
    fs = C.FS
    ff = np.fft.rfftfreq(n, 1.0 / fs)
    if mixing == "real":
        thetas = [sp["theta"] for sp in C.SOURCES]
        X, cols_true = mix_real(S, thetas)
        cmat = (cols_true.T)
        delays = np.zeros((2, len(S)))
        Afreq = None
    elif mixing == "complex_et":
        dets = det.et_triangle()[:2]
        Afreq, cmat, delays = det.mixing_columns(dets, ff, SKIES)
        cols_true = (cmat / np.linalg.norm(cmat, axis=0, keepdims=True)).T
        X, _ = mix_complex(S, cmat.T)
    elif mixing == "etce":
        dets = [det.et_triangle()[0], det.cosmic_explorer()]
        Afreq, cmat, delays = det.mixing_columns(dets, ff, SKIES)
        cols_true = None
        # frequency-dependent mixing in the frequency domain
        X = np.zeros((2, n))
        for a in range(2):
            acc = np.zeros(len(ff), complex)
            for j in range(len(S)):
                acc += Afreq[a, j, :] * np.fft.rfft(S[j])
            X[a] = np.fft.irfft(acc, n=n)
    else:
        raise ValueError(mixing)
    Xn, scale = add_noise(X, snr_db, fs, seed=seed)
    return dict(S=S, meta=meta, cmat=cmat, cols_true=cols_true, X=X, Xn=Xn,
                freqs=ff, delays=delays, Afreq=Afreq, scale=scale, mixing=mixing)
