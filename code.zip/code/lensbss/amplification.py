"""
Point-mass-lens (PML) wave-optics amplification factor F(omega, y).

We use the standard Takahashi & Nakamura (2003) closed form,

    F(w,y) = exp[ pi*w/4 + i*(w/2)*( ln(w/2) - 2*phi_m(y) ) ]
             * Gamma(1 - i*w/2) * 1F1( i*w/2 ; 1 ; i*w*y^2/2 ),

with the dimensionless frequency

    w = 8*pi*G*M_Lz*f / c^3 ,   M_Lz = (1+z_L) M_L   (redshifted lens mass).

NOTE on the redshift convention (reviewer point): M_Lz already absorbs the
(1+z_L) factor, so w must NOT carry a second explicit (1+z_L).  We therefore
write w = 8*pi*G*M_Lz*f/c^3 throughout.

Three evaluators are provided:
  * F_exact   : arbitrary-precision (mpmath) ground truth.
  * F_float64 : a naive vectorised complex128 power series for 1F1.  It is fast
                but, as we demonstrate, breaks down at high w because of
                catastrophic cancellation -- this is *why* arbitrary precision
                (or a surrogate) is needed.
  * F_geo     : the geometric-optics (high-frequency) two-image limit.
"""
import numpy as np
import mpmath as mp

# physical constants (SI)
G = 6.67430e-11
c = 299792458.0
Msun = 1.98892e30


def w_of_f(f, MLz_solar):
    """Dimensionless frequency w from physical frequency f [Hz] and redshifted
    lens mass MLz_solar [Msun]."""
    return 8.0 * np.pi * G * (MLz_solar * Msun) * np.asarray(f) / c**3


def _phi_m(y):
    xm = (y + mp.sqrt(y * y + 4)) / 2
    return (xm - y) ** 2 / 2 - mp.log(xm)


def F_exact_scalar(w, y, dps=30):
    """Exact F(w,y) via mpmath at `dps` decimal digits."""
    with mp.workdps(dps):
        w = mp.mpf(float(w))
        y = mp.mpf(float(y))
        phim = _phi_m(y)
        pref = mp.e ** (mp.pi * w / 4 + 1j * (w / 2) * (mp.log(w / 2) - 2 * phim))
        val = pref * mp.gamma(1 - 1j * w / 2) * mp.hyp1f1(1j * w / 2, 1, 1j * w * y * y / 2)
        return complex(val)


def F_exact(w, y, dps=30):
    """Vectorised exact evaluator (loops in Python; intended for precompute)."""
    w = np.atleast_1d(np.asarray(w, float))
    y = np.atleast_1d(np.asarray(y, float))
    w, y = np.broadcast_arrays(w, y)
    out = np.empty(w.shape, complex)
    flat_w, flat_y, flat_o = w.ravel(), y.ravel(), out.ravel()
    for i in range(flat_w.size):
        flat_o[i] = F_exact_scalar(flat_w[i], flat_y[i], dps=dps)
    return out.reshape(w.shape)


def hyp1f1_series_float64(a, z, nmax=400):
    """Naive complex128 series for 1F1(a;1;z) = sum_n (a)_n z^n / (n!)^2.

    Vectorised over arrays a, z of equal shape.  Returns the partial sum; no
    attempt is made to control cancellation -- this is deliberately the
    'what you would write in float64' reference.
    """
    a = np.asarray(a, complex)
    z = np.asarray(z, complex)
    term = np.ones(np.broadcast(a, z).shape, complex)
    total = term.copy()
    for n in range(0, nmax):
        # term_{n+1} = term_n * (a+n) * z / (n+1)^2
        term = term * (a + n) * z / (n + 1.0) ** 2
        total = total + term
    return total


def F_float64(w, y, nmax=400):
    """Fast float64 evaluator using the naive 1F1 series (breaks down at high w)."""
    w = np.asarray(w, float)
    y = np.asarray(y, float)
    w, y = np.broadcast_arrays(w, y)
    a = 1j * w / 2.0
    z = 1j * w * y ** 2 / 2.0
    # prefactor and Gamma are stable in float64 (large*small, no cancellation)
    from scipy.special import gamma as cgamma
    xm = (y + np.sqrt(y ** 2 + 4)) / 2
    phim = (xm - y) ** 2 / 2 - np.log(xm)
    pref = np.exp(np.pi * w / 4 + 1j * (w / 2) * (np.log(w / 2) - 2 * phim))
    return pref * cgamma(1 - 1j * w / 2) * hyp1f1_series_float64(a, z, nmax=nmax)


def F_geo(w, y):
    """Geometric-optics two-image limit (high-frequency).

    F_geo = |mu+|^1/2 - i |mu-|^1/2 exp(i w * dT),  with
       mu_pm = 1/2 +/- (y^2+2)/(2 y sqrt(y^2+4)),
       dT    = y sqrt(y^2+4)/2 + ln[(sqrt(y^2+4)+y)/(sqrt(y^2+4)-y)].
    """
    w = np.asarray(w, float)
    y = np.asarray(y, float)
    r = np.sqrt(y ** 2 + 4)
    mu_p = 0.5 + (y ** 2 + 2) / (2 * y * r)
    mu_m = 0.5 - (y ** 2 + 2) / (2 * y * r)
    dT = y * r / 2 + np.log((r + y) / (r - y))
    return np.sqrt(np.abs(mu_p)) - 1j * np.sqrt(np.abs(mu_m)) * np.exp(1j * w * dT)
