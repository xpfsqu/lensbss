"""
Surrogate-accelerated wave-optics lensing inference.

Given a separated candidate spectrum S(f) and an (intrinsic) template h(f), we
fit the point-mass-lens parameters (M_Lz, y) by minimising the residual to
A * F(f; M_Lz, y) * h(f), with the BSS scale A marginalised in closed form.  The
amplification factor F is evaluated with the SIREN surrogate, which is what makes
both the dense grid search and the MCMC affordable.

The likelihood is calibrated (reduced chi^2 = 1 at the best fit) and then either
sampled with Metropolis-Hastings or normalised on the grid to obtain credible
regions; the latter is used for the population coverage / PP-plot study where a
full chain per injection would be too expensive.
"""
import numpy as np
from .amplification import w_of_f


# ----------------------------------------------------------------------
# chi^2 surface on a grid, scale marginalised
# ----------------------------------------------------------------------
def chi2_grid(Sf, hf, freqs, MLz_grid, y_grid, surrogate, psd=None,
              wmax=30.0, flow=20.0, stride=2):
    """Return chi^2 over the (MLz, y) grid using the surrogate.

    Sf, hf : complex one-sided spectra (separated signal, intrinsic template).
    psd    : optional one-sided PSD for noise weighting (uses 1/psd weights).
    stride : subsample the fit band (the chi^2 is smooth in frequency, so every
             `stride`-th bin is sufficient and much cheaper).

    Vectorised over the y-grid: for each MLz we evaluate the surrogate once on
    the (band x n_y) block, which is far cheaper than per-cell calls.
    """
    nM, nY = len(MLz_grid), len(y_grid)
    chi2 = np.full((nM, nY), np.inf)
    if psd is not None:
        wts = np.where(psd > 0, 1.0 / psd, 0.0)
    else:
        wts = np.ones_like(freqs)
    # template support: only fit where the intrinsic waveform has power
    hsup = np.abs(hf) > 1e-3 * np.max(np.abs(hf))
    for i, MLz in enumerate(MLz_grid):
        w = w_of_f(freqs, MLz)
        band = np.where((w <= wmax) & (freqs >= flow) & (w > 1e-3) & hsup)[0]
        band = band[::stride]
        nb = band.size
        if nb < 8:
            continue
        wf = w[band]                                  # (nb,)
        wb = wts[band]
        Sb = Sf[band]
        hb = hf[band]
        # evaluate F on the (nb x nY) block in one surrogate call
        Wrep = np.tile(wf, nY)
        Yrep = np.repeat(y_grid, nb)
        Fall = surrogate.predict(Wrep, Yrep).reshape(nY, nb)
        model = Fall * hb[None, :]                    # (nY, nb)
        num = np.sum(wb[None, :] * np.conj(model) * Sb[None, :], axis=1)
        den = np.sum(wb[None, :] * np.abs(model) ** 2, axis=1) + 1e-30
        A = num / den                                 # (nY,) complex
        resid = Sb[None, :] - A[:, None] * model
        chi2[i, :] = np.sum(wb[None, :] * np.abs(resid) ** 2, axis=1)
    return chi2


def best_fit(chi2, MLz_grid, y_grid):
    i, j = np.unravel_index(np.argmin(chi2), chi2.shape)
    return MLz_grid[i], y_grid[j], (i, j)


# ----------------------------------------------------------------------
# Calibrated grid posterior + credible regions
# ----------------------------------------------------------------------
def grid_posterior(chi2, MLz_grid, y_grid, dof=None):
    """Convert a chi^2 surface into a normalised posterior.

    Calibrate sigma^2 so reduced chi^2 = 1 at the minimum: logL = -chi^2/(2 s2)
    with s2 = chi2_min / dof.  dof defaults to (#grid > 0 cells effective ~ 1);
    for posterior *shape* only the relative chi^2 matters, so we use
    s2 = chi2_min / N_eff with N_eff a fixed nominal band length passed by caller.
    """
    c = chi2.copy()
    cmin = np.nanmin(c)
    if dof is None or dof <= 0:
        dof = 1.0
    s2 = cmin / dof
    logp = -(c - cmin) / (2 * s2)
    p = np.exp(logp - logp.max())
    p[~np.isfinite(p)] = 0.0
    p /= p.sum() + 1e-30
    return p


def credible_level_of_truth(p, idx_true):
    """Fraction of posterior mass at probability >= p[true]; i.e. the smallest
    credible level whose HPD region contains the truth.  Used for PP plots."""
    pt = p[idx_true]
    mass_above = p[p >= pt].sum()
    return float(mass_above)


def nearest_grid_index(MLz_grid, y_grid, MLz_true, y_true):
    i = int(np.argmin(np.abs(MLz_grid - MLz_true)))
    j = int(np.argmin(np.abs(y_grid - y_true)))
    return i, j


# ----------------------------------------------------------------------
# Metropolis-Hastings sampler (surrogate likelihood)
# ----------------------------------------------------------------------
def mh_sample(Sf, hf, freqs, surrogate, MLz0, y0, n_samples=10000,
              step_MLz=15.0, step_y=0.02, psd=None, wmax=30.0, flow=20.0,
              bounds=((100.0, 1200.0), (0.05, 1.5)), sigma2=None, seed=0,
              stride=2):
    """Metropolis-Hastings on (M_Lz, y) with a calibrated Gaussian residual
    likelihood.  Returns the chain (n_samples, 2) after a 20% burn-in."""
    rng = np.random.default_rng(seed)
    if psd is not None:
        wts = np.where(psd > 0, 1.0 / psd, 0.0)
    else:
        wts = np.ones_like(freqs)
    hsup = np.abs(hf) > 1e-3 * np.max(np.abs(hf))

    def neglog_resid(MLz, y):
        w = w_of_f(freqs, MLz)
        band = np.where((w <= wmax) & (freqs >= flow) & (w > 1e-3) & hsup)[0]
        band = band[::stride]
        if band.size < 8:
            return np.inf
        wf = w[band]
        Fv = surrogate.predict(wf, np.full_like(wf, y))
        model = Fv * hf[band]
        wb = wts[band]
        num = np.sum(wb * np.conj(model) * Sf[band])
        den = np.sum(wb * np.abs(model) ** 2) + 1e-30
        A = num / den
        resid = Sf[band] - A * model
        return np.sum(wb * np.abs(resid) ** 2)

    # calibrate sigma^2 at the start point if not provided
    c0 = neglog_resid(MLz0, y0)
    if sigma2 is None:
        sigma2 = c0 / 200.0  # nominal effective band length
    cur = np.array([MLz0, y0])
    cur_ll = -neglog_resid(*cur) / (2 * sigma2)
    chain = np.zeros((n_samples, 2))
    naccept = 0
    for t in range(n_samples):
        prop = cur + rng.normal(0, [step_MLz, step_y])
        if not (bounds[0][0] <= prop[0] <= bounds[0][1] and
                bounds[1][0] <= prop[1] <= bounds[1][1]):
            chain[t] = cur
            continue
        prop_ll = -neglog_resid(*prop) / (2 * sigma2)
        if np.log(rng.uniform() + 1e-30) < (prop_ll - cur_ll):
            cur, cur_ll = prop, prop_ll
            naccept += 1
        chain[t] = cur
    burn = n_samples // 5
    return chain[burn:], naccept / n_samples


def gelman_rubin(chains):
    """R-hat for a list of chains (each (n,1) of one parameter)."""
    m = len(chains)
    n = min(len(c) for c in chains)
    arr = np.array([c[:n] for c in chains])     # (m, n)
    means = arr.mean(1)
    B = n * means.var(ddof=1)
    W = arr.var(1, ddof=1).mean()
    var = (1 - 1.0 / n) * W + B / n
    return float(np.sqrt(var / (W + 1e-30)))
