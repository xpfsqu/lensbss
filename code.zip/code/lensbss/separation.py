"""
Time-frequency sparse-component-analysis separation front-end.

This module implements the underdetermined BSS pipeline with the *complex*,
possibly frequency-dependent mixing that a real detector network produces (see
detector.py).  The key change relative to a real-instantaneous-mixing treatment
is that single-source points are clustered in a COMPLEX direction space, not by
the real-ratio test Im(X2/X1)~0 (which is only valid for a constant real mix).

Two clustering parametrisations are provided:

  * 'phase'  : feature (alpha, beta) = (atan|X2/X1|, arg(X2/X1)).  Correct when
               the per-source mixing column is a complex *constant* (e.g. the
               co-located ET triangle, whose inter-detector delays are ~100 ns
               and hence negligible in band).  beta is then frequency-independent.
  * 'delay'  : feature (alpha, d) = (atan|X2/X1|, -arg(X2/X1)/(2 pi f)).  Correct
               when the inter-detector phase is dominated by a geometric time
               delay (e.g. the ET-CE baseline), so beta is linear in f and the
               delay d is the frequency-independent invariant.

For M>2 the same idea generalises: SSP observation vectors are normalised onto
the complex projective sphere and clustered with the chordal metric.
"""
import numpy as np
from scipy.signal import stft as _stft, istft as _istft


# ----------------------------------------------------------------------
# Stage 0: whitening
# ----------------------------------------------------------------------
def whiten(x, psd_func, fs):
    """Whiten a real time series by dividing by the ASD in the frequency domain.

    psd_func(f) returns the one-sided PSD S_n(f); the whitened series has a flat
    noise floor.  This is a per-channel LTI operation and leaves the mixing
    matrix unchanged.
    """
    n = len(x)
    xf = np.fft.rfft(x)
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    asd = np.sqrt(psd_func(freqs))
    asd = np.where(asd > 0, asd, np.inf)
    xw = np.fft.irfft(xf / asd, n=n)
    return xw


# ----------------------------------------------------------------------
# STFT helpers
# ----------------------------------------------------------------------
def stft_channel(x, fs, nperseg=256, noverlap=None):
    if noverlap is None:
        noverlap = nperseg * 3 // 4
    f, t, Z = _stft(x, fs=fs, nperseg=nperseg, noverlap=noverlap,
                    window="hann", boundary="zeros", padded=True)
    return f, t, Z


def istft_channel(Z, fs, nperseg=256, noverlap=None):
    if noverlap is None:
        noverlap = nperseg * 3 // 4
    _, x = _istft(Z, fs=fs, nperseg=nperseg, noverlap=noverlap, window="hann",
                  boundary=True)
    return x


# ----------------------------------------------------------------------
# Stage 1: single-source-point detection + complex clustering (M = 2)
# ----------------------------------------------------------------------
def ssp_features_M2(Z1, Z2, freqs, energy_pct=70.0, feature="phase",
                    rank1_thresh=0.06, win=(3, 3), energy_floor_pct=40.0):
    """Return SSP feature vectors for a 2-channel STFT using a LOCAL RANK-1
    single-source-point test that is valid for *complex* mixing.

    A TF cell is a single-source point if, over a small TF neighbourhood, the
    2x2 observation covariance R = E[X X^H] is approximately rank one (the two
    channels are locally a fixed complex multiple of one direction).  This is the
    complex generalisation of the real-ratio SSP test and does not bias towards
    loud sources, so weak sources still contribute their own cluster.

    The dominant eigenvector of R gives the complex column direction at that cell.
    Returns (feat, alpha, beta, sel_mask, weights, fsel).
    """
    from scipy.ndimage import uniform_filter
    # smoothed covariance components over a small TF window
    R11 = uniform_filter(np.abs(Z1) ** 2, size=win)
    R22 = uniform_filter(np.abs(Z2) ** 2, size=win)
    R12 = (uniform_filter(np.real(Z1 * np.conj(Z2)), size=win)
           + 1j * uniform_filter(np.imag(Z1 * np.conj(Z2)), size=win))
    tr = R11 + R22
    det = R11 * R22 - np.abs(R12) ** 2
    disc = np.sqrt(np.maximum(tr ** 2 - 4 * det, 0.0))
    lam_max = (tr + disc) / 2
    lam_min = (tr - disc) / 2
    rank1 = lam_min / (lam_max + 1e-30)            # small => single source
    # dominant eigenvector v = [R12, lam_max - R11]
    v1 = R12
    v2 = (lam_max - R11).astype(complex)
    # fall back where R12 ~ 0 (use the other row)
    small = np.abs(v1) < 1e-12
    v1 = np.where(small, (lam_max - R22).astype(complex), v1)
    v2 = np.where(small, np.conj(R12), v2)

    P = R11 + R22
    sel = (rank1 < rank1_thresh) & (P >= np.percentile(P, energy_floor_pct))
    sel &= np.abs(v1) > 1e-15
    fidx = np.broadcast_to(freqs[:, None], Z1.shape)
    alpha = np.arctan2(np.abs(v2[sel]), np.abs(v1[sel]))
    beta = np.angle(v2[sel] / v1[sel])
    fsel = fidx[sel]
    w = P[sel] * (1.0 - rank1[sel])                # weight by energy and rank-1-ness
    if feature == "phase":
        feat = np.column_stack([alpha, beta])
    elif feature == "delay":
        d = -beta / (2 * np.pi * np.maximum(fsel, 1.0))
        feat = np.column_stack([alpha, d])
    else:
        raise ValueError(feature)
    return feat, alpha, beta, sel, w, fsel


def _scale_features(feat):
    mu = feat.mean(0)
    sd = feat.std(0) + 1e-12
    return (feat - mu) / sd, mu, sd


def cluster_columns_M2(feat, n_sources, method="dbscan", weights=None,
                       eps=0.25, min_samples=20):
    """Cluster SSP features into n_sources complex mixing directions (M=2).

    Returns (centers_feat, labels) where centers_feat are the n_sources densest
    cluster centroids in (alpha, beta-or-delay) space.
    """
    Xs, mu, sd = _scale_features(feat)
    if method == "kmeans":
        from sklearn.cluster import KMeans
        km = KMeans(n_clusters=n_sources, n_init=10, random_state=0).fit(Xs)
        labels = km.labels_
        cents = km.cluster_centers_ * sd + mu
        order = np.argsort([np.sum(labels == k) for k in range(n_sources)])[::-1]
        return cents[order], labels
    elif method == "dbscan":
        from sklearn.cluster import DBSCAN
        db = DBSCAN(eps=eps, min_samples=min_samples).fit(Xs)
        labels = db.labels_
        uniq = [u for u in np.unique(labels) if u != -1]
        # rank clusters by (weighted) population, keep the n_sources densest
        sizes = []
        for u in uniq:
            m = labels == u
            sizes.append(np.sum(weights[m]) if weights is not None else np.sum(m))
        order = np.argsort(sizes)[::-1][:n_sources]
        cents = []
        for u in np.array(uniq)[order]:
            m = labels == u
            if weights is not None:
                c = np.average(feat[m], axis=0, weights=weights[m])
            else:
                c = feat[m].mean(0)
            cents.append(c)
        # if DBSCAN found fewer than n_sources, pad with k-means fallback
        if len(cents) < n_sources:
            from sklearn.cluster import KMeans
            km = KMeans(n_clusters=n_sources, n_init=10, random_state=0).fit(Xs)
            return km.cluster_centers_ * sd + mu, km.labels_
        return np.array(cents), labels
    else:
        raise ValueError(method)


def cluster_columns_peaks(feat, n_sources, weights=None, bins=(60, 60),
                          smooth=1.5, min_sep_frac=0.12):
    """Robust mixing-column estimation by weighted 2D histogram peak finding.

    Builds a weighted histogram of the (alpha, beta|delay) features, smooths it,
    and returns the n_sources highest local maxima separated by at least
    min_sep_frac of the feature range.  Unlike density clustering this is not
    biased by a populous source dominating the SSP count.
    """
    from scipy.ndimage import gaussian_filter, maximum_filter
    a = feat[:, 0]
    b = feat[:, 1]
    arange = (a.min(), a.max())
    brange = (b.min(), b.max())
    H, ae, be = np.histogram2d(a, b, bins=bins, range=[arange, brange],
                               weights=weights)
    Hs = gaussian_filter(H, smooth)
    mf = maximum_filter(Hs, size=3)
    peaks = (Hs == mf) & (Hs > 0)
    pi, pj = np.where(peaks)
    vals = Hs[pi, pj]
    order = np.argsort(vals)[::-1]
    ac = 0.5 * (ae[:-1] + ae[1:])
    bc = 0.5 * (be[:-1] + be[1:])
    da = (arange[1] - arange[0]) * min_sep_frac
    dbb = (brange[1] - brange[0]) * min_sep_frac + 1e-9
    chosen = []
    for k in order:
        ca, cb = ac[pi[k]], bc[pj[k]]
        ok = True
        for (xa, xb) in chosen:
            if abs(ca - xa) < da and abs(cb - xb) < dbb:
                ok = False
                break
        if ok:
            chosen.append((ca, cb))
        if len(chosen) == n_sources:
            break
    # refine each peak by a local weighted centroid of nearby SSPs
    cents = []
    for (ca, cb) in chosen:
        m = (np.abs(a - ca) < da) & (np.abs(b - cb) < max(dbb, 0.3))
        if m.sum() >= 3:
            ww = weights[m] if weights is not None else None
            cents.append([np.average(a[m], weights=ww), np.average(b[m], weights=ww)])
        else:
            cents.append([ca, cb])
    # pad if fewer peaks than sources
    while len(cents) < n_sources:
        cents.append([np.median(a), np.median(b)])
    return np.array(cents), None



def columns_from_features(cents, feature="phase", f_ref=100.0):
    """Convert (alpha, beta|delay) cluster centers into complex unit columns.

    For 'phase': a = [cos a, sin a * exp(i beta)].
    For 'delay': we return the constant part [cos a, sin a] and the delay; the
    caller can reinsert the exp(-2 pi i f d) frequency dependence per bin.
    """
    out = []
    delays = []
    for c in cents:
        a = c[0]
        if feature == "phase":
            col = np.array([np.cos(a), np.sin(a) * np.exp(1j * c[1])], complex)
            out.append(col / np.linalg.norm(col))
            delays.append(0.0)
        else:
            col = np.array([np.cos(a), np.sin(a)], complex)
            out.append(col / np.linalg.norm(col))
            delays.append(c[1])
    return np.array(out), np.array(delays)


# ----------------------------------------------------------------------
# Stage 2: shortest-path (min-L1) recovery, complex
# ----------------------------------------------------------------------
def _pairs(n):
    return [(i, j) for i in range(n) for j in range(i + 1, n)]


def recover_l1_M2(Zstack, A_cols, delays=None, freqs=None):
    """Shortest-path recovery for M=2, N columns (complex).

    Zstack : (2, F, T) complex STFT of the two channels.
    A_cols : (N, 2) complex unit columns (constant part).
    delays : optional (N,) inter-channel delays; if given, the per-bin column is
             [c0, c1 * exp(-2 pi i f delay)] (delay-aware reconstruction).
    Returns S : (N, F, T) complex separated STFTs.
    """
    M, F, T = Zstack.shape
    N = A_cols.shape[0]
    S = np.zeros((N, F, T), complex)
    X = Zstack.reshape(M, -1)                       # (2, F*T)
    fflat = (np.broadcast_to(freqs[:, None], (F, T)).reshape(-1)
             if freqs is not None else None)
    pairs = _pairs(N)
    # Precompute per-pair inverse where mixing is constant (delays None)
    best_cost = np.full(X.shape[1], np.inf)
    best_s = np.zeros((N, X.shape[1]), complex)
    for (i, j) in pairs:
        if delays is None or np.all(delays == 0):
            Apair = np.column_stack([A_cols[i], A_cols[j]])  # (2,2)
            det = Apair[0, 0] * Apair[1, 1] - Apair[0, 1] * Apair[1, 0]
            if abs(det) < 1e-12:
                continue
            inv = np.array([[Apair[1, 1], -Apair[0, 1]],
                            [-Apair[1, 0], Apair[0, 0]]]) / det
            s = inv @ X                                   # (2, F*T)
            cost = np.abs(s[0]) + np.abs(s[1])
            upd = cost < best_cost
            best_cost = np.where(upd, cost, best_cost)
            best_s[i] = np.where(upd, s[0], best_s[i])
            best_s[j] = np.where(upd, s[1], best_s[j])
            # zero the columns not in this pair where it wins
            for k in range(N):
                if k not in (i, j):
                    best_s[k] = np.where(upd, 0.0, best_s[k])
        else:
            # frequency-dependent columns: solve per unique frequency bin
            ci = np.array([A_cols[i, 0], A_cols[i, 1]])
            cj = np.array([A_cols[j, 0], A_cols[j, 1]])
            phase_i = np.exp(-2j * np.pi * fflat * delays[i])
            phase_j = np.exp(-2j * np.pi * fflat * delays[j])
            a0i, a1i = ci[0] * 1.0, ci[1] * phase_i
            a0j, a1j = cj[0] * 1.0, cj[1] * phase_j
            det = a0i * a1j - a0j * a1i
            ok = np.abs(det) > 1e-12
            s_i = np.zeros(X.shape[1], complex)
            s_j = np.zeros(X.shape[1], complex)
            s_i[ok] = (a1j[ok] * X[0, ok] - a0j * X[1, ok]) / det[ok]
            s_j[ok] = (-a1i[ok] * X[0, ok] + a0i * X[1, ok]) / det[ok]
            cost = np.abs(s_i) + np.abs(s_j)
            upd = cost < best_cost
            best_cost = np.where(upd, cost, best_cost)
            best_s[i] = np.where(upd, s_i, best_s[i])
            best_s[j] = np.where(upd, s_j, best_s[j])
            for k in range(N):
                if k not in (i, j):
                    best_s[k] = np.where(upd, 0.0, best_s[k])
    for k in range(N):
        S[k] = best_s[k].reshape(F, T)
    return S


def soft_mask_M2(Zstack, A_cols):
    """Soft (Wiener-like) recovery: distribute each cell over columns by a softmax
    of the negative projection residual."""
    M, F, T = Zstack.shape
    N = A_cols.shape[0]
    X = Zstack.reshape(M, -1)
    res = np.zeros((N, X.shape[1]))
    proj = np.zeros((N, X.shape[1]), complex)
    for k in range(N):
        a = A_cols[k][:, None]
        coef = (a.conj().T @ X) / (a.conj().T @ a)
        proj[k] = coef[0]
        rec = a @ coef
        res[k] = np.sum(np.abs(X - rec) ** 2, axis=0)
    # softmax over -residual (temperature ~ median residual)
    temp = np.median(res) + 1e-12
    wgt = np.exp(-res / temp)
    wgt /= wgt.sum(0, keepdims=True) + 1e-30
    S = (wgt * proj).reshape(N, F, T)
    return S


# ----------------------------------------------------------------------
# Null-stream projection (M=3 ET triangle)
# ----------------------------------------------------------------------
def null_project(Zstack, cvec):
    """Project a 3-channel STFT onto the 2-D subspace orthogonal to null vector c.

    Returns (Zproj (2,F,T), B) where B (2x3) is the orthonormal projector rows so
    that estimated 3-channel columns are recovered as a = B^+ a_proj.
    """
    c = np.asarray(cvec, float)
    c = c / np.linalg.norm(c)
    # build orthonormal basis of c^perp
    e = np.eye(3)
    # pick two columns least aligned with c
    cols = sorted(range(3), key=lambda i: abs(c[i]))[:2]
    B = []
    for i in cols:
        v = e[i] - np.dot(e[i], c) * c
        for b in B:
            v = v - np.dot(v, b) * b
        v = v / np.linalg.norm(v)
        B.append(v)
    B = np.array(B)                              # (2,3)
    M, F, T = Zstack.shape
    Zp = np.einsum("ab,bft->aft", B, Zstack)
    return Zp, B


# ----------------------------------------------------------------------
# Convenience: full M=2 separation given mixed channels
# ----------------------------------------------------------------------
def separate_M2(x1, x2, n_sources, fs, nperseg=256, feature="phase",
                method="dbscan", energy_pct=85.0, eps=0.25, min_samples=20,
                rank1_thresh=0.06, energy_floor_pct=40.0, A_true_cols=None):
    """End-to-end Stage-1+Stage-2 separation of two real channels.

    Returns dict with separated time series, estimated columns, SSP features.
    If A_true_cols (N,2 complex) is given, recovery uses oracle columns (for the
    fundamental-limit scaling experiments).
    """
    f1, t1, Z1 = stft_channel(x1, fs, nperseg)
    f2, t2, Z2 = stft_channel(x2, fs, nperseg)
    freqs = f1
    feat, alpha, beta, sel, w, fsel = ssp_features_M2(
        Z1, Z2, freqs, feature=feature, rank1_thresh=rank1_thresh,
        energy_floor_pct=energy_floor_pct)
    if method == "peaks":
        cents, labels = cluster_columns_peaks(feat, n_sources, weights=w)
    else:
        cents, labels = cluster_columns_M2(feat, n_sources, method=method,
                                           weights=w, eps=eps,
                                           min_samples=min_samples)
    est_cols, delays = columns_from_features(cents, feature=feature)
    if A_true_cols is not None:
        rec_cols = A_true_cols
        rec_delays = None
    else:
        rec_cols = est_cols
        rec_delays = delays if feature == "delay" else None
    Zstack = np.stack([Z1, Z2], 0)
    S = recover_l1_M2(Zstack, rec_cols, delays=rec_delays, freqs=freqs)
    n = len(x1)
    srcs = []
    for k in range(rec_cols.shape[0]):
        s = istft_channel(S[k], fs, nperseg)
        if len(s) < n:
            s = np.pad(s, (0, n - len(s)))
        srcs.append(s[:n])
    return dict(sources=np.array(srcs), est_cols=est_cols, delays=delays,
                feat=feat, alpha=alpha, beta=beta, labels=labels, weights=w,
                fsel=fsel, freqs=freqs, Z=Zstack, S=S)
