"""
Compact SIREN surrogate for the PML amplification factor, in pure NumPy with
analytic back-propagation.  Maps normalised (w_hat, y_hat) -> (Re F, Im F).

Two activations are supported so we can run the same training twice:
  * 'sine' : SIREN, phi(z) = sin(omega0 * z), Sitzmann (2020) initialisation.
  * 'relu' : same-size ReLU control to expose spectral bias.

An optional physics-informed penalty enforces the exact low-frequency limit
F(w->0, y) -> 1 at collocation points just below the training band; this is the
small method-level addition over the reused surrogate of Zhang et al. (2026).
"""
import numpy as np


class MLP:
    def __init__(self, sizes, activation="sine", omega0=20.0, seed=0):
        self.sizes = sizes
        self.activation = activation
        self.omega0 = omega0
        rng = np.random.default_rng(seed)
        self.W, self.b = [], []
        L = len(sizes) - 1
        for i in range(L):
            fan_in, fan_out = sizes[i], sizes[i + 1]
            if activation == "sine":
                if i == 0:
                    lim = 1.0 / fan_in
                else:
                    lim = np.sqrt(6.0 / fan_in) / omega0
            else:  # relu (He-like)
                lim = np.sqrt(6.0 / fan_in)
            self.W.append(rng.uniform(-lim, lim, size=(fan_out, fan_in)))
            self.b.append(np.zeros(fan_out))

    # ---- forward / backward ----
    def _act(self, z, last_hidden=False):
        if self.activation == "sine":
            return np.sin(self.omega0 * z)
        else:
            return np.maximum(z, 0.0)

    def _dact(self, z):
        if self.activation == "sine":
            return self.omega0 * np.cos(self.omega0 * z)
        else:
            return (z > 0).astype(z.dtype)

    def forward(self, X, cache=False):
        a = X
        zs, as_ = [], [X]
        L = len(self.W)
        for i in range(L):
            z = a @ self.W[i].T + self.b[i]
            zs.append(z)
            if i < L - 1:
                a = self._act(z)
            else:
                a = z  # linear output
            as_.append(a)
        if cache:
            return a, zs, as_
        return a

    def grads(self, X, Y, sample_w=None):
        """MSE gradients.  sample_w optional per-row weight (for physics points)."""
        pred, zs, as_ = self.forward(X, cache=True)
        B = X.shape[0]
        L = len(self.W)
        if sample_w is None:
            dpred = (2.0 / (B * pred.shape[1])) * (pred - Y)
        else:
            sw = sample_w[:, None]
            dpred = (2.0 / (B * pred.shape[1])) * sw * (pred - Y)
        gW = [None] * L
        gb = [None] * L
        da = dpred
        for i in range(L - 1, -1, -1):
            if i == L - 1:
                dz = da  # linear output
            else:
                dz = da * self._dact(zs[i])
            gW[i] = dz.T @ as_[i]
            gb[i] = dz.sum(0)
            da = dz @ self.W[i]
        loss = np.mean((pred - Y) ** 2)
        return loss, gW, gb


class Adam:
    def __init__(self, params, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8):
        self.lr = lr
        self.b1, self.b2, self.eps = b1, b2, eps
        self.m = [np.zeros_like(p) for p in params]
        self.v = [np.zeros_like(p) for p in params]
        self.t = 0

    def step(self, params, grads, lr=None):
        if lr is None:
            lr = self.lr
        self.t += 1
        for i, (p, g) in enumerate(zip(params, grads)):
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g * g
            mhat = self.m[i] / (1 - self.b1 ** self.t)
            vhat = self.v[i] / (1 - self.b2 ** self.t)
            p -= lr * mhat / (np.sqrt(vhat) + self.eps)


class Surrogate:
    """Wraps an MLP plus input/output normalisation for F(w,y)."""

    def __init__(self, w_range, y_range, activation="sine", omega0=20.0,
                 hidden=(160, 160, 160), seed=0):
        self.w_range = w_range
        self.y_range = y_range
        self.net = MLP([2, *hidden, 2], activation=activation, omega0=omega0, seed=seed)
        self.y_mean = None
        self.y_std = None

    def _norm_in(self, w, y):
        w0, w1 = self.w_range
        y0, y1 = self.y_range
        wh = 2 * (w - w0) / (w1 - w0) - 1
        yh = 2 * (y - y0) / (y1 - y0) - 1
        return np.stack([wh, yh], axis=-1)

    def fit(self, w, y, F, iters=7000, lr0=2e-3, lr1=1e-5, phys_weight=0.0,
            batch_size=None, seed=0, verbose=False):
        X = self._norm_in(w, y)
        Y = np.stack([F.real, F.imag], axis=-1)
        self.y_mean = Y.mean(0)
        self.y_std = Y.std(0)
        Yn = (Y - self.y_mean) / self.y_std
        N = X.shape[0]
        rng = np.random.default_rng(seed)

        # physics collocation points (low-frequency limit F->1), normalised input
        if phys_weight > 0:
            yp = np.random.default_rng(1).uniform(self.y_range[0], self.y_range[1], 256)
            wp = np.full_like(yp, self.w_range[0] * 0.02)  # w ~ 0
            Xp = self._norm_in(wp, yp)
            Fp = np.stack([np.ones_like(yp), np.zeros_like(yp)], -1)  # F=1+0i
            Ypn = (Fp - self.y_mean) / self.y_std

        params = self.net.W + self.net.b
        opt = Adam(params, lr=lr0)
        for it in range(iters):
            lr = lr1 + 0.5 * (lr0 - lr1) * (1 + np.cos(np.pi * it / iters))
            if batch_size is None or batch_size >= N:
                Xb, Yb = X, Yn
            else:
                idx = rng.integers(0, N, batch_size)
                Xb, Yb = X[idx], Yn[idx]
            loss, gW, gb = self.net.grads(Xb, Yb)
            if phys_weight > 0:
                lp, gWp, gbp = self.net.grads(Xp, Ypn)
                gW = [g + phys_weight * gp for g, gp in zip(gW, gWp)]
                gb = [g + phys_weight * gp for g, gp in zip(gb, gbp)]
            opt.step(params, gW + gb, lr=lr)
            if verbose and it % 1000 == 0:
                print(f"  it {it:5d}  loss {loss:.3e}  lr {lr:.2e}")
        return self

    def predict(self, w, y):
        X = self._norm_in(np.asarray(w, float), np.asarray(y, float))
        out = self.net.forward(X)
        out = out * self.y_std + self.y_mean
        return out[..., 0] + 1j * out[..., 1]

    # save / load weights
    def state(self):
        return dict(W=[w.copy() for w in self.net.W],
                    b=[b.copy() for b in self.net.b],
                    y_mean=self.y_mean, y_std=self.y_std,
                    w_range=self.w_range, y_range=self.y_range,
                    omega0=self.net.omega0, activation=self.net.activation)

    def load(self, st):
        self.net.W = [w.copy() for w in st["W"]]
        self.net.b = [b.copy() for b in st["b"]]
        self.y_mean = st["y_mean"]
        self.y_std = st["y_std"]
        return self
