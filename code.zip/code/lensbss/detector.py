"""
Detector responses for realistic complex, frequency-dependent mixing.

For the dominant (2,2) mode a CBC produces, in detector a,
    h_a(f) = [F+_a (1+cos^2 i)/2 + i F^x_a cos i] * s(f) * exp(-2 pi i f tau_a)
           = c_a * s(f) * exp(-2 pi i f tau_a),
so the per-source mixing column is COMPLEX (through c_a) and, for widely
separated detectors, FREQUENCY-DEPENDENT (through the geometric delay tau_a).
This is the physical content the constant-real mixing of the original draft
omitted.

We model the ET triangle (three nested, co-located detectors rotated by 60 deg;
delays ~ negligible -> complex *constant* mixing) and Cosmic Explorer (an L-shaped
detector in the US; large baseline to ET -> strongly frequency-dependent mixing).
"""
import numpy as np

C = 299792458.0
REARTH = 6.371e6


def _loc_to_xyz(lat, lon):
    lat, lon = np.radians(lat), np.radians(lon)
    return REARTH * np.array([np.cos(lat) * np.cos(lon),
                              np.cos(lat) * np.sin(lon),
                              np.sin(lat)])


def _arm_vectors(lat, lon, azimuth_deg, opening_deg=90.0):
    """Unit arm vectors (East-North-Up local frame mapped to Earth XYZ)."""
    lat_r, lon_r = np.radians(lat), np.radians(lon)
    east = np.array([-np.sin(lon_r), np.cos(lon_r), 0.0])
    north = np.array([-np.sin(lat_r) * np.cos(lon_r),
                      -np.sin(lat_r) * np.sin(lon_r), np.cos(lat_r)])
    a = np.radians(azimuth_deg)
    b = np.radians(azimuth_deg + opening_deg)
    u = np.cos(a) * north + np.sin(a) * east     # arm 1 (azimuth from North)
    v = np.cos(b) * north + np.sin(b) * east     # arm 2
    return u, v


class Detector:
    def __init__(self, name, lat, lon, az, opening=90.0):
        self.name = name
        self.r = _loc_to_xyz(lat, lon)
        self.u, self.v = _arm_vectors(lat, lon, az, opening)
        # detector response tensor D = 1/2 (u u - v v)
        self.D = 0.5 * (np.outer(self.u, self.u) - np.outer(self.v, self.v))

    def antenna(self, ra, dec, psi):
        """F+, Fx for source (ra, dec) [rad] and polarisation psi [rad]."""
        # propagation direction (towards detector) and wave frame
        n = -np.array([np.cos(dec) * np.cos(ra),
                       np.cos(dec) * np.sin(ra),
                       np.sin(dec)])
        # basis in the plane transverse to n
        # use celestial north as reference
        zhat = np.array([0, 0, 1.0])
        ex = np.cross(zhat, -n)
        if np.linalg.norm(ex) < 1e-8:
            ex = np.array([1.0, 0, 0])
        ex = ex / np.linalg.norm(ex)
        ey = np.cross(-n, ex)
        ey = ey / np.linalg.norm(ey)
        # rotate by polarisation
        cp, sp = np.cos(psi), np.sin(psi)
        m = cp * ex + sp * ey
        nn = -sp * ex + cp * ey
        ep = np.outer(m, m) - np.outer(nn, nn)
        ec = np.outer(m, nn) + np.outer(nn, m)
        Fp = np.sum(self.D * ep)
        Fx = np.sum(self.D * ec)
        return Fp, Fx

    def delay_from_geocenter(self, ra, dec):
        n = -np.array([np.cos(dec) * np.cos(ra),
                       np.cos(dec) * np.sin(ra),
                       np.sin(dec)])
        return float(np.dot(n, self.r) / C)   # tau_a = n . r_a / c


def et_triangle():
    """Three nested ET detectors (co-located, arms rotated by 60 deg)."""
    lat, lon = 43.6, 10.5      # Sardinia-ish candidate site
    dets = []
    for k in range(3):
        dets.append(Detector(f"ET{k+1}", lat, lon, az=0 + 60 * k, opening=60.0))
    return dets


def cosmic_explorer():
    lat, lon = 40.8, -113.8    # Utah-ish candidate site
    return Detector("CE", lat, lon, az=45.0, opening=90.0)


def source_complex_factor(det, ra, dec, psi, iota):
    """c_a = F+ (1+cos^2 i)/2 + i Fx cos i  (complex, freq-independent part)."""
    Fp, Fx = det.antenna(ra, dec, psi)
    ci = np.cos(iota)
    return Fp * (1 + ci ** 2) / 2 + 1j * Fx * ci


def mixing_columns(dets, freqs, sources):
    """Build complex frequency-dependent mixing A(f) of shape [M, N, F].

    `sources` is a list of dicts with keys ra, dec, psi, iota.
    A[a,j,:] = c_{a,j} * exp(-2 pi i f tau_{a,j}).
    """
    M, N, Fn = len(dets), len(sources), len(freqs)
    A = np.zeros((M, N, Fn), complex)
    delays = np.zeros((M, N))
    cmat = np.zeros((M, N), complex)
    for a, det in enumerate(dets):
        for j, sp in enumerate(sources):
            c = source_complex_factor(det, sp["ra"], sp["dec"], sp["psi"], sp["iota"])
            tau = det.delay_from_geocenter(sp["ra"], sp["dec"])
            cmat[a, j] = c
            delays[a, j] = tau
            A[a, j, :] = c * np.exp(-2j * np.pi * np.asarray(freqs) * tau)
    return A, cmat, delays


# ---------- PSDs ----------
def psd_ET(f):
    """Smooth analytic ET-D-like ASD^2 (arbitrary normalisation)."""
    f = np.asarray(f, float)
    x = np.maximum(f, 1.0) / 200.0
    asd = 1.5e-25 * (0.9 * x ** -4.0 + 1.0 + 0.4 * x ** 2.0)
    return asd ** 2


def psd_CE(f):
    f = np.asarray(f, float)
    x = np.maximum(f, 1.0) / 200.0
    asd = 1.0e-25 * (0.7 * x ** -4.0 + 1.0 + 0.5 * x ** 2.0)
    return asd ** 2


def psd_aLIGO(f):
    f = np.asarray(f, float)
    x = np.maximum(f, 1.0) / 215.0
    asd = 3.0e-25 * (x ** -4.14 - 5 * x ** -2 + 111 * (1 - x ** 2 + 0.5 * x ** 4) / (1 + 0.5 * x ** 2))
    return np.abs(asd) ** 2 + (3e-25) ** 2
