"""
Compact-binary waveforms used as the intrinsic sources s_j(t).

We provide
  * taylorf2(...)  : frequency-domain restricted post-Newtonian (TaylorF2) inspiral
                     (Newtonian amplitude f^-7/6, phase to 3.5PN), tapered at ISCO.
  * imr(...)       : a lightweight phenomenological inspiral-merger-ringdown model
                     (TaylorF2 inspiral + an analytic merger and a damped-sinusoid
                     ringdown patterned on the frequency-domain PhenomD construction;
                     this is a reimplementation for *simulated* data, not the
                     calibrated LAL IMRPhenomD waveform).

The intrinsic source returned to the mixer is the detector-frame strain
A(f) e^{i Phi(f)} before antenna projection / inclination weighting.
"""
import numpy as np

TSUN = 4.925491025543576e-6  # G M_sun / c^3  [s]


def _eta_M(m1, m2):
    M = (m1 + m2) * TSUN          # total mass in seconds
    eta = m1 * m2 / (m1 + m2) ** 2
    return eta, M


def chirp_mass(m1, m2):
    return (m1 * m2) ** 0.6 / (m1 + m2) ** 0.2


def f_isco(m1, m2):
    M = (m1 + m2) * TSUN
    return 1.0 / (6 ** 1.5 * np.pi * M)


def taylorf2(f, m1, m2, tc=0.0, phic=0.0, flow=20.0, fhigh=None, taper=0.15):
    """Frequency-domain restricted-PN (TaylorF2) inspiral, complex h~(f).

    Phase to 3.5PN (point particle, non-spinning); Newtonian amplitude.
    The waveform is smoothly tapered to zero above ISCO over `taper` (fractional).
    """
    f = np.asarray(f, float)
    eta, M = _eta_M(m1, m2)
    fI = f_isco(m1, m2)
    if fhigh is None:
        fhigh = fI
    out = np.zeros(f.shape, complex)
    sel = (f >= flow) & (f <= fhigh * (1 + taper))
    fv = f[sel]
    v = (np.pi * M * fv) ** (1.0 / 3.0)
    v2, v3, v4, v5 = v * v, v ** 3, v ** 4, v ** 5
    # 3.5PN TaylorF2 phase coefficients (non-spinning)
    g = np.euler_gamma
    psi = (
        1.0
        + (3715.0 / 756.0 + 55.0 / 9.0 * eta) * v2
        - 16.0 * np.pi * v3
        + (15293365.0 / 508032.0 + 27145.0 / 504.0 * eta + 3085.0 / 72.0 * eta ** 2) * v4
        + (np.pi * (38645.0 / 756.0 - 65.0 / 9.0 * eta)) * (1 + 3 * np.log(v)) * v5
    )
    Psi = 2 * np.pi * fv * tc - phic - np.pi / 4 + (3.0 / (128.0 * eta * v5)) * psi
    amp = fv ** (-7.0 / 6.0)
    h = amp * np.exp(1j * Psi)
    # smooth taper above ISCO
    w = np.ones_like(fv)
    hi = fv > fI
    if np.any(hi):
        x = (fv[hi] - fI) / (fI * taper)
        w[hi] = 0.5 * (1 + np.cos(np.pi * np.clip(x, 0, 1)))
    out[sel] = h * w
    return out


def imr(f, m1, m2, tc=0.0, phic=0.0, flow=20.0):
    """Phenomenological IMR: TaylorF2 inspiral + analytic merger + damped ringdown.

    The ringdown QNM frequency and damping use the standard fits
       f_RD ~ (1 - 0.63 (1-a)^0.3) / (2 pi M_f),  Q ~ 2 (1-a)^-0.45,
    with a final mass/spin from simple non-spinning fits.  Patterned on PhenomD
    (Husa+2016; Khan+2016) but not the calibrated LAL model.
    """
    f = np.asarray(f, float)
    eta, M = _eta_M(m1, m2)
    fI = f_isco(m1, m2)
    # final mass / spin (rough non-spinning fits)
    Ef = 1.0 - eta * (0.057 + 0.498 * eta)        # radiated-energy-ish
    Mf = M * Ef
    af = np.clip(3.464 * eta - 3.51 * eta ** 2, 0.0, 0.95)  # final spin proxy
    f_rd = (1.0 - 0.63 * (1 - af) ** 0.3) / (2 * np.pi * Mf)
    Q = 2.0 * (1 - af) ** (-0.45)
    f_damp = f_rd / (2 * Q)

    out = np.zeros(f.shape, complex)
    # inspiral up to ISCO
    insp = taylorf2(f, m1, m2, tc=tc, phic=phic, flow=flow, fhigh=fI, taper=0.05)
    out += insp
    # phase continuity reference at ISCO
    sel_mr = (f > fI) & (f < 1.6 * f_rd)
    fv = f[sel_mr]
    if fv.size:
        # amplitude: smooth transition inspiral->Lorentzian ringdown
        amp_insp = fI ** (-7.0 / 6.0)
        lorentz = (f_damp ** 2) / ((fv - f_rd) ** 2 + f_damp ** 2)
        # blend
        x = np.clip((fv - fI) / (f_rd - fI + 1e-12), 0, 1)
        amp = amp_insp * ((1 - x) ** 2 + x * lorentz * (fI / f_rd) ** (-7.0 / 6.0) * 0.0
                          + x * lorentz)
        # continue the inspiral phase roughly linearly (group-delay continuous)
        v = (np.pi * M * fv) ** (1.0 / 3.0)
        Psi = 2 * np.pi * fv * tc - phic - np.pi / 4 + (3.0 / (128.0 * eta * v ** 5))
        out[sel_mr] = amp * np.exp(1j * Psi)
    return out


def to_time(hf, n, fs):
    """Inverse rFFT of a one-sided spectrum hf (length n//2+1) to a real series."""
    return np.fft.irfft(hf, n=n) * fs


def make_source_td(m1, m2, n, fs, flow=20.0, kind="pn", tc=None, phic=0.0, seed=0):
    """Return a unit-RMS time-domain intrinsic source and its rFFT frequencies."""
    freqs = np.fft.rfftfreq(n, d=1.0 / fs)
    if tc is None:
        tc = 0.85 * n / fs  # place merger near end of segment
    if kind == "pn":
        hf = taylorf2(freqs, m1, m2, tc=tc, phic=phic, flow=flow)
    else:
        hf = imr(freqs, m1, m2, tc=tc, phic=phic, flow=flow)
    s = to_time(hf, n, fs)
    s = s - s.mean()
    rms = np.sqrt(np.mean(s ** 2)) + 1e-30
    return s / rms, freqs, hf / rms
