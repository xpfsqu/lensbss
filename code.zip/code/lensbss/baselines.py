"""
Baseline separation / inference methods for honest comparison.

  * fastica_separate : sklearn FastICA (requires M>=N; included to show it cannot
                       represent the underdetermined case).
  * duet_separate    : classical degenerate-unmixing TF baseline (amplitude-delay
                       histogram clustering + binary TF masks).
  * sequential_subtract : a CLEAN-like greedy time-domain subtraction baseline
                       (matched-filter the loudest template, subtract, repeat).
  * raw_mixture_lensfit / oracle_clean_lensfit : run the lensing fit on the raw
                       mixed channel and on the clean (unseparated) lensed source,
                       bracketing the value the separation adds.
"""
import numpy as np
from scipy.signal import stft as _stft, istft as _istft
from .metrics import sdr
from .inference import chi2_grid, best_fit


def fastica_separate(X, n_components=2, seed=0):
    """X : (M, T) real mixtures.  Returns (n_components, T) estimated sources."""
    from sklearn.decomposition import FastICA
    ica = FastICA(n_components=n_components, random_state=seed, max_iter=500,
                  whiten="unit-variance")
    S = ica.fit_transform(X.T).T
    return S


def duet_separate(x1, x2, n_sources, fs, nperseg=256):
    """Classical DUET: cluster TF cells in the (symmetric amplitude, delay) plane,
    assign each cell to the nearest peak, reconstruct by binary masking."""
    noverlap = nperseg * 3 // 4
    f, t, Z1 = _stft(x1, fs=fs, nperseg=nperseg, noverlap=noverlap, window="hann",
                     boundary=None)
    _, _, Z2 = _stft(x2, fs=fs, nperseg=nperseg, noverlap=noverlap, window="hann",
                     boundary=None)
    P = np.abs(Z1) ** 2 + np.abs(Z2) ** 2
    eps = 1e-12
    R = (np.abs(Z2) + eps) / (np.abs(Z1) + eps)
    a = R - 1.0 / R                                       # symmetric amplitude
    fidx = np.broadcast_to(f[:, None], Z1.shape)
    delta = -np.angle(Z2 / (Z1 + eps)) / (2 * np.pi * np.maximum(fidx, 1.0))
    thr = np.percentile(P, 80.0)
    sel = P >= thr
    feats = np.column_stack([a[sel], delta[sel]])
    wts = P[sel]
    from sklearn.cluster import KMeans
    fmu, fsd = feats.mean(0), feats.std(0) + 1e-12
    km = KMeans(n_clusters=n_sources, n_init=10, random_state=0).fit(
        (feats - fmu) / fsd, sample_weight=wts)
    centers = km.cluster_centers_ * fsd + fmu
    # assign every TF cell to nearest center, binary mask
    A = a.reshape(-1)
    D = delta.reshape(-1)
    feat_all = np.column_stack([A, D])
    d2 = ((feat_all[:, None, :] - centers[None, :, :]) ** 2).sum(-1)
    lab = np.argmin(d2, axis=1).reshape(Z1.shape)
    srcs = []
    n = len(x1)
    for k in range(n_sources):
        mask = (lab == k).astype(float)
        Zk = mask * Z1   # reconstruct from channel 1
        _, sk = _istft(Zk, fs=fs, nperseg=nperseg, noverlap=noverlap,
                       window="hann", boundary=None)
        if len(sk) < n:
            sk = np.pad(sk, (0, n - len(sk)))
        srcs.append(sk[:n])
    return np.array(srcs)


def sequential_subtract(x, templates, fs, n_iter=3):
    """Greedy CLEAN-like subtraction: for each of n_iter passes, find the template
    with the largest matched amplitude in the residual, fit its amplitude+phase by
    least squares, subtract.  Returns the list of recovered components."""
    resid = x.astype(float).copy()
    comps = []
    used = []
    for _ in range(n_iter):
        best_k, best_amp, best_fit_ts = None, -np.inf, None
        for k, h in enumerate(templates):
            if k in used:
                continue
            # least-squares amplitude of real template h in resid
            denom = np.dot(h, h) + 1e-30
            amp = np.dot(resid, h) / denom
            power = amp ** 2 * denom
            if power > best_amp:
                best_amp, best_k, best_fit_ts = power, k, amp * h
        if best_k is None:
            break
        comps.append(best_fit_ts)
        used.append(best_k)
        resid = resid - best_fit_ts
    return comps, used, resid


def raw_mixture_lensfit(x_channel, hf_template, fs, MLz_grid, y_grid, surrogate,
                        psd=None):
    """Run the lensing fit directly on a raw mixed channel (no separation)."""
    n = len(x_channel)
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    Sf = np.fft.rfft(x_channel) / fs
    chi2 = chi2_grid(Sf, hf_template, freqs, MLz_grid, y_grid, surrogate, psd=psd)
    return best_fit(chi2, MLz_grid, y_grid), chi2


def oracle_clean_lensfit(clean_lensed_td, hf_template, fs, MLz_grid, y_grid,
                         surrogate, psd=None):
    """Run the lensing fit on the clean (unseparated) lensed source: the best case."""
    n = len(clean_lensed_td)
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    Sf = np.fft.rfft(clean_lensed_td) / fs
    chi2 = chi2_grid(Sf, hf_template, freqs, MLz_grid, y_grid, surrogate, psd=psd)
    return best_fit(chi2, MLz_grid, y_grid), chi2
