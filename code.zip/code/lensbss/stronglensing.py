"""
Strong lensing: separating coherent multiple images.

The crucial physical fact (which a generic-mixture treatment misses) is that the
multiple images of one strongly lensed source share the SAME sky position, hence
the SAME antenna pattern and the SAME inter-detector delay.  Their mixing columns
are therefore COLLINEAR -- they differ only by a complex scalar (magnification
ratio and Morse phase) and an arrival-time offset.  A Stage-1 clustering that
looks for distinct directions in the mixing space sees a SINGLE direction and
cannot separate the images by geometry.

This module
  (1) builds two images with an identical complex column (collinear),
  (2) shows that direction clustering collapses them to one cluster, and
  (3) recovers them with a delay-aware coherent two-image model: along the shared
      direction the data are s(t) + r e^{i phi_M} s(t - dt); we estimate the delay
      dt from the autocorrelation/cepstrum and solve the two-path (echo) model in
      the frequency domain for the individual images.
"""
import numpy as np


def make_lensed_images(s_td, fs, mag_ratio=0.6, dt=0.45, morse_phase=-np.pi / 2):
    """Return (image1, image2) time series for a type-I and type-II image of the
    same intrinsic source s_td.  image2 is delayed by dt, scaled by sqrt(mag_ratio)
    and carries a Morse phase (applied as a Hilbert/quadrature rotation)."""
    n = len(s_td)
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    Sf = np.fft.rfft(s_td)
    img1 = s_td.copy()
    # image 2: magnitude sqrt(mag_ratio), delay dt, Morse phase as constant
    # phase rotation of the analytic signal
    phase = np.exp(-2j * np.pi * freqs * dt) * np.exp(1j * morse_phase)
    img2 = np.fft.irfft(Sf * np.sqrt(mag_ratio) * phase, n=n)
    return img1, img2


def estimate_delay(y, fs, dt_min=0.02, dt_max=1.0):
    """Estimate the echo delay of y(t) = s(t) + r s(t-dt) via the autocorrelation
    of the log-spectrum (real cepstrum), robust to the unknown source shape."""
    n = len(y)
    Y = np.fft.rfft(y)
    logmag = np.log(np.abs(Y) + 1e-12)
    # cepstrum: ifft of log-magnitude shows a peak at the echo delay (in samples)
    ceps = np.fft.irfft(logmag, n=n)
    q = np.arange(n) / fs
    lo = int(dt_min * fs)
    hi = min(int(dt_max * fs), n // 2)
    k = lo + np.argmax(np.abs(ceps[lo:hi]))
    return q[k], ceps


def deconvolve_two_image(y, fs, dt, ridge=1e-3):
    """Given the single combined channel y(t) = img1(t) + img2(t) with
    img2 = r e^{i phiM} img1(t-dt), solve for img1 and img2 in the frequency domain.

    We model Y(f) = H1(f) S(f) with H1 = 1 + g exp(-2 pi i f dt); estimating the
    complex echo gain g by least squares over the band, then img1 = irfft(Y/H1),
    img2 = y - img1.
    """
    n = len(y)
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    Y = np.fft.rfft(y)
    # estimate complex gain g minimizing |Y - (1 + g e^{-i w dt}) S|; but S unknown.
    # Use the relation on the *combined* signal directly: the echo kernel is
    # H = 1 + g z, z = exp(-2 pi i f dt). We estimate g by fitting the
    # autocorrelation: argmax over g of spectral flatness of Y/(1+g z).
    z = np.exp(-2j * np.pi * freqs * dt)
    # grid search over g magnitude and Morse phase (4 discrete Morse phases)
    best = None
    for r in np.linspace(0.2, 0.95, 16):
        for phi in [0.0, -np.pi / 2, np.pi / 2, np.pi]:
            g = np.sqrt(r) * np.exp(1j * phi)
            H = 1 + g * z
            S = Y / (H + ridge)
            # whiteness/sparsity proxy: minimize L1 of the implied source cepstrum
            c = np.fft.irfft(np.log(np.abs(S) + 1e-9), n=n)
            score = np.sum(np.abs(c[int(0.02 * fs):n // 2]))
            if best is None or score < best[0]:
                best = (score, g, H, S)
    _, g, H, S = best
    img1 = np.fft.irfft(S, n=n)
    img2 = y - img1
    return img1, img2, g


def direction_spread(alpha, beta, weights=None):
    """Diagnostic: angular spread (deg) of SSP directions; collinear images give a
    single tight mode, unrelated sources give well-separated modes."""
    if weights is None:
        weights = np.ones_like(alpha)
    am = np.average(alpha, weights=weights)
    return float(np.degrees(np.sqrt(np.average((alpha - am) ** 2, weights=weights))))


def delay_ampl_from_template(combined, template_td, fs, dt_min=0.05, dt_max=1.0,
                             flow=20.0, psd_func=None):
    """Template-informed two-image recovery: matched-filter the combined stream
    with the binary template, find the two strongest peaks -> arrival-time delay,
    relative magnification, and (coarse) Morse phase.  Robust for a candidate
    whose intrinsic waveform is known."""
    n = len(combined)
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    Y = np.fft.rfft(combined)
    H = np.fft.rfft(template_td)
    if psd_func is not None:
        psd = psd_func(freqs)
        wts = np.where((freqs >= flow) & (psd > 0), 1.0 / psd, 0.0)
    else:
        wts = (freqs >= flow).astype(float)
    z = np.fft.irfft(wts * Y * np.conj(H), n=n)          # complex MF (analytic)
    zc = np.fft.irfft(wts * Y * np.conj(H) * 1j, n=n)
    env = np.sqrt(z ** 2 + zc ** 2)                       # MF envelope
    # primary peak
    k1 = int(np.argmax(env))
    lo, hi = int(dt_min * fs), int(dt_max * fs)
    # search secondary peak at lag >= dt_min from primary (both directions)
    mask = np.ones(n, bool)
    for k in range(max(0, k1 - lo), min(n, k1 + lo)):
        mask[k] = False
    cand = np.where(mask)[0]
    cand = cand[(np.abs(cand - k1) >= lo) & (np.abs(cand - k1) <= hi)]
    k2 = cand[np.argmax(env[cand])]
    t1, t2 = sorted([k1 / fs, k2 / fs])
    dt = t2 - t1
    amp_ratio = env[max(k1, k2, key=lambda k: 0)] # placeholder
    amp_ratio = env[k2] / (env[k1] + 1e-30)
    # relative phase at the two peaks (Morse proxy)
    ph1 = np.arctan2(zc[k1], z[k1])
    ph2 = np.arctan2(zc[k2], z[k2])
    return dt, float(amp_ratio), float(ph2 - ph1), env
