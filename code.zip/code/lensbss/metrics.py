"""Quality metrics."""
import numpy as np


def sdr(true, est):
    """Scale-invariant SDR (dB): BSS recovers up to a scale, so we fit the
    optimal real scale before measuring distortion."""
    true = np.asarray(true, float)
    est = np.asarray(est, float)
    a = np.dot(est, true) / (np.dot(true, true) + 1e-30)
    # align scale of est to true
    s = np.dot(true, est) / (np.dot(est, est) + 1e-30)
    est_s = s * est
    num = np.sum(true ** 2)
    den = np.sum((true - est_s) ** 2) + 1e-30
    return 10 * np.log10(num / den + 1e-30)


def corr(true, est):
    true = true - true.mean()
    est = est - est.mean()
    return float(np.dot(true, est) / (np.linalg.norm(true) * np.linalg.norm(est) + 1e-30))


def matched_filter_snr(h, psd, fs, flow=20.0, fhigh=None):
    """Optimal matched-filter SNR of time series h against one-sided psd(f)."""
    n = len(h)
    hf = np.fft.rfft(h) / fs
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    if fhigh is None:
        fhigh = fs / 2
    df = freqs[1] - freqs[0]
    sel = (freqs >= flow) & (freqs <= fhigh) & (psd > 0)
    snr2 = 4 * df * np.sum(np.abs(hf[sel]) ** 2 / psd[sel])
    return float(np.sqrt(np.real(snr2)))


def complex_dir_error_deg(a_true, a_est):
    """Geodesic distance on complex projective space between two complex unit
    column directions (degrees).  d = arccos(|<a,b>|/(|a||b|))."""
    a = np.asarray(a_true, complex).ravel()
    b = np.asarray(a_est, complex).ravel()
    c = np.abs(np.vdot(a, b)) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-30)
    return float(np.degrees(np.arccos(np.clip(c, 0, 1))))


def angle_error_deg(a_true, a_est):
    """Real 2D direction angle error (degrees)."""
    t = np.arctan2(a_true[1], a_true[0])
    e = np.arctan2(a_est[1], a_est[0])
    d = np.abs(t - e)
    return float(np.degrees(min(d, np.pi - d)))


def reconstruct_quadratures(Zk, fs, nperseg, n):
    """Return the two real reconstructions (a, b) = istft(Zk), istft(i Zk) so that
    the global-phase family of real reconstructions is cos(psi) a + sin(psi) b.

    Complex mixing of a real source leaves an unobservable global (analytic)
    phase on each recovered component; these two quadratures span that freedom.
    """
    from scipy.signal import istft as _istft
    noverlap = nperseg * 3 // 4
    _, a = _istft(Zk, fs=fs, nperseg=nperseg, noverlap=noverlap, window="hann",
                  boundary=True)
    _, b = _istft(1j * Zk, fs=fs, nperseg=nperseg, noverlap=noverlap,
                  window="hann", boundary=True)
    a = np.pad(a, (0, max(0, n - len(a))))[:n]
    b = np.pad(b, (0, max(0, n - len(b))))[:n]
    return a, b


def sdr_phase_aligned(x_true, Zk, fs, nperseg):
    """Scale- and global-phase-invariant SDR for a complex-mixing reconstruction.

    Optimises the analytic global phase psi (standard in complex/anechoic BSS)
    before measuring distortion against the real source x_true.
    """
    n = len(x_true)
    a, b = reconstruct_quadratures(Zk, fs, nperseg, n)
    psi = np.arctan2(np.dot(x_true, b), np.dot(x_true, a))
    aligned = np.cos(psi) * a + np.sin(psi) * b
    return sdr(x_true, aligned), aligned
