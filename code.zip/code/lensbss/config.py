"""Central configuration for all experiments (single source of truth so figures
and the manuscript stay consistent)."""
import os
import numpy as np

FS = 2048.0
DUR = 4.0
N = int(FS * DUR)
FLOW = 20.0
NPERSEG = 512

# fiducial three-source mixture (chirp masses well separated; the microlensed
# source is chosen to be both well separated and to carry wave-optics content).
# (m1, m2, theta_real, lensed?)
SOURCES = [
    dict(m1=19, m2=17, theta=0.35, lensed=True,  MLz=500.0, y=0.30),  # microlensed
    dict(m1=33, m2=30, theta=0.95, lensed=False),                      # high mass
    dict(m1=11, m2=9,  theta=1.45, lensed=False),                      # low mass
]

# locked Stage-1 hyper-parameters
SEP = dict(nperseg=NPERSEG, feature="phase", method="dbscan",
           eps=0.16, min_samples=15, energy_floor_pct=25, rank1_thresh=0.05)

# microlensing fiducial
MLZ_FID = 500.0
Y_FID = 0.30

# inference grid
MLZ_GRID = np.linspace(150.0, 1100.0, 96)
Y_GRID = np.linspace(0.08, 1.20, 90)

ROOT = "/home/claude/proj"
RESULTS = os.path.join(ROOT, "results")
FIGDIR = "/home/claude/paper/figs"
os.makedirs(RESULTS, exist_ok=True)
os.makedirs(FIGDIR, exist_ok=True)

# matplotlib style
def setup_mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "figure.dpi": 130, "savefig.dpi": 160, "font.size": 9,
        "axes.titlesize": 9, "axes.labelsize": 9, "legend.fontsize": 7.5,
        "xtick.labelsize": 8, "ytick.labelsize": 8, "lines.linewidth": 1.3,
        "axes.grid": True, "grid.alpha": 0.25, "figure.autolayout": False,
        "axes.prop_cycle": plt.cycler(color=[
            "#2b6cb0", "#c0392b", "#27865c", "#8e44ad", "#d68910", "#16a085"]),
    })
    return plt
