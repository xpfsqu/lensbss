"""Run the fiducial complex-mixing experiment: separation, lens point estimate,
MCMC posterior; cache everything needed for figures 3,4,5,9,10 and the text."""
import os, json, pickle, time
import numpy as np
import sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import experiment as ex, config as C, inference as inf, metrics as mx
from lensbss import separation as sep
from lensbss.siren import Surrogate
from lensbss.amplification import w_of_f

R = C.RESULTS
with open(os.path.join(R, "siren_sine.pkl"), "rb") as f:
    st = pickle.load(f)
sur = Surrogate(st["w_range"], st["y_range"], activation="sine", omega0=st["omega0"])
sur.load(st)

fs, n = C.FS, C.N
res = {}

# ---- fiducial complex-ET separation ----
sc = ex.fiducial_scenario(snr_db=34.0, seed=0, mixing="complex_et")
S, meta, Xn = sc["S"], sc["meta"], sc["Xn"]
cols_true = sc["cols_true"]
out = sep.separate_M2(Xn[0], Xn[1], 3, fs, **C.SEP)
perm, sdrs, aligned = ex.best_match_sdr_pa(S, out["S"], fs, C.NPERSEG)
corrs = [mx.corr(S[i], aligned[i]) for i in range(3)]
# CP1 column errors (match est to true)
col_err = []
for i in range(3):
    errs = [mx.complex_dir_error_deg(cols_true[i], e) for e in out["est_cols"]]
    col_err.append(min(errs))
res["fiducial"] = dict(sdr=list(map(float, sdrs)), mean_sdr=float(np.mean(sdrs)),
                       corr=list(map(float, corrs)), perm=list(map(int, perm)),
                       col_err_deg=list(map(float, col_err)))
print("FIDUCIAL complex-ET: SDR", np.round(sdrs, 2), "mean", round(np.mean(sdrs), 2),
      "corr", np.round(corrs, 3), "col_err(deg)", np.round(col_err, 2))

# ---- lensing point estimate (separated vs clean oracle) ----
m0 = meta[0]; freqs = m0["freqs"]; hf = m0["hf"]
sl_rec = aligned[0]
Sf_rec = np.fft.rfft(sl_rec) / fs
chi2 = inf.chi2_grid(Sf_rec, hf, freqs, C.MLZ_GRID, C.Y_GRID, sur)
MLz_hat, y_hat, idx = inf.best_fit(chi2, C.MLZ_GRID, C.Y_GRID)
Sf_clean = np.fft.rfft(S[0]) / fs
chi2c = inf.chi2_grid(Sf_clean, hf, freqs, C.MLZ_GRID, C.Y_GRID, sur)
MLzc, yc, idxc = inf.best_fit(chi2c, C.MLZ_GRID, C.Y_GRID)
res["lensfit"] = dict(MLz_sep=float(MLz_hat), y_sep=float(y_hat),
                      MLz_clean=float(MLzc), y_clean=float(yc),
                      MLz_true=float(m0["MLz"]), y_true=float(m0["y"]))
print(f"LENS FIT separated ({MLz_hat:.0f},{y_hat:.3f}) clean ({MLzc:.0f},{yc:.3f}) "
      f"true ({m0['MLz']:.0f},{m0['y']:.2f})")

# empirical |F| from separated data (per-band ratio to template), for fig5
w_arr = w_of_f(freqs, m0["MLz"])
band = (w_arr <= 30) & (freqs >= 20) & (w_arr > 1e-3)
Fmod = sur.predict(w_arr[band], np.full(band.sum(), y_hat))
# scale
modv = Fmod * hf[band]
A = np.sum(np.conj(modv) * Sf_rec[band]) / (np.sum(np.abs(modv) ** 2) + 1e-30)
Femp = Sf_rec[band] / (A * hf[band] + 1e-30)

# ---- MCMC posterior (surrogate likelihood), multi-chain R-hat ----
t0 = time.time()
chains = []
accs = []
starts = [(MLz_hat, y_hat), (MLz_hat * 0.85, min(y_hat * 1.3, 1.0)),
          (MLz_hat * 1.15, max(y_hat * 0.7, 0.1)), (550, 0.25)]
for ci, (m0s, y0s) in enumerate(starts):
    ch, acc = inf.mh_sample(Sf_rec, hf, freqs, sur, m0s, y0s, n_samples=8000,
                            step_MLz=18.0, step_y=0.025, seed=10 + ci)
    chains.append(ch); accs.append(acc)
mcmc_time = time.time() - t0
allchain = np.vstack(chains)
rhat_M = inf.gelman_rubin([c[:, 0:1] for c in chains])
rhat_y = inf.gelman_rubin([c[:, 1:2] for c in chains])
med_M, med_y = np.median(allchain[:, 0]), np.median(allchain[:, 1])
q_M = np.percentile(allchain[:, 0], [5, 95])
q_y = np.percentile(allchain[:, 1], [5, 95])
res["mcmc"] = dict(med_MLz=float(med_M), med_y=float(med_y),
                   ci_MLz=list(map(float, q_M)), ci_y=list(map(float, q_y)),
                   rhat_MLz=float(rhat_M), rhat_y=float(rhat_y),
                   accept=float(np.mean(accs)), time_s=float(mcmc_time),
                   nsamp=int(allchain.shape[0]))
print(f"MCMC med ({med_M:.0f},{med_y:.3f}) 90% MLz[{q_M[0]:.0f},{q_M[1]:.0f}] "
      f"y[{q_y[0]:.3f},{q_y[1]:.3f}] Rhat({rhat_M:.3f},{rhat_y:.3f}) "
      f"acc {np.mean(accs):.2f} time {mcmc_time:.1f}s ({allchain.shape[0]} samples)")

# ---- save arrays for figures ----
np.savez(os.path.join(R, "main_arrays.npz"),
         S=S, aligned=aligned, Xn=Xn,
         est_cols_re=out["est_cols"].real, est_cols_im=out["est_cols"].imag,
         cols_true_re=cols_true.real, cols_true_im=cols_true.imag,
         alpha=out["alpha"], beta=out["beta"], weights=out["weights"],
         chi2=chi2, chi2c=chi2c, MLZ_GRID=C.MLZ_GRID, Y_GRID=C.Y_GRID,
         freqs=freqs, hf=hf, Femp_re=Femp.real, Femp_im=Femp.imag,
         band=band, Ftrue_re=m0["F"].real, Ftrue_im=m0["F"].imag,
         chain=allchain, idx=np.array(idx), idxc=np.array(idxc),
         perm=np.array(perm))

with open(os.path.join(R, "main.json"), "w") as f:
    json.dump(res, f, indent=2)
print("saved main_arrays.npz and main.json")
