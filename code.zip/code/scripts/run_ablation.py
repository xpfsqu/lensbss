"""Whitening-sensitivity ablation + glitch robustness (K-means vs DBSCAN)."""
import os, json
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C, separation as sep, metrics as mx, experiment as ex
from lensbss.detector import psd_ET, psd_aLIGO

R = C.RESULTS
fs, n = C.FS, C.N
ff = np.fft.rfftfreq(n, 1.0 / fs)
S, meta = ex.make_sources()
thetas = [sp["theta"] for sp in C.SOURCES]
X, cols = ex.mix_real(S, thetas)

def psd_wrong_slope(f):
    """Deliberately wrong low-frequency slope (f^-2.4 ASD vs ET's ~f^-4)."""
    f = np.asarray(f, float)
    x = np.maximum(f, 1.0) / 200.0
    asd = 1.5e-25 * (0.9 * x ** -2.4 + 1.0 + 0.4 * x ** 2.0)
    return asd ** 2

def whiten_sources(psd_func):
    return np.array([sep.whiten(S[j], psd_func, fs) for j in range(3)])

def mean_sdr(Xn, whiten_psd, target_psd):
    if whiten_psd is not None:
        x1 = sep.whiten(Xn[0], whiten_psd, fs); x2 = sep.whiten(Xn[1], whiten_psd, fs)
    else:
        x1, x2 = Xn[0], Xn[1]
    target = whiten_sources(target_psd) if target_psd is not None else S
    out = sep.separate_M2(x1, x2, 3, fs, **C.SEP)
    _, sdrs, _ = ex.best_match_sdr_pa(target, out["S"], fs, C.NPERSEG)
    return float(np.mean(sdrs))

SNRS = [30, 18, 10, 6]
NREAL = 5
variants = {"none": None, "ideal_ET": psd_ET, "aLIGO_mismatch": psd_aLIGO,
            "wrong_slope": psd_wrong_slope}
# each variant measured in its OWN whitened domain (fair: isolates how well
# separation works after that whitening, not a cross-domain mismatch)
res = {"snrs": SNRS, "nreal": NREAL, "curves": {k: [] for k in variants}}
for snr in SNRS:
    acc = {k: [] for k in variants}
    for r in range(NREAL):
        Xn, _ = ex.add_noise(X, snr, fs, psd_func=psd_ET, seed=200 + r)
        for k, pf in variants.items():
            acc[k].append(mean_sdr(Xn, pf, pf))
    for k in variants:
        res["curves"][k].append(float(np.mean(acc[k])))
    with open(os.path.join(R, "ablation.json"), "w") as f:
        json.dump(res, f, indent=2)
    print(f"SNR {snr:>2}dB: " + " | ".join(f"{k} {np.mean(acc[k]):.1f}" for k in variants))

# ---- glitch test: K-means vs DBSCAN mixing-matrix angle error ----
def sine_gaussian(t, t0, f0, Q, amp):
    tau = Q / (2 * np.pi * f0)
    return amp * np.exp(-((t - t0) ** 2) / (2 * tau ** 2)) * np.sin(2 * np.pi * f0 * (t - t0))

t = np.arange(n) / fs
Xn, _ = ex.add_noise(X, 30, fs, psd_func=psd_ET, seed=7)

def angle_errs(Xc):
    x1 = sep.whiten(Xc[0], psd_ET, fs); x2 = sep.whiten(Xc[1], psd_ET, fs)
    f1, _, Z1 = sep.stft_channel(x1, fs, C.NPERSEG)
    _, _, Z2 = sep.stft_channel(x2, fs, C.NPERSEG)
    feat, alpha, beta, selm, w, fselv = sep.ssp_features_M2(
        Z1, Z2, f1, feature="phase", rank1_thresh=C.SEP["rank1_thresh"],
        energy_floor_pct=C.SEP["energy_floor_pct"])
    true_alphas = np.array(sorted(thetas))
    e = {}
    for method in ["kmeans", "dbscan"]:
        cents, _ = sep.cluster_columns_M2(feat, 3, method=method, weights=w,
                                          eps=C.SEP["eps"], min_samples=C.SEP["min_samples"])
        est = np.array(sorted([c[0] for c in cents]))
        e[method] = float(np.degrees(np.max(np.abs(est - true_alphas))))
    return e, (Z1, f1, alpha, beta, fselv, selm)

base, _ = angle_errs(Xn)
rms0 = np.sqrt(np.mean(Xn[0] ** 2))
g = (sine_gaussian(t, 1.1, 70, 5, 1.6 * rms0)
     + sine_gaussian(t, 2.7, 120, 5, 1.4 * rms0))
Xg = Xn.copy(); Xg[0] = Xg[0] + g
errs, spec = angle_errs(Xg)
res["glitch"] = dict(baseline_kmeans=base["kmeans"], baseline_dbscan=base["dbscan"],
                     kmeans_max_angle_err_deg=errs["kmeans"],
                     dbscan_max_angle_err_deg=errs["dbscan"])
with open(os.path.join(R, "ablation.json"), "w") as f:
    json.dump(res, f, indent=2)
print(f"glitch baseline: K-means {base['kmeans']:.2f} DBSCAN {base['dbscan']:.2f} deg")
print(f"with glitches:  K-means {errs['kmeans']:.2f} DBSCAN {errs['dbscan']:.2f} deg")
Z1, f1, alpha, beta, fselv, selm = spec
np.savez(os.path.join(R, "glitch_spec.npz"),
         Z1=Z1, freqs=f1, alpha=alpha, beta=beta, fsel=fselv)
print("saved ablation.json + glitch_spec.npz")
