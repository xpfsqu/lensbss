"""Strong-lensing experiment (reviewer's central fix).

Two images of one strongly lensed source share the SAME sky position -> the SAME
complex mixing column (collinear).  We show:
  (1) Stage-1 direction clustering collapses the two images into ONE cluster, so
      plain UBSS cannot separate them by mixing geometry (identifiability fig).
  (2) A delay-aware coherent stage recovers the two images and their time delay.
"""
import os, json
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C, detector as det, waveforms as wf, separation as sep
from lensbss import stronglensing as sl, metrics as mx, experiment as ex

R = C.RESULTS
fs, n = C.FS, C.N
ff = np.fft.rfftfreq(n, 1.0 / fs)
res = {}

# --- intrinsic source + two coherent images (same sky position) ---
s0, _, _ = wf.make_source_td(30, 27, n, fs, seed=7)   # the lensed binary
DT, MAG, MORSE = 0.45, 0.6, -np.pi / 2
img1, img2 = sl.make_lensed_images(s0, fs, mag_ratio=MAG, dt=DT, morse_phase=MORSE)
# unrelated binary at a DIFFERENT sky position
s_un, _, _ = wf.make_source_td(14, 12, n, fs, seed=8)

ets = det.et_triangle()[:2]
sky_img = dict(ra=1.0, dec=0.2, psi=0.5, iota=0.6)     # shared by both images
sky_un = dict(ra=4.0, dec=-0.7, psi=1.0, iota=1.1)
A_img, c_img, _ = det.mixing_columns(ets, ff, [sky_img])
A_un, c_un, _ = det.mixing_columns(ets, ff, [sky_un])
col_img = (c_img[:, 0] / np.linalg.norm(c_img[:, 0]))
col_un = (c_un[:, 0] / np.linalg.norm(c_un[:, 0]))
print("image column (alpha,beta) = (%.3f,%.3f); unrelated = (%.3f,%.3f)" % (
    np.arctan2(abs(col_img[1]), abs(col_img[0])), np.angle(col_img[1] / col_img[0]),
    np.arctan2(abs(col_un[1]), abs(col_un[0])), np.angle(col_un[1] / col_un[0])))
res["columns"] = dict(
    img_alpha=float(np.arctan2(abs(col_img[1]), abs(col_img[0]))),
    img_beta=float(np.angle(col_img[1] / col_img[0])),
    un_alpha=float(np.arctan2(abs(col_un[1]), abs(col_un[0]))),
    un_beta=float(np.angle(col_un[1] / col_un[0])),
    cp1_sep_deg=float(mx.complex_dir_error_deg(col_img, col_un)))

# combined image stream along col_img + unrelated along col_un -> 2 channels
img_sum = img1 + img2
X = np.zeros((2, n))
for a in range(2):
    X[a] = (np.fft.irfft(c_img[a, 0] * np.fft.rfft(img_sum), n=n)
            + np.fft.irfft(c_un[a, 0] * np.fft.rfft(s_un), n=n))
Xn, _ = ex.add_noise(X, 36.0, fs, seed=3)

# --- Stage 1 on the full mixture: how many distinct directions? ---
f1, t1, Z1 = sep.stft_channel(Xn[0], fs, C.NPERSEG)
_, _, Z2 = sep.stft_channel(Xn[1], fs, C.NPERSEG)
feat, alpha, beta, selm, w, fselv = sep.ssp_features_M2(
    Z1, Z2, f1, feature="phase", rank1_thresh=C.SEP["rank1_thresh"],
    energy_floor_pct=C.SEP["energy_floor_pct"])
# cluster assuming we (wrongly) ask for 3 geometric sources
cents3, lab3 = sep.cluster_columns_M2(feat, 3, method="kmeans", weights=w)
cents2, lab2 = sep.cluster_columns_M2(feat, 2, method="kmeans", weights=w)
# the two images share a column: their CP1 separation is ~0, while each is far
# from the unrelated source.  Quantify the geometric degeneracy directly.
res["identifiability"] = dict(
    img_img_cp1_deg=0.0,
    img_unrelated_cp1_deg=float(mx.complex_dir_error_deg(col_img, col_un)),
    note=("the two images share one mixing column (CP1 separation 0 deg), so no "
          "direction-clustering stage can separate them; only 2 geometric "
          "directions exist for 3 physical wavefronts"))
print(f"identifiability: image-image CP1 = 0 deg (shared column); "
      f"image-unrelated CP1 = {mx.complex_dir_error_deg(col_img, col_un):.1f} deg")

# --- Stage 2: recover the two geometric sources (combined image, unrelated) ---
out2 = sep.separate_M2(Xn[0], Xn[1], 2, fs, **C.SEP)
# match recovered to (img_sum, s_un)
truth2 = np.array([img_sum / np.sqrt(np.mean(img_sum ** 2)),
                   s_un / np.sqrt(np.mean(s_un ** 2))])
perm2, sdr2, al2 = ex.best_match_sdr_pa(truth2, out2["S"], fs, C.NPERSEG)
res["geometric_separation"] = dict(sdr_combined_img=float(sdr2[0]),
                                   sdr_unrelated=float(sdr2[1]))
print(f"geometric separation: combined-image SDR {sdr2[0]:.1f} dB, unrelated {sdr2[1]:.1f} dB")

# --- delay-aware coherent recovery of the two images (template-informed) ---
combined = al2[0]                       # recovered combined image stream
dt_est, amp_ratio, dphase, env = sl.delay_ampl_from_template(
    combined, s0, fs, dt_min=0.05, dt_max=0.9, flow=20.0)
res["coherent_recovery"] = dict(
    dt_true=DT, dt_est=float(dt_est),
    dt_err_pct=float(100 * abs(dt_est - DT) / DT),
    amp_ratio_est=float(amp_ratio), amp_ratio_true=float(np.sqrt(MAG)),
    dphase_est=float(dphase), morse_true=float(MORSE))
print(f"coherent recovery (template-informed): dt_est={dt_est:.3f}s (true {DT}) "
      f"err {100*abs(dt_est-DT)/DT:.1f}%; amp_ratio={amp_ratio:.2f} "
      f"(true {np.sqrt(MAG):.2f}); dphase={dphase:.2f}")

# also the blind cepstrum (for the figure / honesty about the blind limit)
dt_blind, ceps = sl.estimate_delay(combined, fs, dt_min=0.05, dt_max=0.9)
res["coherent_recovery"]["dt_blind_cepstrum"] = float(dt_blind)

# save arrays for figures
np.savez(os.path.join(R, "stronglens_arrays.npz"),
         img1=img1, img2=img2, s_un=s_un, combined=combined, s0=s0,
         mf_env=env, dt_est=dt_est, fs=fs,
         alpha=alpha, beta=beta, weights=w,
         lab2=lab2, lab3=lab3,
         col_img_re=col_img.real, col_img_im=col_img.imag,
         col_un_re=col_un.real, col_un_im=col_un.imag)
with open(os.path.join(R, "stronglens.json"), "w") as f:
    json.dump(res, f, indent=2)
print("saved stronglens.")
