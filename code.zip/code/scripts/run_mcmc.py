"""Surrogate-likelihood MCMC on the cached separated microlensed signal.
Runs chains incrementally and saves after each so progress is never lost."""
import os, json, pickle, time
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C, inference as inf
from lensbss.siren import Surrogate

R = C.RESULTS
with open(os.path.join(R, "siren_sine.pkl"), "rb") as f:
    st = pickle.load(f)
sur = Surrogate(st["w_range"], st["y_range"], activation="sine", omega0=st["omega0"])
sur.load(st)

d = np.load(os.path.join(R, "main_arrays.npz"))
sl = d["sl_rec"]; freqs = d["freqs"]; hf = d["hf"]; fs = C.FS
Sf = np.fft.rfft(sl) / fs

NS = 2500
starts = [(560, 0.281), (470, 0.36), (680, 0.22)]
chains_path = os.path.join(R, "mcmc_chains.npz")
chains = []
if os.path.exists(chains_path):
    z = np.load(chains_path, allow_pickle=True)
    chains = [z[f"c{i}"] for i in range(int(z["nchains"]))]
    print("resuming with", len(chains), "chains")

t0 = time.time()
for ci in range(len(chains), len(starts)):
    m0s, y0s = starts[ci]
    ch, acc = inf.mh_sample(Sf, hf, freqs, sur, m0s, y0s, n_samples=NS,
                            step_MLz=20.0, step_y=0.03, seed=10 + ci, stride=2)
    chains.append(ch)
    print(f"chain {ci}: {ch.shape[0]} samples, acc {acc:.2f}, "
          f"med ({np.median(ch[:,0]):.0f},{np.median(ch[:,1]):.3f}), "
          f"t={time.time()-t0:.0f}s")
    save = {f"c{i}": chains[i] for i in range(len(chains))}
    save["nchains"] = len(chains)
    np.savez(chains_path, **save)

allchain = np.vstack(chains)
rhat_M = inf.gelman_rubin([c[:, 0:1] for c in chains])
rhat_y = inf.gelman_rubin([c[:, 1:2] for c in chains])
med_M, med_y = float(np.median(allchain[:, 0])), float(np.median(allchain[:, 1]))
q_M = list(map(float, np.percentile(allchain[:, 0], [5, 95])))
q_y = list(map(float, np.percentile(allchain[:, 1], [5, 95])))
summary = dict(med_MLz=med_M, med_y=med_y, ci_MLz=q_M, ci_y=q_y,
               rhat_MLz=float(rhat_M), rhat_y=float(rhat_y),
               nsamp=int(allchain.shape[0]), nchains=len(chains))
with open(os.path.join(R, "mcmc.json"), "w") as f:
    json.dump(summary, f, indent=2)
np.savez(os.path.join(R, "mcmc_flat.npz"), chain=allchain)
print("MCMC summary:", json.dumps(summary, indent=2))
