"""Fiducial complex-ET separation + lens point estimate (no MCMC).
Caches arrays for figs 3,4,5,10 and the separated signal for the MCMC step."""
import os, json, pickle
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import experiment as ex, config as C, inference as inf, metrics as mx
from lensbss import separation as sep
from lensbss.siren import Surrogate
from lensbss.amplification import w_of_f

R = C.RESULTS
with open(os.path.join(R, "siren_sine.pkl"), "rb") as f:
    st = pickle.load(f)
sur = Surrogate(st["w_range"], st["y_range"], activation="sine", omega0=st["omega0"])
sur.load(st)
fs, n = C.FS, C.N
res = {}

sc = ex.fiducial_scenario(snr_db=34.0, seed=0, mixing="complex_et")
S, meta, Xn = sc["S"], sc["meta"], sc["Xn"]
cols_true = sc["cols_true"]
out = sep.separate_M2(Xn[0], Xn[1], 3, fs, **C.SEP)
perm, sdrs, aligned = ex.best_match_sdr_pa(S, out["S"], fs, C.NPERSEG)
corrs = [mx.corr(S[i], aligned[i]) for i in range(3)]
col_err = [min(mx.complex_dir_error_deg(cols_true[i], e) for e in out["est_cols"])
           for i in range(3)]
res["fiducial"] = dict(sdr=list(map(float, sdrs)), mean_sdr=float(np.mean(sdrs)),
                       corr=list(map(float, corrs)), perm=list(map(int, perm)),
                       col_err_deg=list(map(float, col_err)),
                       masses=[[m["m1"], m["m2"]] for m in meta],
                       thetas=[float(sp["theta"]) for sp in C.SOURCES])
print("FIDUCIAL: SDR", np.round(sdrs, 2), "mean", round(float(np.mean(sdrs)), 2),
      "corr", np.round(corrs, 3), "col_err(deg)", np.round(col_err, 2))

m0 = meta[0]; freqs = m0["freqs"]; hf = m0["hf"]
sl_rec = aligned[0]
Sf_rec = np.fft.rfft(sl_rec) / fs
chi2 = inf.chi2_grid(Sf_rec, hf, freqs, C.MLZ_GRID, C.Y_GRID, sur)
MLz_hat, y_hat, idx = inf.best_fit(chi2, C.MLZ_GRID, C.Y_GRID)
Sf_clean = np.fft.rfft(S[0]) / fs
chi2c = inf.chi2_grid(Sf_clean, hf, freqs, C.MLZ_GRID, C.Y_GRID, sur)
MLzc, yc, idxc = inf.best_fit(chi2c, C.MLZ_GRID, C.Y_GRID)
res["lensfit"] = dict(MLz_sep=float(MLz_hat), y_sep=float(y_hat),
                      MLz_clean=float(MLzc), y_clean=float(yc),
                      MLz_true=float(m0["MLz"]), y_true=float(m0["y"]))
print(f"LENS FIT separated ({MLz_hat:.0f},{y_hat:.3f}) clean ({MLzc:.0f},{yc:.3f}) "
      f"true ({m0['MLz']:.0f},{m0['y']:.2f})")

w_arr = w_of_f(freqs, MLz_hat)
band = (w_arr <= 30) & (freqs >= 20) & (w_arr > 1e-3)
Fmod = sur.predict(w_arr[band], np.full(band.sum(), y_hat))
modv = Fmod * hf[band]
A = np.sum(np.conj(modv) * Sf_rec[band]) / (np.sum(np.abs(modv) ** 2) + 1e-30)
Femp = Sf_rec[band] / (A * hf[band] + 1e-30)

np.savez(os.path.join(R, "main_arrays.npz"),
         S=S, aligned=aligned, Xn=Xn,
         est_cols_re=out["est_cols"].real, est_cols_im=out["est_cols"].imag,
         cols_true_re=cols_true.real, cols_true_im=cols_true.imag,
         alpha=out["alpha"], beta=out["beta"], weights=out["weights"],
         chi2=chi2, chi2c=chi2c, MLZ_GRID=C.MLZ_GRID, Y_GRID=C.Y_GRID,
         freqs=freqs, hf=hf, Femp_re=Femp.real, Femp_im=Femp.imag,
         band=band, Ftrue_re=m0["F"].real, Ftrue_im=m0["F"].imag,
         idx=np.array(idx), idxc=np.array(idxc), perm=np.array(perm),
         sl_rec=sl_rec)
with open(os.path.join(R, "main.json"), "w") as f:
    json.dump(res, f, indent=2)
print("saved main_arrays.npz + main.json")
