"""WDO 2D heatmap + scaling (oracle/blind) + IMR separation + null stream."""
import os, json
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C, experiment as ex, separation as sep, metrics as mx
from lensbss import detector as det, waveforms as wf
from lensbss.detector import psd_ET

R = C.RESULTS
fs, n = C.FS, C.N
ff = np.fft.rfftfreq(n, 1.0 / fs)
res = {}

SKIES5 = [dict(ra=1.2, dec=0.3, psi=0.4, iota=0.5),
          dict(ra=4.5, dec=-0.6, psi=1.1, iota=1.2),
          dict(ra=2.8, dec=0.9, psi=0.7, iota=0.9),
          dict(ra=0.6, dec=-1.0, psi=0.2, iota=1.4),
          dict(ra=5.4, dec=0.5, psi=1.3, iota=0.3)]

def complex_mix(S, skies, snr_db, seed):
    dets = det.et_triangle()[:2]
    A, cmat, _ = det.mixing_columns(dets, ff, skies)
    X, _ = ex.mix_complex(S, cmat.T)
    Xn, _ = ex.add_noise(X, snr_db, fs, seed=seed)
    return Xn, cmat

# ---------------- WDO 2D heatmap: dMass x dt_c ----------------
print("=== WDO 2D heatmap ===")
dM_grid = np.array([0.5, 2, 4, 7, 10, 14])
dt_grid = np.array([0.0, 0.05, 0.12, 0.22, 0.35, 0.5])
H = np.zeros((len(dM_grid), len(dt_grid)))
m1b, m2b = 26.0, 22.0
for i, dM in enumerate(dM_grid):
    for j, dt in enumerate(dt_grid):
        s0, _, _ = wf.make_source_td(m1b, m2b, n, fs, tc=2.0, seed=1)
        s1, _, _ = wf.make_source_td(m1b + dM, m2b + 0.8 * dM, n, fs,
                                     tc=2.0 + dt, seed=2)
        S2 = np.array([s0, s1])
        Xn, _ = complex_mix(S2, SKIES5[:2], 30.0, seed=3)
        out = sep.separate_M2(Xn[0], Xn[1], 2, fs, **C.SEP)
        _, sdrs, _ = ex.best_match_sdr_pa(S2, out["S"], fs, C.NPERSEG)
        H[i, j] = float(np.min(sdrs))     # worst-separated of the pair
    print(f"  dM={dM_grid[i]:>4}: " + " ".join(f"{H[i,j]:5.1f}" for j in range(len(dt_grid))))
res["wdo"] = dict(dM_grid=dM_grid.tolist(), dt_grid=dt_grid.tolist(),
                  min_sdr=H.tolist())
np.savez(os.path.join(R, "wdo.npz"), dM=dM_grid, dt=dt_grid, H=H)

# ---------------- scaling: N sources, oracle vs blind ----------------
print("=== scaling N sources ===")
Ns = [2, 3, 4, 5]
scaling = {"N": Ns, "blind_mean": [], "blind_std": [], "oracle_mean": [], "oracle_std": []}
masses = [(31, 28), (19, 17), (24, 21), (12, 10), (40, 35)]
for N in Ns:
    bl_acc, or_acc = [], []
    for seed in range(3):
        S = np.array([wf.make_source_td(*masses[k], n, fs, tc=1.6 + 0.15 * k,
                                        seed=10 * seed + k)[0] for k in range(N)])
        Xn, cmat = complex_mix(S, SKIES5[:N], 32.0, seed=seed)
        cols_true = (cmat / np.linalg.norm(cmat, axis=0, keepdims=True)).T
        out_b = sep.separate_M2(Xn[0], Xn[1], N, fs, **C.SEP)
        _, sb, _ = ex.best_match_sdr_pa(S, out_b["S"], fs, C.NPERSEG)
        bl_acc.append(np.mean(sb))
        out_o = sep.separate_M2(Xn[0], Xn[1], N, fs, A_true_cols=cols_true,
                                **C.SEP)
        _, so, _ = ex.best_match_sdr_pa(S, out_o["S"], fs, C.NPERSEG)
        or_acc.append(np.mean(so))
    scaling["blind_mean"].append(float(np.mean(bl_acc)))
    scaling["blind_std"].append(float(np.std(bl_acc)))
    scaling["oracle_mean"].append(float(np.mean(or_acc)))
    scaling["oracle_std"].append(float(np.std(or_acc)))
    print(f"  N={N}: blind {np.mean(bl_acc):5.1f}+/-{np.std(bl_acc):.1f} | "
          f"oracle {np.mean(or_acc):5.1f}+/-{np.std(or_acc):.1f} dB")
res["scaling"] = scaling

# ---------------- IMR separation ----------------
print("=== IMR separation ===")
S_imr = np.array([wf.make_source_td(*m, n, fs, tc=1.7 + 0.1 * k, kind="imr",
                                    seed=k + 1)[0]
                  for k, m in enumerate([(35, 31), (22, 19), (13, 11)])])
Xn, cmat = complex_mix(S_imr, SKIES5[:3], 34.0, seed=4)
out = sep.separate_M2(Xn[0], Xn[1], 3, fs, **C.SEP)
_, imr_sdr, imr_al = ex.best_match_sdr_pa(S_imr, out["S"], fs, C.NPERSEG)
res["imr"] = dict(sdr=list(map(float, imr_sdr)), mean=float(np.mean(imr_sdr)))
print(f"  IMR SDR {np.round(imr_sdr,2)} mean {np.mean(imr_sdr):.2f} dB")
np.savez(os.path.join(R, "imr_arrays.npz"), S=S_imr, aligned=imr_al)

# ---------------- null stream: M=3, N=4 (real mixing, deemphasised) ----------------
print("=== null stream M=3 N=4 ===")
S4 = np.array([wf.make_source_td(*m, n, fs, tc=1.6 + 0.12 * k, seed=k + 1)[0]
               for k, m in enumerate([(30, 27), (20, 18), (24, 21), (12, 10)])])
# real 3x4 mixing
rng = np.random.default_rng(0)
ang = np.array([0.3, 0.8, 1.2, 1.45])
M3 = np.array([[np.cos(a) for a in ang],
               [np.sin(a) * np.cos(0.5 * a) for a in ang],
               [np.sin(a) * np.sin(0.5 * a) for a in ang]])
X3 = M3 @ S4
def add_noise_multi(X, snr_db, seed):
    rng = np.random.default_rng(seed)
    p = np.mean(X ** 2)
    s2 = p / (10 ** (snr_db / 10))
    return X + rng.normal(0, np.sqrt(s2), X.shape)
res["nullstream"] = {}
for snr in [np.inf, 40, 20]:
    Xc = X3 if not np.isfinite(snr) else add_noise_multi(X3, snr, 7)
    f1, _, Za = sep.stft_channel(Xc[0], fs, C.NPERSEG)
    _, _, Zb = sep.stft_channel(Xc[1], fs, C.NPERSEG)
    _, _, Zc = sep.stft_channel(Xc[2], fs, C.NPERSEG)
    Zst = np.stack([Za, Zb, Zc], 0)
    # null out source 0 (known column M3[:,0])
    Zproj, B = sep.null_project(Zst, M3[:, 0])
    # power of source-0 contribution before vs after projection
    s0_only = M3[:, 0:1] @ S4[0:1, :]
    f1, _, Z0a = sep.stft_channel(s0_only[0], fs, C.NPERSEG)
    _, _, Z0b = sep.stft_channel(s0_only[1], fs, C.NPERSEG)
    _, _, Z0c = sep.stft_channel(s0_only[2], fs, C.NPERSEG)
    Z0 = np.stack([Z0a, Z0b, Z0c], 0)
    Z0proj = np.einsum("ij,jft->ift", B, Z0)
    before = np.sum(np.abs(Z0) ** 2)
    after = np.sum(np.abs(Z0proj) ** 2)
    supp = 10 * np.log10((after + 1e-300) / (before + 1e-300))
    key = "noiseless" if not np.isfinite(snr) else f"snr{snr}"
    res["nullstream"][key] = float(supp)
    print(f"  null-stream suppression of source 0 ({key}): {supp:.1f} dB")

with open(os.path.join(R, "extras.json"), "w") as f:
    json.dump(res, f, indent=2)
print("saved extras.json + wdo.npz + imr_arrays.npz")
