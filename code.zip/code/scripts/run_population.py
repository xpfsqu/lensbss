"""Population study (reviewer: UBSS as preprocessing; coverage / PP plots).

For each injection: a microlensed source (random masses, MLz in [350,650],
y in [0.2,0.45]) plus two contaminating CBCs at random sky positions are
complex-ET mixed and separated; the lensing posterior is computed on the
separated microlensed source by a coarse grid.  We record the point-estimate
bias and the posterior credible level at which the injected truth falls (for the
PP / coverage curve).  Runs in batches and saves after each so it can resume.
"""
import os, json, pickle, time
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C, experiment as ex, separation as sep, inference as inf
from lensbss import waveforms as wf, detector as det
from lensbss.siren import Surrogate

R = C.RESULTS
with open(os.path.join(R, "siren_sine.pkl"), "rb") as f:
    st = pickle.load(f)
sur = Surrogate(st["w_range"], st["y_range"], activation="sine", omega0=st["omega0"])
sur.load(st)
fs, n = C.FS, C.N
ff = np.fft.rfftfreq(n, 1.0 / fs)

MLZg = np.linspace(200, 900, 44)
Yg = np.linspace(0.10, 0.60, 40)
NTOT = 100
BATCH = 20

store = os.path.join(R, "population.json")
recs = []
if os.path.exists(store):
    with open(store) as f:
        recs = json.load(f)["records"]
    print("resuming with", len(recs), "injections")

skies_pool = [dict(ra=1.2, dec=0.3, psi=0.4, iota=0.5),
              dict(ra=4.5, dec=-0.6, psi=1.1, iota=1.2),
              dict(ra=2.8, dec=0.9, psi=0.7, iota=0.9),
              dict(ra=0.6, dec=-1.0, psi=0.2, iota=1.4),
              dict(ra=5.4, dec=0.5, psi=1.3, iota=0.3),
              dict(ra=3.3, dec=-0.2, psi=0.9, iota=0.8)]

t0 = time.time()
while len(recs) < NTOT:
    batch_start = len(recs)
    for k in range(batch_start, min(batch_start + BATCH, NTOT)):
        rng = np.random.default_rng(1000 + k)
        # microlensed source: keep in a band with usable wave-optics content
        m1 = rng.uniform(16, 24); m2 = rng.uniform(14, m1)
        MLz = rng.uniform(350, 650); y = rng.uniform(0.20, 0.45)
        smic, freqs, hl, hf, F = ex.build_lensed_source(m1, m2, MLz, y, n, fs, seed=k)
        # two contaminating CBCs
        c1 = wf.make_source_td(rng.uniform(28, 40), rng.uniform(24, 34), n, fs,
                               tc=rng.uniform(1.4, 2.4), seed=100 + k)[0]
        c2 = wf.make_source_td(rng.uniform(9, 14), rng.uniform(8, 12), n, fs,
                               tc=rng.uniform(1.4, 2.4), seed=200 + k)[0]
        S = np.array([smic, c1, c2])
        idxsky = rng.permutation(len(skies_pool))[:3]
        skies = [skies_pool[i] for i in idxsky]
        A, cmat, _ = det.mixing_columns(det.et_triangle()[:2], ff, skies)
        X, _ = ex.mix_complex(S, cmat.T)
        Xn, _ = ex.add_noise(X, rng.uniform(28, 40), fs, seed=300 + k)
        out = sep.separate_M2(Xn[0], Xn[1], 3, fs, **C.SEP)
        # pick separated component best matching the microlensed source
        perm, sdrs, aligned = ex.best_match_sdr_pa(S, out["S"], fs, C.NPERSEG)
        sep_mic = aligned[0]
        sdr_mic = float(sdrs[0])
        Sf = np.fft.rfft(sep_mic) / fs
        chi2 = inf.chi2_grid(Sf, hf, freqs, MLZg, Yg, sur, stride=4)
        p = inf.grid_posterior(chi2, MLZg, Yg)
        iM = int(np.argmin(np.abs(MLZg - MLz)))
        iy = int(np.argmin(np.abs(Yg - y)))
        cl = float(inf.credible_level_of_truth(p, (iM, iy)))
        MLz_hat = float(MLZg[np.unravel_index(np.argmin(chi2), chi2.shape)[0]])
        y_hat = float(Yg[np.unravel_index(np.argmin(chi2), chi2.shape)[1]])
        recs.append(dict(MLz_true=float(MLz), y_true=float(y),
                         MLz_hat=MLz_hat, y_hat=y_hat, cred_level=cl,
                         sdr_mic=sdr_mic))
    with open(store, "w") as f:
        json.dump({"records": recs, "MLZg": MLZg.tolist(), "Yg": Yg.tolist()}, f)
    print(f"  {len(recs)}/{NTOT} done, t={time.time()-t0:.0f}s")

# summary statistics
M_true = np.array([r["MLz_true"] for r in recs])
M_hat = np.array([r["MLz_hat"] for r in recs])
y_true = np.array([r["y_true"] for r in recs])
y_hat = np.array([r["y_hat"] for r in recs])
cl = np.array([r["cred_level"] for r in recs])
relbiasM = (M_hat - M_true) / M_true
# coverage at nominal levels: fraction with cred_level <= level
levels = np.array([0.5, 0.68, 0.9])
cover = [float(np.mean(cl <= L)) for L in levels]
summary = dict(n=len(recs),
               median_relbias_MLz=float(np.median(relbiasM)),
               mad_relbias_MLz=float(np.median(np.abs(relbiasM - np.median(relbiasM)))),
               median_relbias_y=float(np.median((y_hat - y_true) / y_true)),
               coverage_levels=levels.tolist(), coverage=cover)
with open(os.path.join(R, "population_summary.json"), "w") as f:
    json.dump(summary, f, indent=2)
print("SUMMARY:", json.dumps(summary, indent=2))
