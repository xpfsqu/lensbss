"""Baseline separation methods and the downstream-value table.

Separation baselines (on the fiducial complex-ET mixture):
  FastICA (M>=N only), DUET (anechoic), sequential CLEAN-like subtraction, vs our
  time-frequency SCA.
Downstream value: run the lensing fit on (i) a raw mixed channel, (ii) our
  separated microlensed source, (iii) the oracle clean source, and report the
  (M_Lz, y) recovery + runtime, bracketing the value separation adds.
"""
import os, json, time
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C, experiment as ex, separation as sep, metrics as mx
from lensbss import baselines as bl, inference as inf
from lensbss.siren import Surrogate

R = C.RESULTS
import pickle
with open(os.path.join(R, "siren_sine.pkl"), "rb") as f:
    st = pickle.load(f)
sur = Surrogate(st["w_range"], st["y_range"], activation="sine", omega0=st["omega0"])
sur.load(st)
fs, n = C.FS, C.N

sc = ex.fiducial_scenario(snr_db=34.0, seed=0, mixing="complex_et")
S, meta, Xn = sc["S"], sc["meta"], sc["Xn"]
res = {}

# ---- separation baselines ----
# our SCA
out = sep.separate_M2(Xn[0], Xn[1], 3, fs, **C.SEP)
_, sca_sdr, _ = ex.best_match_sdr_pa(S, out["S"], fs, C.NPERSEG)
# FastICA (2 comps from 2 channels; underdetermined -> cannot recover 3)
ica = bl.fastica_separate(Xn, n_components=2, seed=0)
ica_sdr = [max(mx.sdr(S[i], ica[k]) for k in range(ica.shape[0])) for i in range(3)]
# DUET
duet = bl.duet_separate(Xn[0], Xn[1], 3, fs, nperseg=256)
duet_sdr = [max(mx.sdr(S[i], duet[k]) for k in range(duet.shape[0])) for i in range(3)]
# sequential CLEAN-like subtraction using intrinsic templates
templates = [np.real(np.fft.irfft(m["hf"], n=n)) for m in meta]
templates = [tt / (np.sqrt(np.mean(tt ** 2)) + 1e-30) for tt in templates]
comps, used, _ = bl.sequential_subtract(Xn[0], templates, fs, n_iter=3)
seq_sdr = []
for i in range(3):
    best = -np.inf
    for c in comps:
        best = max(best, mx.sdr(S[i], c))
    seq_sdr.append(best)
res["separation_sdr"] = dict(
    sca=list(map(float, sca_sdr)), sca_mean=float(np.mean(sca_sdr)),
    fastica=list(map(float, ica_sdr)), fastica_mean=float(np.mean(ica_sdr)),
    duet=list(map(float, duet_sdr)), duet_mean=float(np.mean(duet_sdr)),
    sequential=list(map(float, seq_sdr)), sequential_mean=float(np.mean(seq_sdr)))
print("SEPARATION mean SDR (dB):  SCA %.1f | FastICA %.1f | DUET %.1f | seq-subtract %.1f"
      % (np.mean(sca_sdr), np.mean(ica_sdr), np.mean(duet_sdr), np.mean(seq_sdr)))

# ---- downstream value: lens PE on raw vs separated vs oracle ----
m0 = meta[0]; freqs = m0["freqs"]; hf = m0["hf"]
MLzT, yT = m0["MLz"], m0["y"]
# separated microlensed source (phase-aligned)
perm, _, aligned = ex.best_match_sdr_pa(S, out["S"], fs, C.NPERSEG)
sep_src = aligned[0]

def fit_and_time(sig):
    Sf = np.fft.rfft(sig) / fs
    t0 = time.time()
    chi2 = inf.chi2_grid(Sf, hf, freqs, C.MLZ_GRID, C.Y_GRID, sur)
    dt = time.time() - t0
    MLz, y, _ = inf.best_fit(chi2, C.MLZ_GRID, C.Y_GRID)
    return MLz, y, dt

raw_MLz, raw_y, _ = fit_and_time(Xn[0])
sep_MLz, sep_y, sep_dt = fit_and_time(sep_src)
ora_MLz, ora_y, _ = fit_and_time(S[0])

def errs(MLz, y):
    return float(100 * (MLz - MLzT) / MLzT), float(100 * (y - yT) / yT)

res["downstream"] = dict(
    truth=[float(MLzT), float(yT)],
    raw=[float(raw_MLz), float(raw_y), *errs(raw_MLz, raw_y)],
    separated=[float(sep_MLz), float(sep_y), *errs(sep_MLz, sep_y)],
    oracle=[float(ora_MLz), float(ora_y), *errs(ora_MLz, ora_y)],
    surrogate_fit_time_s=float(sep_dt))
print("DOWNSTREAM lens fit (MLz,y):")
print(f"   truth      ({MLzT:.0f},{yT:.2f})")
print(f"   raw mix    ({raw_MLz:.0f},{raw_y:.3f})  err {errs(raw_MLz,raw_y)[0]:+.0f}%,{errs(raw_MLz,raw_y)[1]:+.0f}%")
print(f"   separated  ({sep_MLz:.0f},{sep_y:.3f})  err {errs(sep_MLz,sep_y)[0]:+.0f}%,{errs(sep_MLz,sep_y)[1]:+.0f}%")
print(f"   oracle     ({ora_MLz:.0f},{ora_y:.3f})  err {errs(ora_MLz,ora_y)[0]:+.0f}%,{errs(ora_MLz,ora_y)[1]:+.0f}%")

# runtime per lens evaluation: surrogate vs mpmath (from speed.json)
with open(os.path.join(R, "speed.json")) as f:
    speed = json.load(f)
res["runtime"] = speed

np.savez(os.path.join(R, "baselines_arrays.npz"),
         S=S, sca=out["sources"], ica=ica, duet=duet,
         comps=np.array(comps) if comps else np.zeros((0, n)),
         sep_src=sep_src, raw=Xn[0])
with open(os.path.join(R, "baselines.json"), "w") as f:
    json.dump(res, f, indent=2)
print("saved baselines.json + baselines_arrays.npz")
