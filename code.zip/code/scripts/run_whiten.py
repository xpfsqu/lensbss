"""Whitening robustness (reviewer point on SNR definition + error bands).

Uses the real-mixing 3-source configuration to ISOLATE the noise-colour effect
(complex mixing is established separately).  Measures separation quality in the
whitened domain for consistency between the whitened and unwhitened pipelines,
sweeping the network mixing SNR with several noise realisations (error bands),
and maps network mixing SNR -> matched-filter SNR.  Also runs the whitening
ablation (ideal / aLIGO-mismatch / wrong-slope) and the glitch K-means vs DBSCAN
test.
"""
import os, json
import numpy as np, sys
sys.path.insert(0, "/home/claude/proj")
from lensbss import config as C, separation as sep, metrics as mx, experiment as ex
from lensbss import detector as det
from lensbss.detector import psd_ET, psd_aLIGO

R = C.RESULTS
fs, n = C.FS, C.N
ff = np.fft.rfftfreq(n, 1.0 / fs)

# build the fiducial sources (real mixing here)
S, meta = ex.make_sources()
thetas = [sp["theta"] for sp in C.SOURCES]
X, cols = ex.mix_real(S, thetas)

def whiten_sources(psd_func):
    return np.array([sep.whiten(S[j], psd_func, fs) for j in range(3)])

def sep_quality(Xn_chan, whiten_psd):
    """Return mean SDR (whitened-domain) of the 3 sources."""
    if whiten_psd is not None:
        x1 = sep.whiten(Xn_chan[0], whiten_psd, fs)
        x2 = sep.whiten(Xn_chan[1], whiten_psd, fs)
        target = whiten_sources(whiten_psd)
    else:
        x1, x2 = Xn_chan[0], Xn_chan[1]
        target = S
    out = sep.separate_M2(x1, x2, 3, fs, **C.SEP)
    perm, sdrs, _ = ex.best_match_sdr_pa(target, out["S"], fs, C.NPERSEG)
    return float(np.mean(sdrs)), sdrs[0]   # mean, microlensed(src0)

SNRS = [40, 30, 22, 16, 12, 8, 6]
NREAL = 12
out_path = os.path.join(R, "whiten.json")
res = {"snrs": SNRS, "nreal": NREAL}

# network mixing SNR -> matched-filter SNR mapping (deterministic in signal)
mf_map = []
for snr in SNRS:
    Xn, scale = ex.add_noise(X, snr, fs, psd_func=psd_ET, seed=0)
    mf = ex.network_mf_snr(S[0], cols[0], psd_ET, fs)  # source0 MF SNR at unit amplitude
    # the injected source amplitude relative to noise sets the *measured* MF SNR;
    # measure it directly from the noisy data scale
    mf_map.append(float(mf))   # template-normalised; reported as proportional
res["mf_per_netsnr"] = mf_map

# SNR sweep with/without whitening, error bands
sweep = {"white_mean": [], "white_std": [], "nowhite_mean": [], "nowhite_std": [],
         "white_mic": [], "nowhite_mic": []}
for snr in SNRS:
    wm, nm, wmic, nmic = [], [], [], []
    for r in range(NREAL):
        Xn, _ = ex.add_noise(X, snr, fs, psd_func=psd_ET, seed=100 + r)
        m_w, mic_w = sep_quality(Xn, psd_ET)
        m_n, mic_n = sep_quality(Xn, None)
        wm.append(m_w); nm.append(m_n); wmic.append(mic_w); nmic.append(mic_n)
    sweep["white_mean"].append(float(np.mean(wm)))
    sweep["white_std"].append(float(np.std(wm)))
    sweep["nowhite_mean"].append(float(np.mean(nm)))
    sweep["nowhite_std"].append(float(np.std(nm)))
    sweep["white_mic"].append(float(np.mean(wmic)))
    sweep["nowhite_mic"].append(float(np.mean(nmic)))
    res["sweep"] = sweep
    with open(out_path, "w") as f:
        json.dump(res, f, indent=2)
    print(f"SNR {snr:>2}dB: whiten {np.mean(wm):5.1f}+/-{np.std(wm):.1f} dB | "
          f"no-whiten {np.mean(nm):5.1f}+/-{np.std(nm):.1f} dB")

print("saved whiten.json")
