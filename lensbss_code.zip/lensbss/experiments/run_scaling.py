#!/usr/bin/env python3
"""Scaling with the number of overlapping sources (paper Section 8.2).

At fixed M=2 channels, increase the source count N and record the mean
separation SDR with oracle and blindly estimated columns.
"""

from __future__ import annotations

import numpy as np
import warnings
warnings.filterwarnings("ignore")

from lensbss import default_config
from lensbss.mixing import column_from_angles, mix_sources
from lensbss.waveforms import taylorf2
from lensbss.sca import sparse_recover, rank_one_ssp, cluster_directions
from lensbss.psd import colored_noise
from lensbss.metrics import match_and_score


def scene_N(cfg, N, rng):
    freqs = np.fft.rfftfreq(cfg.n_t, d=1.0 / cfg.f_s)
    masses = [(30, 28), (22, 20), (16, 14), (11, 9), (8, 7)][:N]
    alphas = np.linspace(np.deg2rad(20), np.deg2rad(70), N)
    betas = np.linspace(-2.0, 2.0, N)
    src, cols = [], []
    for (m, (m1, m2)) in enumerate(masses):
        x = np.fft.irfft(taylorf2(freqs, m1, m2, tc=2.0 + 0.03 * m, f_low=cfg.f_low),
                         n=cfg.n_t)
        x /= np.std(x) + 1e-30
        src.append(x)
        cols.append(column_from_angles(alphas[m], betas[m]))
    src = np.stack(src, axis=0)
    C = np.stack(cols, axis=-1)
    mixed = mix_sources(src, C)
    noise = np.stack([colored_noise(cfg, rng) for _ in range(2)], axis=0)
    noise *= np.sqrt(np.sum(mixed ** 2) / (10 ** (34 / 10)) /
                     (np.sum(noise ** 2) + 1e-30))
    return mixed + noise, src, C


def main():
    cfg = default_config()
    print("=== Scaling with source count N (M=2) ===")
    for N in [2, 3, 4, 5]:
        oracle, blind = [], []
        for s in range(3):
            rng = np.random.default_rng(100 + s)
            ch, src, C = scene_N(cfg, N, rng)
            truths = list(src)
            est_o = sparse_recover(ch, C, cfg)
            oracle.append(np.mean(match_and_score(truths, list(est_o))))
            ssp = rank_one_ssp(ch, cfg)
            Cb, *_ = cluster_directions(ssp, cfg, n_expected=N)
            if Cb.shape[1] >= 2:
                est_b = sparse_recover(ch, Cb, cfg)
                blind.append(np.mean(match_and_score(truths, list(est_b))))
        print(f"N={N} | oracle {np.mean(oracle):5.1f} dB | "
              f"blind {np.mean(blind) if blind else float('nan'):5.1f} dB")


if __name__ == "__main__":
    main()
