#!/usr/bin/env python3
"""Lensing inference on a separated source (paper Section 5).

Fits (M_Lz, y) to the separated microlensed source with a profiled complex
amplitude, then samples the posterior and reports the credible interval.  The
neural-surrogate interface accelerates the amplification-factor evaluations.
"""

from __future__ import annotations

import numpy as np
import warnings
warnings.filterwarnings("ignore")

from lensbss import default_config
from lensbss.separation import build_fiducial, separate
from lensbss.waveforms import taylorf2
from lensbss.inference import grid_fit, metropolis_hastings, gelman_rubin


def main():
    cfg = default_config()
    scene = build_fiducial(cfg, snr_db=34.0, seed=1)
    res = separate(scene["channels"], cfg, n_expected=3)

    # The separated microlensed source is the one best matching source 0.
    from lensbss.metrics import phase_aligned_sdr
    k = int(np.argmax([phase_aligned_sdr(scene["sources"][0], e)
                       for e in res["estimates"]]))
    sep = res["estimates"][k]

    freqs = np.fft.rfftfreq(cfg.n_t, d=1.0 / cfg.f_s)
    data_spec = np.fft.rfft(sep)
    template = taylorf2(freqs, 19, 17, tc=2.0, f_low=cfg.f_low)

    m_grid = np.linspace(300, 900, 25)
    y_grid = np.linspace(0.15, 0.5, 20)
    (m_hat, y_hat), _ = grid_fit(data_spec, template, freqs, cfg, m_grid, y_grid,
                                 use_surrogate=True)
    print(f"grid MLE (separated): M_Lz={m_hat:.0f} Msun, y={y_hat:.3f}  "
          f"(truth 500, 0.30)")

    chains = []
    for s in range(3):
        chain, acc = metropolis_hastings(data_spec, template, freqs, cfg,
                                         start=(m_hat, y_hat), n_samples=1500,
                                         n_burn=800, seed=s, use_surrogate=True)
        chains.append(chain)
    allm = np.concatenate([c[:, 0] for c in chains])
    ally = np.concatenate([c[:, 1] for c in chains])
    rhat_m = gelman_rubin([c[:, 0] for c in chains])
    rhat_y = gelman_rubin([c[:, 1] for c in chains])
    print(f"posterior median: M_Lz={np.median(allm):.0f} Msun, y={np.median(ally):.3f}")
    print(f"90%% CI: M_Lz [{np.percentile(allm,5):.0f}, {np.percentile(allm,95):.0f}] Msun, "
          f"y [{np.percentile(ally,5):.3f}, {np.percentile(ally,95):.3f}]")
    print(f"Gelman-Rubin: Rhat(M_Lz)={rhat_m:.3f}, Rhat(y)={rhat_y:.3f}")


if __name__ == "__main__":
    main()
