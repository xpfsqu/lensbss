#!/usr/bin/env python3
"""Separation baselines on the fiducial complex mixture (paper Section 6).

Shows that FastICA (cannot represent an underdetermined mixing) and DUET
(assumes anechoic real mixing) fail on the complex near-zero-delay columns,
while the covariance SCA pipeline succeeds.
"""

from __future__ import annotations

import numpy as np
import warnings
warnings.filterwarnings("ignore")

from lensbss import default_config
from lensbss.separation import build_fiducial, separate
from lensbss.baselines import fastica_separate, duet_separate
from lensbss.metrics import match_and_score


def main():
    cfg = default_config()
    scene = build_fiducial(cfg, snr_db=34.0, seed=1)
    truths = list(scene["sources"])

    res = separate(scene["channels"], cfg, n_expected=3)
    sca = match_and_score(truths, list(res["estimates"]))

    ica = fastica_separate(scene["channels"], n_sources=3)
    ica_sdr = match_and_score(truths, list(ica))

    duet = duet_separate(scene["channels"], n_sources=3, cfg=cfg)
    duet_sdr = match_and_score(truths, list(duet))

    print("=== Baseline comparison (mean phase-aligned SDR) ===")
    print(f"SCA (this work): {np.mean(sca):5.1f} dB")
    print(f"FastICA        : {np.mean(ica_sdr):5.1f} dB   (fails: N>M)")
    print(f"DUET           : {np.mean(duet_sdr):5.1f} dB   (fails: complex columns)")


if __name__ == "__main__":
    main()
