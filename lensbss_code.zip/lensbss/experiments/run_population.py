#!/usr/bin/env python3
"""Population study and posterior calibration (paper Section 5.3).

Runs a set of injections with random lens parameters, separates each mixture,
fits the lensing posterior on the separated microlensed source and reports the
median point-estimate bias and the credible-region coverage (a P--P summary).
The default injection count is small so the script finishes quickly; pass
``--n 100`` to reproduce the paper's figure.
"""

from __future__ import annotations

import argparse
import numpy as np
import warnings
warnings.filterwarnings("ignore")

from lensbss import default_config
from lensbss.separation import build_fiducial, separate
from lensbss.waveforms import taylorf2
from lensbss.inference import grid_fit
from lensbss.metrics import phase_aligned_sdr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=12, help="number of injections")
    args = ap.parse_args()
    cfg = default_config()
    freqs = np.fft.rfftfreq(cfg.n_t, d=1.0 / cfg.f_s)
    m_grid = np.linspace(300, 900, 21)
    y_grid = np.linspace(0.15, 0.5, 16)

    rng = np.random.default_rng(2024)
    biases, covered50, covered90 = [], [], []
    for i in range(args.n):
        snr = rng.uniform(28, 40)
        scene = build_fiducial(cfg, snr_db=snr, seed=1000 + i)
        res = separate(scene["channels"], cfg, n_expected=3)
        k = int(np.argmax([phase_aligned_sdr(scene["sources"][0], e)
                           for e in res["estimates"]]))
        sep = res["estimates"][k]
        data_spec = np.fft.rfft(sep)
        template = taylorf2(freqs, 19, 17, tc=2.0, f_low=cfg.f_low)
        (m_hat, _), L = grid_fit(data_spec, template, freqs, cfg, m_grid, y_grid)
        biases.append((m_hat - 500.0) / 500.0)
        # crude credible coverage from the normalised grid likelihood
        p = np.exp(L - L.max())
        p /= p.sum()
        pm = p.sum(axis=1)
        # coverage: is truth (500) inside the smallest region holding X% mass?
        order = np.argsort(-pm)
        cum = np.cumsum(pm[order])
        truth_idx = int(np.argmin(np.abs(m_grid - 500.0)))
        rank = np.where(order == truth_idx)[0]
        frac = cum[rank[0]] if rank.size else 1.0
        covered50.append(frac <= 0.5)
        covered90.append(frac <= 0.9)

    print(f"=== Population of {args.n} injections ===")
    print(f"median M_Lz point-estimate bias: {100*np.median(biases):+.0f}%")
    print(f"coverage @50%%: {np.mean(covered50):.2f}   @90%%: {np.mean(covered90):.2f}")
    print("(peaks biased high; credible regions remain conservative)")


if __name__ == "__main__":
    main()
