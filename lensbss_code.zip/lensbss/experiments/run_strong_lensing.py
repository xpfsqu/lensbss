#!/usr/bin/env python3
"""Strong-lensing shared-column demonstration (paper Section 4).

Two images of one strongly lensed source share a single mixing direction and are
geometrically inseparable by direction; an unrelated source sits far away in
CP^1.  Direction-based SCA isolates the combined-image stream, and a
template-informed matched filter then recovers the image time delay.
"""

from __future__ import annotations

import argparse
import numpy as np

from lensbss import default_config
from lensbss.mixing import column_from_angles, mix_sources
from lensbss.waveforms import taylorf2
from lensbss.metrics import cp1_angle


def recover_delay(cfg, delay, mag_ratio, morse_n=1):
    """Coherent template-informed recovery of the image time delay."""
    freqs = np.fft.rfftfreq(cfg.n_t, d=1.0 / cfg.f_s)
    h = taylorf2(freqs, 25, 22, tc=2.0, f_low=cfg.f_low)
    img1 = np.fft.irfft(h, n=cfg.n_t)
    shift = int(round(delay * cfg.f_s))
    img2 = mag_ratio * np.roll(
        np.fft.irfft(h * np.exp(-1j * morse_n * np.pi / 2), n=cfg.n_t), shift)
    combined = img1 + img2
    templ = np.fft.irfft(h, n=cfg.n_t)
    env = np.abs(np.correlate(combined, templ, mode="full"))
    lags = np.arange(-cfg.n_t + 1, cfg.n_t) / cfg.f_s
    order = np.argsort(-env)
    peaks = []
    for idx in order:
        if all(abs(lags[idx] - p) > 0.05 for p in peaks):
            peaks.append(lags[idx])
        if len(peaks) == 2:
            break
    peaks.sort()
    return abs(peaks[1] - peaks[0]) if len(peaks) == 2 else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--delay", type=float, default=0.45)
    ap.add_argument("--mag-ratio", type=float, default=0.6)
    ap.add_argument("--grid", action="store_true",
                    help="sweep (delay, mag-ratio) and report recovery errors")
    args = ap.parse_args()

    if args.grid:
        cfg = default_config()
        print("=== Coherent delay recovery over a grid ===")
        print("true dt [s] | mag | recovered dt [s] | error")
        for dt in (0.30, 0.45, 0.70):
            for mu in (0.4, 0.6, 0.8):
                rec = recover_delay(cfg, dt, mu)
                print(f"  {dt:.2f}      | {mu:.1f} |   {rec:.3f}         "
                      f"| {abs(rec-dt)/dt*100:.1f}%")
        return
    cfg = default_config()
    freqs = np.fft.rfftfreq(cfg.n_t, d=1.0 / cfg.f_s)

    # One lensed source (two images, shared direction) + one unrelated source.
    h = taylorf2(freqs, 25, 22, tc=2.0, f_low=cfg.f_low)
    img1 = np.fft.irfft(h, n=cfg.n_t)
    # Second image: delayed, demagnified, Morse phase -pi/2.
    shift = int(round(args.delay * cfg.f_s))
    img2 = args.mag_ratio * np.roll(np.fft.irfft(h * np.exp(-1j * np.pi / 2), n=cfg.n_t), shift)
    combined = img1 + img2
    combined /= np.std(combined) + 1e-30

    other = np.fft.irfft(taylorf2(freqs, 12, 10, tc=1.9, f_low=cfg.f_low), n=cfg.n_t)
    other /= np.std(other) + 1e-30

    col_img = column_from_angles(np.deg2rad(55.0), +1.9)      # shared image column
    col_oth = column_from_angles(np.deg2rad(20.0), -1.0)      # unrelated
    print("CP^1 separation image-vs-unrelated: %.1f deg" %
          cp1_angle(col_img, col_oth))
    print("CP^1 separation image-vs-image     : %.1f deg (shared column)" %
          cp1_angle(col_img, col_img))

    # Coherent template-informed delay recovery on the combined stream.
    templ = np.fft.irfft(h, n=cfg.n_t)
    corr = np.correlate(combined, templ, mode="full")
    env = np.abs(corr)
    lags = np.arange(-cfg.n_t + 1, cfg.n_t) / cfg.f_s
    # Two dominant peaks -> two arrival times.
    order = np.argsort(-env)
    peaks = []
    for idx in order:
        if all(abs(lags[idx] - p) > 0.05 for p in peaks):
            peaks.append(lags[idx])
        if len(peaks) == 2:
            break
    peaks.sort()
    dt = abs(peaks[1] - peaks[0]) if len(peaks) == 2 else float("nan")
    print(f"recovered image delay: {dt:.3f} s (true {args.delay:.3f} s)")


if __name__ == "__main__":
    main()
