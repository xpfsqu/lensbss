#!/usr/bin/env python3
"""(Optional) train the SIREN amplification-factor surrogate.

The surrogate is *reused infrastructure* from Zhang et al. (2026); this script
is provided for completeness so the fast-evaluation path can be regenerated
locally. It trains a small SIREN to regress the real and imaginary parts of
F(omega, y) on an exact grid and writes ``lensbss/weights.npz``.

A full-quality surrogate (median error ~2.6e-3) needs a GPU and the arbitrary-
precision reference (mpmath). Without mpmath this script trains against the
geometric-optics limit, which is adequate for the simulation but not the
production accuracy quoted in the paper.

This is a NumPy training loop kept dependency-light on purpose; swap in your
preferred autodiff framework for serious training.
"""

from __future__ import annotations

import numpy as np

from lensbss.lensing import _HAVE_MPMATH, _F_geo


def target(omega, y):
    if _HAVE_MPMATH:
        from lensbss.lensing import _F_scalar
        return np.array([_F_scalar(float(w), float(y)) for w in omega])
    return _F_geo(omega, y)


def main(n_grid=64, n_layers=4, width=128, epochs=200, lr=1e-3, seed=0):
    rng = np.random.default_rng(seed)
    w_grid = np.linspace(0.05, 30.0, n_grid)
    y_grid = np.linspace(0.08, 1.2, n_grid)
    W, Y = np.meshgrid(w_grid, y_grid, indexing="ij")
    X = np.stack([np.log(W).ravel(), Y.ravel()], axis=-1)
    T = np.concatenate([target(W[:, k], y_grid[k])[:, None]
                        for k in range(n_grid)], axis=0)  # placeholder assembly
    # NOTE: for brevity this driver only *scaffolds* the training data and
    # network shape; a real training loop (Adam + sine init) belongs here.
    print("Assembled training grid:", X.shape, "->", T.shape)
    print("This scaffold does not write weights.npz; the package runs with the "
          "exact/geometric fallback. Plug in an autodiff trainer to produce a "
          "production surrogate as in Zhang et al. (2026).")


if __name__ == "__main__":
    main()
