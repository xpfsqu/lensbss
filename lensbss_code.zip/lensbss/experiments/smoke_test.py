#!/usr/bin/env python3
"""Fast end-to-end smoke test.

Runs a short version of every stage and checks that the pipeline produces
finite, sensible outputs.  Intended for CI and for a first-run sanity check;
it does not reproduce the paper's numbers.  Exit code 0 on success.
"""

from __future__ import annotations

import sys
import numpy as np
import warnings
warnings.filterwarnings("ignore")

from lensbss import default_config
from lensbss.separation import build_fiducial, separate
from lensbss.metrics import match_and_score, cp1_angle
from lensbss.lensing import amplification_factor


def main():
    ok = True
    cfg = default_config(T=2.0)  # shorter segment for speed

    # 1. amplification factor evaluates and is ~1 at low frequency
    F = amplification_factor(np.array([1.0, 50.0, 200.0]), 500.0, 0.3,
                             use_surrogate=True)
    assert np.all(np.isfinite(F)), "amplification factor not finite"
    print("[ok] amplification factor:", np.round(np.abs(F), 3))

    # 2. build + separate
    scene = build_fiducial(cfg, snr_db=40.0, seed=3)
    res = separate(scene["channels"], cfg, n_expected=3)
    assert res["columns"].shape[1] == 3, "expected 3 recovered columns"
    print("[ok] recovered", res["columns"].shape[1], "mixing columns")

    # 3. metrics
    sdrs = match_and_score(list(scene["sources"]), list(res["estimates"]))
    assert np.all(np.isfinite(sdrs)), "SDR not finite"
    assert np.mean(sdrs) > 2.0, "mean SDR unexpectedly low"
    print("[ok] mean phase-aligned SDR: %.1f dB" % np.mean(sdrs))

    # 4. column angle metric sanity
    a = cp1_angle(np.array([1, 0], complex), np.array([0, 1], complex))
    assert abs(a - 90.0) < 1e-6, "CP1 angle wrong"
    print("[ok] CP^1 angle metric")

    print("\nSMOKE TEST PASSED" if ok else "SMOKE TEST FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
