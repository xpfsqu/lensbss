#!/usr/bin/env python3
"""Whitening study and PSD-mismatch ablation (paper Section 7.1--7.2).

Sweeps the network SNR with and without whitening, then repeats with a
mismatched PSD, showing the whitening plateau is robust to PSD shape.
"""

from __future__ import annotations

import numpy as np
import warnings
warnings.filterwarnings("ignore")

from lensbss import default_config
from lensbss.separation import build_fiducial, separate
from lensbss.psd import whiten
from lensbss.metrics import match_and_score


def run(snr, whiten_psd, seed):
    cfg = default_config()
    scene = build_fiducial(cfg, snr_db=snr, seed=seed)
    ch = scene["channels"]
    truths = list(scene["sources"])
    if whiten_psd is not None:
        ch = np.stack([whiten(c, cfg, psd_name=whiten_psd) for c in ch], axis=0)
        truths = [whiten(t, cfg, psd_name=whiten_psd) for t in truths]
    res = separate(ch, cfg, n_expected=3)
    return float(np.mean(match_and_score(truths, list(res["estimates"]))))


def main():
    print("=== Whitening vs SNR ===")
    for snr in [40, 28, 16, 6]:
        with_w = np.mean([run(snr, "etd", s) for s in range(3)])
        no_w = np.mean([run(snr, None, s) for s in range(3)])
        print(f"SNR {snr:>2} dB | whitened {with_w:5.1f} dB | unwhitened {no_w:5.1f} dB")

    print("\n=== PSD-mismatch ablation (SNR 20 dB) ===")
    for name in ["etd", "aligo"]:
        val = np.mean([run(20, name, s) for s in range(3)])
        print(f"whiten with {name:>5}: {val:5.1f} dB")


if __name__ == "__main__":
    main()
