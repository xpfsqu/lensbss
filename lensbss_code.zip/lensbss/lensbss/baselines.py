"""Separation baselines for honest comparison (paper Section 6).

* FastICA - cannot represent an underdetermined mixing; included to show it
  fails on N>M.
* DUET - assumes anechoic (amplitude--delay) real mixing; fails on near-zero
  delay complex columns.
* CLEAN-like sequential subtraction - a *non-blind* upper reference that
  requires every source template a priori.
"""

from __future__ import annotations

import numpy as np


def fastica_separate(channels, n_sources, seed=0):
    """FastICA baseline (square/overdetermined only)."""
    from sklearn.decomposition import FastICA
    X = np.real(channels).T  # (n_t, n_det)
    k = min(n_sources, X.shape[1])
    ica = FastICA(n_components=k, random_state=seed, whiten="unit-variance",
                  max_iter=500)
    S = ica.fit_transform(X).T
    # Pad to n_sources so downstream matching is uniform.
    if S.shape[0] < n_sources:
        S = np.vstack([S, np.zeros((n_sources - S.shape[0], S.shape[1]))])
    return S


def duet_separate(channels, n_sources, cfg):
    """DUET baseline assuming anechoic amplitude--delay mixing."""
    from .sca import stft, istft
    f, t, Z1 = stft(channels[0], cfg)
    _, _, Z2 = stft(channels[1], cfg)
    ratio = Z2 / (Z1 + 1e-30)
    amp = np.abs(ratio)
    # DUET delay estimate assumes a real delay; with complex columns this is
    # ill-defined, which is precisely the failure mode we demonstrate.
    delay = -np.angle(ratio) / (2 * np.pi * (f[:, None] + 1e-30))
    feats = np.stack([np.log(amp).ravel(), delay.ravel()], axis=-1)
    from sklearn.cluster import KMeans
    lab = KMeans(n_clusters=n_sources, n_init=5, random_state=0).fit_predict(feats)
    lab = lab.reshape(Z1.shape)
    out = []
    for k in range(n_sources):
        M = (lab == k).astype(float)
        out.append(np.real(istft(M * Z1, cfg)))
    return np.stack(out, axis=0)


def clean_subtract(channels, templates, cfg):
    """Non-blind CLEAN-like sequential subtraction using known templates."""
    from .sca import stft, istft
    residual = channels.copy()
    out = []
    for h in templates:
        f, t, Zr = stft(residual[0], cfg)
        _, _, Zh = stft(h, cfg)
        gain = np.vdot(Zh, Zr) / (np.vdot(Zh, Zh) + 1e-30)
        rec = np.real(istft(gain * Zh, cfg))
        out.append(rec)
        residual = residual - np.stack([gain * h, gain * h], axis=0)
    return np.stack(out, axis=0)
