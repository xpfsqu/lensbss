"""Separation quality metrics.

Because complex/anechoic BSS recovers each source only up to a global phase
(paper Section 2.4), separation quality is measured with a *phase-aligned*
signal-to-distortion ratio: the residual global phase is minimised before the
distortion is computed.
"""

from __future__ import annotations

import numpy as np
from scipy.signal import hilbert


def cp1_angle(a: np.ndarray, b: np.ndarray) -> float:
    """Angle (deg) between two directions on the complex projective line."""
    a = a / (np.linalg.norm(a) + 1e-30)
    b = b / (np.linalg.norm(b) + 1e-30)
    cosang = np.abs(np.vdot(a, b))
    return float(np.degrees(np.arccos(np.clip(cosang, 0.0, 1.0))))


def phase_aligned_sdr(true: np.ndarray, est: np.ndarray) -> float:
    """Phase-aligned SDR (dB) between a real reference and a recovery.

    The recovered analytic source may be rotated by a global phase, mixing the
    signal with its Hilbert transform.  We minimise over that phase and over a
    real scale before measuring the distortion.
    """
    t_an = hilbert(np.asarray(true, dtype=float))
    e_an = hilbert(np.asarray(est, dtype=float))
    # Optimal complex scale (phase + amplitude) aligning e to t.
    denom = np.vdot(e_an, e_an)
    if np.abs(denom) < 1e-30:
        return -np.inf
    scale = np.vdot(e_an, t_an) / denom
    aligned = np.real(scale * e_an)
    num = np.sum(np.asarray(true, dtype=float) ** 2)
    err = np.sum((np.asarray(true, dtype=float) - aligned) ** 2)
    return float(10.0 * np.log10(num / (err + 1e-30)))


def waveform_correlation(true: np.ndarray, est: np.ndarray) -> float:
    """Phase-insensitive normalised correlation between two real signals."""
    t_an = hilbert(np.asarray(true, dtype=float))
    e_an = hilbert(np.asarray(est, dtype=float))
    return float(np.abs(np.vdot(t_an, e_an)) /
                 (np.linalg.norm(t_an) * np.linalg.norm(e_an) + 1e-30))


def match_and_score(truths, ests):
    """Greedy best-permutation matching of estimates to truths; return SDRs."""
    n = len(truths)
    m = len(ests)
    score = np.full((n, m), -np.inf)
    for i in range(n):
        for j in range(m):
            score[i, j] = phase_aligned_sdr(truths[i], ests[j])
    used = set()
    out = []
    for i in range(n):
        order = np.argsort(-score[i])
        for j in order:
            if j not in used:
                used.add(j)
                out.append(score[i, j])
                break
    return np.array(out)
