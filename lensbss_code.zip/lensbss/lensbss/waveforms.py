"""Compact-binary waveforms.

These are *research* waveforms used for a separation study: a 3.5 post-Newtonian
``TaylorF2`` inspiral phase and a lightweight phenomenological
inspiral--merger--ringdown (IMR) model.  They reproduce the qualitative
time--frequency morphology of real chirps but are **not** calibrated LIGO
Algorithm Library templates and must not be used for production parameter
estimation (see the paper's limitations section).
"""

from __future__ import annotations

import numpy as np

from .config import G, C, MSUN


def _chirp_mass(m1: float, m2: float) -> float:
    return (m1 * m2) ** 0.6 / (m1 + m2) ** 0.2


def taylorf2(
    freqs: np.ndarray,
    m1: float,
    m2: float,
    distance_mpc: float = 400.0,
    tc: float = 0.0,
    phic: float = 0.0,
    f_low: float = 20.0,
) -> np.ndarray:
    """Frequency-domain 3.5 PN ``TaylorF2`` inspiral waveform.

    Parameters
    ----------
    freqs
        Non-negative frequency grid [Hz].
    m1, m2
        Component masses [solar masses].
    distance_mpc
        Luminosity distance [Mpc]; sets only the overall amplitude scale.
    tc, phic
        Coalescence time [s] and phase [rad].
    f_low
        Lower cutoff [Hz]; the waveform is zero below this frequency.

    Returns
    -------
    numpy.ndarray (complex)
        Strain :math:`\\tilde h(f)` on ``freqs``.
    """
    m1_si, m2_si = m1 * MSUN, m2 * MSUN
    mt = m1_si + m2_si
    eta = m1_si * m2_si / mt ** 2
    mc = _chirp_mass(m1, m2) * MSUN

    f = np.asarray(freqs, dtype=float)
    mask = f >= max(f_low, 1e-6)
    v = np.zeros_like(f)
    v[mask] = (np.pi * G * mt * f[mask] / C ** 3) ** (1.0 / 3.0)

    # 3.5PN TaylorF2 phase coefficients (dimensionless in powers of v).
    psi = np.zeros_like(f)
    vv = v[mask]
    pref = 3.0 / (128.0 * eta * vv ** 5)
    c0 = 1.0
    c2 = (3715.0 / 756.0 + 55.0 / 9.0 * eta)
    c3 = -16.0 * np.pi
    c4 = (15293365.0 / 508032.0 + 27145.0 / 504.0 * eta + 3085.0 / 72.0 * eta ** 2)
    psi[mask] = pref * (
        c0
        + c2 * vv ** 2
        + c3 * vv ** 3
        + c4 * vv ** 4
    )

    # Restricted PN amplitude ~ f^{-7/6}.
    dist = distance_mpc * 3.085_677_581e22  # Mpc -> m
    amp = np.zeros_like(f)
    amp0 = np.sqrt(5.0 / 24.0) * (G * mc / C ** 3) ** (5.0 / 6.0) / (
        np.pi ** (2.0 / 3.0) * dist / C
    )
    amp[mask] = amp0 * f[mask] ** (-7.0 / 6.0)

    phase = 2.0 * np.pi * f * tc - phic - psi + np.pi / 4.0
    h = amp * np.exp(-1j * phase)
    h[~mask] = 0.0
    return h


def imr_phenom(
    freqs: np.ndarray,
    m1: float,
    m2: float,
    distance_mpc: float = 400.0,
    tc: float = 0.0,
    phic: float = 0.0,
    f_low: float = 20.0,
) -> np.ndarray:
    """Lightweight phenomenological IMR waveform.

    The inspiral is the :func:`taylorf2` phase; a smooth tapered Lorentzian
    ringdown is stitched on above an estimated dominant-mode frequency so that
    merger and ringdown power is present.  This is deliberately simple; it only
    needs to provide realistic broadband TF morphology for the separation tests.
    """
    h = taylorf2(freqs, m1, m2, distance_mpc, tc, phic, f_low)

    f = np.asarray(freqs, dtype=float)
    mt = (m1 + m2) * MSUN
    # Approximate dominant ringdown frequency (Schwarzschild-like scaling).
    f_rd = C ** 3 / (2.0 * np.pi * G * mt) * 0.08
    q = 12.0
    lorentz = 1.0 / (1.0 + ((f - f_rd) / (f_rd / q)) ** 2)
    taper = 0.5 * (1.0 + np.tanh((f - 0.6 * f_rd) / (0.1 * f_rd)))
    # Blend a ringdown tail onto the inspiral amplitude.
    amp_scale = 1.0 + 0.6 * taper * lorentz
    return h * amp_scale
