"""End-to-end separation pipeline and a fiducial mixture builder."""

from __future__ import annotations

import numpy as np

from .config import Config
from .waveforms import taylorf2, imr_phenom
from .lensing import amplification_factor
from .mixing import et_mixing_columns, mix_sources, column_from_angles
from .sca import rank_one_ssp, cluster_directions, sparse_recover
from .psd import colored_noise


def _time_domain_source(cfg, m1, m2, tc, phic, lensed=None, imr=False):
    """Build a single real source time series on the segment grid."""
    freqs = np.fft.rfftfreq(cfg.n_t, d=1.0 / cfg.f_s)
    wf = imr_phenom if imr else taylorf2
    H = wf(freqs, m1, m2, tc=tc, phic=phic, f_low=cfg.f_low)
    if lensed is not None:
        m_lz, y = lensed
        H = H * amplification_factor(freqs, m_lz, y, use_surrogate=True)
    x = np.fft.irfft(H, n=cfg.n_t)
    x /= np.std(x) + 1e-30
    return x


def build_fiducial(cfg: Config, snr_db: float = 34.0, imr: bool = False, seed=None):
    """Construct the fiducial three-source ET mixture used in the paper."""
    rng = np.random.default_rng(cfg.seed if seed is None else seed)
    # Sources placed at controlled, well-separated CP^1 mixing directions
    # (alpha = amplitude-ratio angle in radians, beta = relative phase).  The
    # two heavier sources share a similar alpha but carry opposite phase beta,
    # exactly the case that a real-amplitude test would merge and the complex
    # treatment separates.
    specs = [
        dict(m1=19, m2=17, tc=2.00, phic=0.3, lensed=(500.0, 0.30),
             alpha=np.deg2rad(25.0), beta=+0.60),
        dict(m1=33, m2=30, tc=2.05, phic=1.1, lensed=None,
             alpha=np.deg2rad(58.0), beta=-1.97),
        dict(m1=11, m2=9, tc=1.90, phic=2.0, lensed=None,
             alpha=np.deg2rad(62.0), beta=+1.73),
    ]
    src = np.stack([
        _time_domain_source(cfg, s["m1"], s["m2"], s["tc"], s["phic"],
                            lensed=s["lensed"], imr=imr)
        for s in specs
    ], axis=0)

    columns = np.stack([column_from_angles(s["alpha"], s["beta"]) for s in specs],
                       axis=-1)
    mixed = mix_sources(src, columns)  # (2, n_t) complex

    # Add coloured noise scaled to the requested network SNR.
    sig_pow = np.sum(np.abs(mixed) ** 2)
    noise = np.stack([colored_noise(cfg, rng) for _ in range(2)], axis=0)
    noise = noise.astype(complex)
    noise_pow = np.sum(np.abs(noise) ** 2)
    target = sig_pow / (10 ** (snr_db / 10.0))
    noise *= np.sqrt(target / (noise_pow + 1e-30))
    channels = mixed + noise
    return dict(channels=channels, sources=src, columns=columns, specs=specs)


def separate(channels, cfg, n_expected=3):
    """Run the covariance SSP + clustering + sparse-recovery pipeline.

    Returns
    -------
    dict
        ``estimates`` (recovered sources), ``columns`` (estimated columns),
        ``ssp`` (single-source-point diagnostics).
    """
    ssp = rank_one_ssp(channels, cfg)
    columns, labels, scatter = cluster_directions(ssp, cfg, n_expected=n_expected)
    if columns.shape[1] == 0:
        raise RuntimeError("no clusters found; check eta / DBSCAN parameters")
    est = sparse_recover(channels, columns, cfg)
    return dict(estimates=est, columns=columns, ssp=ssp, scatter=scatter,
                labels=labels)
