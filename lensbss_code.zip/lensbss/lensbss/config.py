"""Global configuration and physical constants.

All experiment drivers read their defaults from :func:`default_config`, so a
single edit here (or a YAML file passed on the command line) changes every
downstream script.  Random seeds are stored explicitly so that every figure in
the paper is reproducible bit-for-bit on a given NumPy version.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Tuple

# ---------------------------------------------------------------------------
# Physical constants (SI)
# ---------------------------------------------------------------------------
G = 6.674_30e-11          # gravitational constant [m^3 kg^-1 s^-2]
C = 2.997_924_58e8        # speed of light [m s^-1]
MSUN = 1.988_41e30        # solar mass [kg]


@dataclass
class Config:
    """Simulation and analysis configuration.

    Parameters
    ----------
    f_s
        Sample rate [Hz].
    T
        Segment duration [s].
    f_low
        High-pass / analysis starting frequency [Hz].
    f_high
        Upper analysis frequency [Hz]; ``None`` uses the Nyquist frequency.
    n_stft
        STFT window length (samples).
    hop
        STFT hop size (samples).
    eta
        Rank-one conditioning threshold ``lambda_min / lambda_max`` below which
        a time-frequency cell is declared a single-source point.
    dbscan_eps, dbscan_min_samples
        DBSCAN parameters used to cluster single-source-point directions in the
        (alpha, beta) plane.
    psd
        Name of the design PSD used for coloured noise and whitening.  ``etd``
        is the ET-D sensitivity of Hild et al. (2011).
    seed
        Master random seed.
    """

    f_s: float = 2048.0
    T: float = 4.0
    f_low: float = 20.0
    f_high: float | None = None

    n_stft: int = 256
    hop: int = 64

    eta: float = 0.05
    dbscan_eps: float = 0.08
    dbscan_min_samples: int = 20

    psd: str = "etd"
    seed: int = 20240101

    @property
    def n_t(self) -> int:
        """Number of time samples in a segment."""
        return int(round(self.f_s * self.T))

    @property
    def band(self) -> Tuple[float, float]:
        hi = self.f_high if self.f_high is not None else 0.5 * self.f_s
        return (self.f_low, hi)

    def to_dict(self) -> dict:
        return asdict(self)


def default_config(**overrides) -> Config:
    """Return the fiducial configuration used in the paper, with overrides.

    Examples
    --------
    >>> cfg = default_config(f_low=10.0, T=8.0)   # lower-frequency cross-check
    >>> cfg.n_t
    16384
    """
    cfg = Config()
    for key, value in overrides.items():
        if not hasattr(cfg, key):
            raise KeyError(f"unknown config field: {key!r}")
        setattr(cfg, key, value)
    return cfg
