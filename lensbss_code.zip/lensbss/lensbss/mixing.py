"""Complex detector mixing for a co-located Einstein Telescope network.

The three nested ET interferometers sit at the same site with arms rotated by
60 degrees, so the geometric time delays are essentially zero but the mixing
columns are still *complex*: the antenna-pattern combination together with the
source polarization phase gives each source a complex direction in channel
space.  This is the crux of the paper (Section 2): real-valued mixing models are
inadequate.
"""

from __future__ import annotations

import numpy as np


def antenna_response(psi: float, theta: float, phi: float, rot: float):
    """Plus/cross antenna-pattern factors for an L-shaped detector.

    Parameters
    ----------
    psi
        Polarization angle [rad].
    theta, phi
        Source sky location (polar, azimuth) [rad] in the detector frame.
    rot
        In-plane rotation of the detector arms [rad] (60 deg steps for the ET
        triangle).
    """
    ph = phi - rot
    fp = 0.5 * (1.0 + np.cos(theta) ** 2) * np.cos(2 * ph) * np.cos(2 * psi) \
        - np.cos(theta) * np.sin(2 * ph) * np.sin(2 * psi)
    fc = 0.5 * (1.0 + np.cos(theta) ** 2) * np.cos(2 * ph) * np.sin(2 * psi) \
        + np.cos(theta) * np.sin(2 * ph) * np.cos(2 * psi)
    return fp, fc


def et_mixing_columns(sources, n_det: int = 2, rng=None) -> np.ndarray:
    """Complex mixing columns for a list of sources in an ET network.

    Parameters
    ----------
    sources
        Sequence of dicts with keys ``theta``, ``phi``, ``psi`` (sky location
        and polarization) and ``pol_phase`` (an intrinsic polarization phase
        that makes the column complex).
    n_det
        Number of co-located interferometers used (2 or 3).

    Returns
    -------
    numpy.ndarray, shape (n_det, n_sources), complex
        Constant (frequency-independent) complex mixing columns.
    """
    rots = [0.0, np.deg2rad(60.0), np.deg2rad(120.0)][:n_det]
    cols = np.zeros((n_det, len(sources)), dtype=complex)
    for j, s in enumerate(sources):
        for a, rot in enumerate(rots):
            fp, fc = antenna_response(s["psi"], s["theta"], s["phi"], rot)
            amp = fp - 1j * fc  # complex polarization combination
            cols[a, j] = amp * np.exp(1j * s.get("pol_phase", 0.0))
        # Normalise column to unit length (direction on CP^{n_det-1}).
        cols[:, j] /= np.linalg.norm(cols[:, j]) + 1e-30
    return cols


def column_from_angles(alpha: float, beta: float) -> np.ndarray:
    """Unit complex 2-column from a CP^1 point ``(alpha, beta)``.

    ``alpha`` is the amplitude-ratio angle and ``beta`` the relative phase, so
    the column is ``[cos alpha, sin alpha * exp(i beta)]``.  This lets a driver
    place sources at controlled, well-separated mixing directions (equivalent to
    specific sky positions and polarizations).
    """
    return np.array([np.cos(alpha), np.sin(alpha) * np.exp(1j * beta)],
                    dtype=complex)


def mix_sources(source_ts: np.ndarray, columns: np.ndarray) -> np.ndarray:
    """Mix real source time series through complex columns.

    A complex column applied to a real source is realised in the time domain
    through the analytic signal: the observed strain is
    ``Re[a_aj * s_j^analytic(t)] = |a_aj|(cos phi_aj s_j - sin phi_aj H[s_j])``.
    The detector strains are therefore **real**; the complex structure appears
    in the STFT, where the single-source ratio ``X_2/X_1`` equals the complex
    column ratio ``a_2j/a_1j`` (paper Section 2).

    Parameters
    ----------
    source_ts
        Array of shape ``(n_sources, n_t)`` of real source strains.
    columns
        Complex mixing matrix ``(n_det, n_sources)``.

    Returns
    -------
    numpy.ndarray, shape (n_det, n_t), real
        Real detector strains.
    """
    from scipy.signal import hilbert
    analytic = hilbert(source_ts, axis=-1)  # real -> analytic
    return np.real(columns @ analytic)
