"""Wave-optics point-mass amplification factor.

The isolated point-mass amplification factor is the confluent-hypergeometric
expression of Nakamura & Deguchi (1999) and Takahashi & Nakamura (2003).  Naive
double-precision evaluation of ``1F1`` cancels catastrophically at large omega,
so the reference implementation here uses arbitrary precision (mpmath).  A fast
neural surrogate with the same interface lives in :mod:`lensbss.surrogate`.
"""

from __future__ import annotations

import numpy as np

from .config import G, C, MSUN

try:
    import mpmath as mp
    _HAVE_MPMATH = True
except Exception:  # pragma: no cover
    _HAVE_MPMATH = False


def dimensionless_frequency(f: np.ndarray, m_lz_msun: float) -> np.ndarray:
    r"""Dimensionless frequency :math:`\omega = 8\pi G M_{Lz} f / c^3`.

    ``m_lz_msun`` is the *redshifted* lens mass :math:`M_{Lz}=(1+z_L)M_L` in
    solar masses; the lens redshift is already absorbed, so no extra factor of
    ``(1+z_L)`` is applied.
    """
    m_lz = m_lz_msun * MSUN
    return 8.0 * np.pi * G * m_lz * np.asarray(f, dtype=float) / C ** 3


def _phi_m(y: float) -> float:
    """Phase of the minimum-time image for a point-mass lens."""
    xm = 0.5 * (y + np.sqrt(y ** 2 + 4.0))
    return (xm - y) ** 2 / 2.0 - np.log(xm)


def _F_geo(w: np.ndarray, y: float) -> np.ndarray:
    r"""Geometric-optics amplification factor (NumPy, no mpmath).

    Valid for :math:`\omega \gg 1`, this two-image limit captures the
    magnifications and the wave-optics interference fringe that a separation
    study needs.  It is the default when mpmath is unavailable, and a fast
    fallback for the surrogate:

    .. math:: F(w,y) = |\mu_+|^{1/2} - i\,|\mu_-|^{1/2}\, e^{\,i w \Delta T}.
    """
    w = np.asarray(w, dtype=float)
    root = np.sqrt(y ** 2 + 4.0)
    mu_p = 0.5 + (y ** 2 + 2.0) / (2.0 * y * root)
    mu_m = 0.5 - (y ** 2 + 2.0) / (2.0 * y * root)
    dT = 0.5 * y * root + np.log((root + y) / (root - y))
    F = np.sqrt(np.abs(mu_p)) - 1j * np.sqrt(np.abs(mu_m)) * np.exp(1j * w * dT)
    F[w <= 0] = 1.0
    return F


def _F_scalar(w: float, y: float, dps: int = 30) -> complex:
    """Exact F(omega, y) at a single omega via arbitrary precision."""
    if w <= 0.0:
        return 1.0 + 0.0j
    with mp.workdps(dps):
        iw2 = 1j * mp.mpf(w) / 2
        pref = mp.e ** (
            mp.pi * mp.mpf(w) / 4
            + iw2 * (mp.log(mp.mpf(w) / 2) - 2 * _phi_m(y))
        )
        val = pref * mp.gamma(1 - iw2) * mp.hyp1f1(iw2, 1, iw2 * y ** 2)
    return complex(val)


def amplification_factor(
    f: np.ndarray,
    m_lz_msun: float,
    y: float,
    use_surrogate: bool = False,
    dps: int = 30,
) -> np.ndarray:
    """Amplification factor F on a frequency grid.

    Parameters
    ----------
    f
        Frequency grid [Hz].
    m_lz_msun
        Redshifted lens mass [solar masses].
    y
        Dimensionless impact parameter.
    use_surrogate
        If ``True`` use the trained SIREN surrogate (fast); otherwise use the
        arbitrary-precision reference (accurate).
    dps
        mpmath working precision (decimal places) for the reference path.
    """
    w = dimensionless_frequency(f, m_lz_msun)
    if use_surrogate:
        from .surrogate import Surrogate
        return Surrogate.default().evaluate(w, y)
    if not _HAVE_MPMATH:
        # No arbitrary-precision backend: fall back to the geometric-optics
        # limit so the package runs out of the box.  Install mpmath for the
        # full-precision confluent-hypergeometric reference.
        return _F_geo(w, y)
    out = np.ones_like(w, dtype=complex)
    nz = w > 0
    out[nz] = np.array([_F_scalar(float(wi), y, dps) for wi in w[nz]])
    return out
