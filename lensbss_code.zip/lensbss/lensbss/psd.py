"""Design noise power spectral densities and coloured-noise generation.

The reference sensitivity is the ET-D curve of Hild et al. (2011), which is the
PSD adopted for the ET conceptual-design and science studies (Punturo et al.
2010; Abac et al. 2025).  A simple analytic aLIGO-like curve is provided for the
whitening-mismatch ablation.
"""

from __future__ import annotations

import numpy as np


def et_d_psd(f: np.ndarray) -> np.ndarray:
    """Analytic ET-D-like strain PSD [1/Hz].

    A compact broken-power-law fit that reproduces the ET-D shape: a steep
    low-frequency wall, a bucket around 100--300 Hz, and a rising
    shot-noise tail.  Adequate for whitening and coloured-noise studies; use the
    tabulated official curve for production work.
    """
    f = np.asarray(f, dtype=float)
    x = np.clip(f, 1.0, None) / 100.0
    # Amplitude spectral density model (dimensionless-ish, arbitrary norm).
    asd = 1e-24 * (
        0.03 * x ** -4.05
        + 1.0 * x ** -0.6
        + 0.5 * x ** 1.1
        + 0.02 * x ** 2.0
    )
    return asd ** 2


def aligo_psd(f: np.ndarray) -> np.ndarray:
    """Analytic aLIGO-like strain PSD [1/Hz] (for mismatch ablation)."""
    f = np.asarray(f, dtype=float)
    x = np.clip(f, 1.0, None) / 215.0
    asd = 1e-23 * (x ** -4.14 - 5.0 * x ** -2 + 111.0 * (1.0 - x ** 2 + 0.5 * x ** 4)
                   / (1.0 + 0.5 * x ** 2))
    asd = np.abs(asd)
    return asd ** 2


def get_psd(name: str):
    return {"etd": et_d_psd, "aligo": aligo_psd}[name]


def colored_noise(cfg, rng: np.random.Generator, psd_name: str | None = None) -> np.ndarray:
    """Generate a coloured-noise time series matching ``cfg`` and a design PSD."""
    psd_name = psd_name or cfg.psd
    n = cfg.n_t
    freqs = np.fft.rfftfreq(n, d=1.0 / cfg.f_s)
    psd = get_psd(psd_name)(freqs)
    # Two-sided white draw, coloured by sqrt(PSD * fs / 2).
    sigma = np.sqrt(psd * cfg.f_s / 2.0)
    re = rng.standard_normal(freqs.size)
    im = rng.standard_normal(freqs.size)
    spec = sigma * (re + 1j * im)
    spec[0] = spec[0].real
    if n % 2 == 0:
        spec[-1] = spec[-1].real
    return np.fft.irfft(spec, n=n)


def whiten(x: np.ndarray, cfg, psd_name: str | None = None) -> np.ndarray:
    """Whiten a time series by a design PSD."""
    psd_name = psd_name or cfg.psd
    n = x.size
    freqs = np.fft.rfftfreq(n, d=1.0 / cfg.f_s)
    psd = get_psd(psd_name)(freqs)
    spec = np.fft.rfft(x)
    spec = spec / np.sqrt(psd + 1e-50)
    return np.fft.irfft(spec, n=n)
