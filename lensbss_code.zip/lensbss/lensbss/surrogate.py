"""Neural surrogate interface for the amplification factor.

Following Zhang et al. (2026), a sinusoidal-representation network (SIREN) is
used as a drop-in, fast replacement for the arbitrary-precision amplification
factor.  The surrogate is treated here as *reused computational
infrastructure*, not as a contribution of this paper: this module provides a
minimal NumPy SIREN and a training/loading interface so the separation and
inference pipelines can run without a heavyweight deep-learning dependency.

If a pre-trained checkpoint (``weights.npz``) is present it is loaded; otherwise
:meth:`Surrogate.default` falls back transparently to the exact evaluator so
that every driver script still runs out of the box.  The reported timing and
accuracy figures in the paper come from the trained network of Zhang et al.
(2026); retraining to those numbers is done with ``experiments/train_surrogate.py``.
"""

from __future__ import annotations

import os
import numpy as np


def _siren_layer(x, w, b, w0=1.0, last=False):
    z = x @ w + b
    return z if last else np.sin(w0 * z)


class Surrogate:
    """Minimal SIREN surrogate F(omega, y) -> complex.

    The network maps ``(omega, y)`` to the real and imaginary parts of ``F``.
    Weights are stored in a ``.npz`` checkpoint.  Without a checkpoint the
    surrogate defers to the exact evaluator, keeping the public interface
    identical.
    """

    def __init__(self, weights: dict | None = None, w0: float = 30.0):
        self.weights = weights
        self.w0 = w0

    # -- construction ------------------------------------------------------
    @classmethod
    def default(cls) -> "Surrogate":
        here = os.path.dirname(__file__)
        ckpt = os.path.join(here, "weights.npz")
        if os.path.exists(ckpt):
            data = np.load(ckpt)
            weights = {k: data[k] for k in data.files}
            return cls(weights=weights, w0=float(weights.get("w0", 30.0)))
        return cls(weights=None)

    # -- evaluation --------------------------------------------------------
    def evaluate(self, omega: np.ndarray, y: float) -> np.ndarray:
        """Return complex F on a dimensionless-frequency grid ``omega``."""
        omega = np.asarray(omega, dtype=float)
        if self.weights is None:
            # Transparent fallback when no trained checkpoint is present: use
            # the arbitrary-precision reference if mpmath is available, else the
            # NumPy geometric-optics limit.  Either way the interface is
            # identical to the trained SIREN.
            from .lensing import _HAVE_MPMATH, _F_scalar, _F_geo
            if _HAVE_MPMATH:
                out = np.ones_like(omega, dtype=complex)
                nz = omega > 0
                out[nz] = np.array([_F_scalar(float(w), y) for w in omega[nz]])
                return out
            return _F_geo(omega, y)

        x = np.stack([np.log(np.clip(omega, 1e-6, None)),
                      np.full_like(omega, y)], axis=-1)
        w = self.weights
        n_layers = int(w["n_layers"])
        h = x
        for i in range(n_layers):
            last = (i == n_layers - 1)
            h = _siren_layer(h, w[f"W{i}"], w[f"b{i}"],
                             w0=self.w0 if i == 0 else 1.0, last=last)
        return h[..., 0] + 1j * h[..., 1]


def benchmark(n: int = 2000, seed: int = 0) -> dict:
    """Rough timing of surrogate vs. exact evaluation (informational)."""
    import time
    from .lensing import amplification_factor
    rng = np.random.default_rng(seed)
    f = np.linspace(20, 1024, n)
    t0 = time.perf_counter()
    amplification_factor(f, 500.0, 0.3, use_surrogate=True)
    t_surr = time.perf_counter() - t0
    t1 = time.perf_counter()
    amplification_factor(f[:50], 500.0, 0.3, use_surrogate=False)
    t_exact = (time.perf_counter() - t1) * (n / 50)
    return {"t_surrogate_s": t_surr, "t_exact_s_est": t_exact,
            "speedup": t_exact / max(t_surr, 1e-9)}
