"""Lensing inference with a profiled complex amplitude.

We fit the redshifted lens mass and impact parameter ``(M_Lz, y)`` to a
separated (or clean) source spectrum.  The complex amplitude ``A`` multiplying
``F(omega, y) h(f)`` is profiled out in closed form, which simultaneously
absorbs the BSS global-phase ambiguity (paper Section 2.4).
"""

from __future__ import annotations

import numpy as np

from .lensing import amplification_factor
from .psd import get_psd


def _profiled_residual(data_spec, model_spec, weight):
    """Return the noise-weighted residual after profiling a complex amplitude."""
    w = weight
    num = np.sum(w * np.conj(model_spec) * data_spec)
    den = np.sum(w * np.abs(model_spec) ** 2) + 1e-300
    A = num / den
    resid = data_spec - A * model_spec
    chi2 = np.sum(w * np.abs(resid) ** 2).real
    return chi2, A


def lensing_loglike(params, data_spec, template_spec, freqs, cfg,
                    use_surrogate=True):
    """Gaussian log-likelihood for ``params = (M_Lz, y)`` with profiled A."""
    m_lz, y = params
    if m_lz <= 0 or not (0.02 < y < 2.0):
        return -np.inf
    F = amplification_factor(freqs, m_lz, y, use_surrogate=use_surrogate)
    model = F * template_spec
    psd = get_psd(cfg.psd)(freqs)
    weight = 1.0 / (psd + 1e-50)
    band = (freqs >= cfg.band[0]) & (freqs <= cfg.band[1])
    chi2, _ = _profiled_residual(data_spec[band], model[band], weight[band])
    return -0.5 * chi2


def grid_fit(data_spec, template_spec, freqs, cfg, m_grid, y_grid,
             use_surrogate=True):
    """Coarse-grid maximum-likelihood point estimate and chi^2 landscape."""
    L = np.full((len(m_grid), len(y_grid)), -np.inf)
    for i, m in enumerate(m_grid):
        for k, y in enumerate(y_grid):
            L[i, k] = lensing_loglike((m, y), data_spec, template_spec, freqs,
                                      cfg, use_surrogate)
    i, k = np.unravel_index(np.argmax(L), L.shape)
    return (m_grid[i], y_grid[k]), L


def metropolis_hastings(data_spec, template_spec, freqs, cfg, start,
                        n_samples=2000, n_burn=1000, step=(30.0, 0.03),
                        seed=0, use_surrogate=True):
    """Simple adaptive-free Metropolis-Hastings sampler for ``(M_Lz, y)``."""
    rng = np.random.default_rng(seed)
    cur = np.array(start, dtype=float)
    cur_ll = lensing_loglike(cur, data_spec, template_spec, freqs, cfg, use_surrogate)
    chain = []
    acc = 0
    for it in range(n_samples + n_burn):
        prop = cur + rng.normal(scale=step, size=2)
        prop_ll = lensing_loglike(prop, data_spec, template_spec, freqs, cfg,
                                  use_surrogate)
        if np.log(rng.random() + 1e-300) < (prop_ll - cur_ll):
            cur, cur_ll = prop, prop_ll
            acc += 1
        if it >= n_burn:
            chain.append(cur.copy())
    chain = np.array(chain)
    return chain, acc / (n_samples + n_burn)


def gelman_rubin(chains):
    """Gelman-Rubin R-hat for a list of 1D chains."""
    chains = np.asarray(chains)
    m, n = chains.shape
    means = chains.mean(axis=1)
    B = n * means.var(ddof=1)
    W = chains.var(axis=1, ddof=1).mean()
    var = (1 - 1.0 / n) * W + B / n
    return float(np.sqrt(var / (W + 1e-30)))
