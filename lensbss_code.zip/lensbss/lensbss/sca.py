"""Sparse component analysis for complex underdetermined mixing.

The pipeline has three stages (paper Section 2.3--2.4):

1. :func:`rank_one_ssp` - detect single-source time-frequency cells by a local
   rank-one covariance test that is valid for *complex* mixing;
2. :func:`cluster_directions` - cluster the single-source-point directions on
   the complex projective line CP^1 with DBSCAN, recovering the mixing columns;
3. :func:`sparse_recover` - recover the sources cell-by-cell with a
   minimum-l1 (shortest-path) assignment to at most two columns per cell.
"""

from __future__ import annotations

import numpy as np
from scipy.signal import stft as _sp_stft, istft as _sp_istft


def stft(x, cfg):
    """Short-time Fourier transform matching the package conventions.

    Detector strains are real, so a one-sided (positive-frequency) transform is
    used; the resulting complex TF cells carry the complex mixing structure.  A
    Hann window at 75%% overlap satisfies COLA, so the transform is invertible.
    """
    f, t, Z = _sp_stft(np.real(x), fs=cfg.f_s, nperseg=cfg.n_stft,
                       noverlap=cfg.n_stft - cfg.hop, window="hann",
                       return_onesided=True, boundary="zeros", padded=True)
    return f, t, Z


def istft(Z, cfg):
    """Inverse of :func:`stft`."""
    _, x = _sp_istft(Z, fs=cfg.f_s, nperseg=cfg.n_stft,
                     noverlap=cfg.n_stft - cfg.hop, window="hann",
                     input_onesided=True, boundary=True)
    return x


def rank_one_ssp(channels, cfg, smooth=(3, 3)):
    """Detect single-source-point cells via a local rank-one covariance test.

    Parameters
    ----------
    channels
        Array ``(n_det, n_t)`` of (complex) detector channels.  Only the first
        two channels are used for the 2x2 test.
    cfg
        Configuration providing STFT parameters and the threshold ``eta``.
    smooth
        Covariance-smoothing neighbourhood ``(n_freq, n_time)``.

    Returns
    -------
    dict
        ``freqs``, ``times``, ``mask`` (boolean SSP map), ``alpha``, ``beta``
        (per-cell CP^1 direction), ``weight`` (TF energy), and ``Z`` (list of
        per-channel STFTs).
    """
    Zs = []
    for a in range(min(2, channels.shape[0])):
        f, t, Z = stft(channels[a], cfg)
        Zs.append(Z)
    Z1, Z2 = Zs[0], Zs[1]

    band = (f >= cfg.band[0]) & (f <= cfg.band[1])

    # Local 2x2 covariance entries, smoothed by a boxcar.
    from scipy.ndimage import uniform_filter
    c11 = uniform_filter(np.abs(Z1) ** 2, size=smooth)
    c22 = uniform_filter(np.abs(Z2) ** 2, size=smooth)
    c12 = uniform_filter((Z1 * np.conj(Z2)).real, size=smooth) \
        + 1j * uniform_filter((Z1 * np.conj(Z2)).imag, size=smooth)

    tr = c11 + c22
    det = (c11 * c22 - np.abs(c12) ** 2).real
    disc = np.sqrt(np.clip(tr ** 2 - 4.0 * det, 0.0, None))
    lam_max = 0.5 * (tr + disc)
    lam_min = 0.5 * (tr - disc)
    cond = lam_min / (lam_max + 1e-30)

    mask = (cond < cfg.eta) & band[:, None]
    # Dominant eigenvector direction: for a 2x2 Hermitian matrix, take the
    # column-space direction from (c12, lam_max - c11).
    a1 = lam_max - c22
    a2 = np.conj(c12)
    norm = np.sqrt(np.abs(a1) ** 2 + np.abs(a2) ** 2) + 1e-30
    a1n, a2n = a1 / norm, a2 / norm

    alpha = np.arctan2(np.abs(a2n), np.abs(a1n))
    beta = np.angle(a2n / (a1n + 1e-30))
    weight = lam_max
    return dict(freqs=f, times=t, mask=mask, alpha=alpha, beta=beta,
                weight=weight, Z=Zs)


def cluster_directions(ssp, cfg, n_expected=None):
    """Cluster single-source-point directions with DBSCAN on (alpha, beta).

    Returns the estimated complex columns (unit-norm, 2-vector each) as an
    array of shape ``(2, n_clusters)`` together with the cluster labels.
    """
    from sklearn.cluster import DBSCAN
    m = ssp["mask"]
    a = ssp["alpha"][m]
    b = ssp["beta"][m]
    w = ssp["weight"][m]
    if a.size == 0:
        return np.zeros((2, 0), dtype=complex), np.array([]), (a, b, w)

    # Wrap beta into a 2D unit circle to avoid the +/-pi seam.
    feats = np.stack([a / (np.pi / 2), np.cos(b), np.sin(b)], axis=-1)
    db = DBSCAN(eps=cfg.dbscan_eps, min_samples=cfg.dbscan_min_samples).fit(feats)
    labels = db.labels_

    cols = []
    for lab in sorted(set(labels)):
        if lab == -1:
            continue
        sel = labels == lab
        aw = np.average(a[sel], weights=w[sel])
        # Circular mean of beta.
        bw = np.arctan2(np.average(np.sin(b[sel]), weights=w[sel]),
                        np.average(np.cos(b[sel]), weights=w[sel]))
        col = np.array([np.cos(aw), np.sin(aw) * np.exp(1j * bw)], dtype=complex)
        col /= np.linalg.norm(col)
        cols.append((w[sel].sum(), col))
    cols.sort(key=lambda z: -z[0])
    if n_expected is not None:
        cols = cols[:n_expected]
    C = np.stack([c for _, c in cols], axis=-1) if cols else np.zeros((2, 0), complex)
    return C, labels, (a, b, w)


def sparse_recover(channels, columns, cfg):
    """Minimum-l1 cell-by-cell recovery for at most two active columns.

    Parameters
    ----------
    channels
        ``(n_det, n_t)`` complex detector channels.
    columns
        Estimated complex columns ``(2, n_sources)``.
    cfg
        Configuration.

    Returns
    -------
    numpy.ndarray, shape (n_sources, n_t), real
        Recovered source time series.
    """
    f, t, Z1 = stft(channels[0], cfg)
    _, _, Z2 = stft(channels[1], cfg)
    n_src = columns.shape[1]
    S = [np.zeros_like(Z1) for _ in range(n_src)]

    pairs = [(i, j) for i in range(n_src) for j in range(i + 1, n_src)]
    if n_src == 1:
        pairs = [(0, 0)]

    X = np.stack([Z1, Z2], axis=0)  # (2, nf, nt)
    nf, nt = Z1.shape
    for fi in range(nf):
        for ti in range(nt):
            x = X[:, fi, ti]
            if np.abs(x).sum() == 0:
                continue
            best_cost = np.inf
            best = None
            for (i, j) in pairs:
                A = np.stack([columns[:, i], columns[:, j]], axis=-1)
                try:
                    sol, *_ = np.linalg.lstsq(A, x, rcond=None)
                except np.linalg.LinAlgError:
                    continue
                cost = np.abs(sol).sum()
                if cost < best_cost:
                    best_cost, best = cost, (i, j, sol)
            if best is None:
                continue
            i, j, sol = best
            S[i][fi, ti] += sol[0]
            if i != j:
                S[j][fi, ti] += sol[1]

    out = np.stack([np.real(istft(Sk, cfg)) for Sk in S], axis=0)
    return out
