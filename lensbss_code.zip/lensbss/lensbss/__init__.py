"""
lensbss: blind source separation of overlapping lensed gravitational-wave
transients in a third-generation network.

This package accompanies the manuscript

    Y. Jia, P. Xu and F. Zhang,
    "Blind source separation of overlapping lensed gravitational-wave
    transients in a third-generation network with a neural wave-optics
    surrogate", submitted to Classical and Quantum Gravity.

It provides a fully reproducible simulation of overlapping (optionally lensed)
compact-binary signals in a co-located Einstein Telescope network, a
covariance-based sparse-component-analysis (SCA) separation pipeline valid for
complex detector mixing, a wave-optics amplification-factor evaluator with a
neural-surrogate interface, and a profiled-amplitude lensing-inference stage.

The public API is intentionally small; see the ``experiments/`` drivers for
end-to-end examples that regenerate the figures in the paper.
"""

from .config import Config, default_config
from .waveforms import taylorf2, imr_phenom
from .lensing import dimensionless_frequency, amplification_factor
from .mixing import et_mixing_columns, mix_sources
from .sca import (
    stft,
    istft,
    rank_one_ssp,
    cluster_directions,
    sparse_recover,
)
from .separation import separate
from .metrics import phase_aligned_sdr, cp1_angle
from .inference import lensing_loglike, grid_fit, metropolis_hastings

__version__ = "1.0.0"

__all__ = [
    "Config",
    "default_config",
    "taylorf2",
    "imr_phenom",
    "dimensionless_frequency",
    "amplification_factor",
    "et_mixing_columns",
    "mix_sources",
    "stft",
    "istft",
    "rank_one_ssp",
    "cluster_directions",
    "sparse_recover",
    "separate",
    "phase_aligned_sdr",
    "cp1_angle",
    "lensing_loglike",
    "grid_fit",
    "metropolis_hastings",
]
