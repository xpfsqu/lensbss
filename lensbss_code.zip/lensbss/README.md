# lensbss

**Blind source separation of overlapping lensed gravitational-wave transients in
a third-generation network with a neural wave-optics surrogate.**

Reference implementation accompanying the manuscript submitted to *Classical and
Quantum Gravity*:

> Y. Jia, P. Xu and F. Zhang, *Blind source separation of overlapping lensed
> gravitational-wave transients in a third-generation network with a neural
> wave-optics surrogate.*

The package simulates overlapping (optionally lensed) compact-binary signals in a
co-located Einstein Telescope network and separates them with a
covariance-based sparse-component-analysis (SCA) pipeline that is valid for
**complex** detector mixing. It also provides a wave-optics amplification-factor
evaluator with a neural-surrogate interface and a profiled-amplitude
lensing-inference stage.

## Why this is not the usual SCA pipeline

1. **Realistic ET mixing is complex and frequency dependent**, so the classical
   real-ratio single-source-point (SSP) test is invalid. We replace it with a
   local **rank-one covariance detector** and cluster the recovered directions on
   the complex projective line `CP^1` (`lensbss/sca.py`).
2. **Two images of a strongly lensed source share one mixing column** and are
   geometrically inseparable by direction; a coherent, template-informed stage is
   required (`experiments/run_strong_lensing.py`).
3. **Separation biases downstream lensing point estimates**, so BSS is used as a
   preprocessing / initialization stage feeding a Bayesian fit, not as a
   standalone estimator (`lensbss/inference.py`).

## Installation

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
pip install -e .            # optional: installs the `lensbss` package
```

`mpmath` is optional. If it is present, the amplification factor is evaluated
with the arbitrary-precision confluent-hypergeometric reference; if it is absent,
the code falls back transparently to the geometric-optics limit so every script
still runs.

## Quick start

```bash
python experiments/smoke_test.py            # ~10 s end-to-end sanity check
python experiments/run_fiducial.py          # three-source separation + scatter
python experiments/run_strong_lensing.py    # shared-column demonstration
python experiments/run_baselines.py         # SCA vs FastICA vs DUET
python experiments/run_lensing_inference.py # profiled-amplitude lensing fit
python experiments/run_lowfreq.py           # starting-frequency cross-check
python experiments/run_whitening.py         # whitening + PSD-mismatch ablation
python experiments/run_scaling.py           # scaling with source count N
python experiments/run_wdo.py               # W-disjoint separation-success map
python experiments/run_strong_lensing.py --grid  # coherent recovery over a grid
python experiments/run_population.py --n 100  # population bias / coverage
```

If you did not `pip install -e .`, run from the repository root with
`PYTHONPATH=.` prefixed, e.g. `PYTHONPATH=. python experiments/run_fiducial.py`.

## Repository layout

```
lensbss/
  config.py       simulation + analysis configuration and constants
  waveforms.py    TaylorF2 (PN) and phenomenological IMR waveforms
  psd.py          ET-D / aLIGO design PSDs, coloured noise, whitening
  mixing.py       complex ET mixing columns and the mixing operator
  lensing.py      wave-optics amplification factor F(omega, y)
  surrogate.py    SIREN surrogate interface for F (fast path)
  sca.py          rank-one SSP detection, CP^1 clustering, sparse recovery
  separation.py   end-to-end pipeline + fiducial mixture builder
  metrics.py      phase-aligned SDR and CP^1 angle
  inference.py    profiled-amplitude lensing likelihood, grid + MCMC
  baselines.py    FastICA, DUET, CLEAN-like references
experiments/
  run_*.py        one driver per figure / experiment in the paper
  smoke_test.py   fast CI check
configs/
  fiducial.yaml   the fiducial configuration
```

## Reproducibility notes

* Every driver seeds NumPy explicitly (see `lensbss/config.py`).
* The waveforms are research-grade PN / phenomenological-IMR implementations, not
  calibrated LIGO Algorithm Library templates; absolute parameter values are
  illustrative (see the paper's limitations section).
* The trained SIREN surrogate weights of Zhang et al. (2026) are not bundled;
  without a `weights.npz` checkpoint the surrogate defers to the exact/geometric
  evaluator with an identical interface. Train with
  `experiments/train_surrogate.py` (optional) to reproduce the surrogate timing.

## License

MIT. See `LICENSE`.
